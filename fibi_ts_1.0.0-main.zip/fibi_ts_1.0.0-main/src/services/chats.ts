// ============================================
// src/services/chats.ts
// Описание: CRUD операции с чатами (загрузка в облако, мерж)
// Версия: 3.0.0 - TypeScript
// ============================================

import { getApiClient } from './api';
import { getChatStore, Chat, Message, CreateChatOptions } from '@store/ChatStore';
import { getUserStore } from '@store/UserStore';
import { getEventBus } from '@core/event-bus';
import { generateUUID } from '@utils/helpers';

/**
 * Результат загрузки чатов
 */
export interface LoadChatsResult {
    success: boolean;
    chats: Chat[];
    totalMessages: number;
    syncToken: string | null;
}

/**
 * Результат операции с чатом
 */
export interface ChatOperationResult {
    success: boolean;
    syncToken?: string | null;
    error?: string;
    chatId?: string;
}

/**
 * Сервис для работы с чатами
 */
export class ChatService {
    private static instance: ChatService | null = null;

    private apiClient = getApiClient();
    private chatStore = getChatStore();
    private userStore = getUserStore();
    private eventBus = getEventBus();
    private _uploadStartTime: number = 0;
    private _uploadTotal: number = 0;

    private constructor() {}

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): ChatService {
        if (!ChatService.instance) {
            ChatService.instance = new ChatService();
        }
        return ChatService.instance;
    }

    // ==========================================
    // ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    // ==========================================

    /**
     * Сохранить sync_token после действия
     */
    private saveSyncToken(syncToken: string | null): void {
        if (syncToken) {
            const tempStore = new (window as any).BaseStore('temp');
            tempStore.saveSyncToken(syncToken);
            console.log(`✅ sync_token обновлен после действия: ${syncToken.substring(0, 8)}...`);
        }
    }

    /**
     * Получить текущий sync_token
     */
    private getSyncToken(): string | null {
        const tempStore = new (window as any).BaseStore('temp');
        return tempStore.getSyncToken();
    }

    // ==========================================
    // ЗАГРУЗКА ДАННЫХ
    // ==========================================

    /**
     * Полная перезагрузка данных (с sync=true)
     */
    async fullReload(): Promise<boolean> {
        console.log('🔄 [fullReload] Начинаем полную перезагрузку данных...');

        try {
            const data = await this.loadAllChats({ sync: true });

            if (data && data.success && data.chats) {
                if (data.syncToken) {
                    this.saveSyncToken(data.syncToken);
                }

                console.log(`✅ [fullReload] Загружено ${data.chats.length} чатов, ${data.totalMessages || 0} сообщений`);

                // Обновляем UI
                if ((window as any).chatUI) {
                    (window as any).chatUI.refreshUI();
                }
                if ((window as any).profileUI) {
                    (window as any).profileUI.renderHistoryChatsList(
                        (window as any).profileUI.currentFilter || 'all'
                    );
                }

                return true;
            }

            return false;
        } catch (err) {
            console.error('❌ [fullReload] Ошибка:', err);
            return false;
        }
    }

    /**
     * Загрузить все чаты
     */
    async loadAllChats(options: { sync?: boolean } = {}): Promise<LoadChatsResult | null> {
        if (!this.userStore.canSync()) {
            console.log('⏭️ Синхронизация отключена');
            return null;
        }

        try {
            const { sync = false } = options;
            const url = sync ? '/chats/get-all?sync=true' : '/chats/get-all';

            console.log(`📋 [loadAllChats] Загружаем все чаты (sync=${sync})...`);

            const data = await this.apiClient.get<any>(url);

            if (data.success && data.chats) {
                this.chatStore.updateAllChats(data.chats);

                if (data.syncToken) {
                    this.saveSyncToken(data.syncToken);
                }

                console.log(`✅ [loadAllChats] Загружено ${data.chats.length} чатов, ${data.total_messages || 0} сообщений`);

                return {
                    success: true,
                    chats: data.chats,
                    totalMessages: data.total_messages || 0,
                    syncToken: data.syncToken || null
                };
            }

            return null;
        } catch (err) {
            console.error('❌ [loadAllChats] Ошибка:', err);
            return null;
        }
    }

    /**
     * Загрузить метаданные чатов
     */
    async loadMetadata(silent: boolean = false): Promise<any> {
        if (!this.userStore.canSync()) {
            console.log('⏭️ Синхронизация отключена');
            return null;
        }

        try {
            if (!silent) console.log('📋 Загрузка метаданных чатов...');

            const data = await this.apiClient.get('/chats/sync-metadata');

            if (data.chats && Array.isArray(data.chats)) {
                this.chatStore.updateMetadata(data.chats);
                console.log(`✅ Загружено ${data.chats.length} метаданных чатов`);
            }

            return data;
        } catch (err) {
            console.error('❌ Ошибка загрузки метаданных:', err);
            return null;
        }
    }

    /**
     * Открыть чат по ID
     */
    async openChat(chatId: string): Promise<boolean> {
        if (!this.userStore.canSync()) {
            console.log('⏭️ Синхронизация отключена');
            return false;
        }

        try {
            console.log(`📂 Открываем чат ${chatId}...`);

            const data = await this.apiClient.get(`/chats/get?id=${chatId}`);

            if (data.success && data.chat) {
                this.mergeChatFromCloud(
                    {
                        ...data.chat,
                        messages: data.messages || []
                    },
                    data.chat.topic_id
                );

                if (data.syncToken) {
                    this.saveSyncToken(data.syncToken);
                }

                return true;
            }

            return false;
        } catch (err) {
            console.error(`❌ Ошибка открытия чата ${chatId}:`, err);
            return false;
        }
    }

    // ==========================================
    // MERGE ЧАТОВ
    // ==========================================

    /**
     * Смержить облачный чат с локальным
     */
    mergeChatFromCloud(cloudChat: any, topicId: string): Chat | null {
        console.log(`🔄 Мержим чат ${cloudChat.id} из облака...`);

        const found = this.chatStore.findChatById(cloudChat.id);

        if (found) {
            const { chat } = found;

            // Обновляем метаданные
            chat.title = cloudChat.title;
            chat.maxContext = cloudChat.max_context || 15;
            chat.userRenamed = cloudChat.user_renamed || false;
            chat.updated_at = cloudChat.updated_at;
            chat.deleted_at = cloudChat.deleted_at || null;
            chat.synced = true;

            // Мержим сообщения
            const cloudMsgIds = new Set(cloudChat.messages.map((m: any) => m.id));

            // Сохраняем локальные сообщения, которых нет в облаке
            chat.messages = chat.messages.filter(m => {
                if (cloudMsgIds.has(m.id)) return true;
                if (!m.id || m.id.startsWith('local_')) return true;
                return false;
            });

            // Добавляем новые сообщения из облака
            for (const msg of cloudChat.messages) {
                const exists = chat.messages.some(m => m.id === msg.id);
                if (!exists) {
                    chat.messages.push({
                        id: msg.id,
                        text: msg.text,
                        type: msg.msg_type || msg.type || 'user-msg',
                        isFavorite: msg.is_favorite || false,
                        deleted_at: msg.deleted_at || null,
                        created_at: msg.created_at || new Date().toISOString()
                    });
                }
            }

            // Сортируем сообщения
            chat.messages.sort((a, b) => {
                return new Date(a.created_at || 0).getTime() - new Date(b.created_at || 0).getTime();
            });

            this.chatStore.save();

            console.log(`✅ Чат ${cloudChat.id} обновлен (${chat.messages.length} сообщений)`);
            return chat;
        } else {
            // Создаем новый чат
            const newChat = this.chatStore.createChat(
                topicId || cloudChat.topic_id || 'fast',
                cloudChat.title,
                {
                    id: cloudChat.id,
                    maxContext: cloudChat.max_context || 15,
                    userRenamed: cloudChat.user_renamed || false,
                    synced: true,
                    messages: cloudChat.messages.map((m: any) => ({
                        id: m.id,
                        text: m.text,
                        type: m.msg_type || m.type || 'user-msg',
                        isFavorite: m.is_favorite || false,
                        deleted_at: m.deleted_at || null,
                        created_at: m.created_at || new Date().toISOString()
                    }))
                }
            );

            console.log(`✅ Новый чат ${cloudChat.id} создан (${newChat.messages.length} сообщений)`);
            return newChat;
        }
    }

    // ==========================================
    // ОПЕРАЦИИ С ЧАТАМИ
    // ==========================================

    /**
     * Получить чат
     */
    async getChat(chatId: string): Promise<Chat | null> {
        try {
            const data = await this.apiClient.get(`/chats/get?id=${chatId}`);

            if (data.success && data.chat) {
                const syncedChat = this.mergeChatFromCloud(
                    {
                        ...data.chat,
                        messages: data.messages || []
                    },
                    data.chat.topic_id
                );

                if (data.syncToken) {
                    this.saveSyncToken(data.syncToken);
                }

                return syncedChat;
            }

            return null;
        } catch (err) {
            console.error(`❌ Ошибка получения чата ${chatId}:`, err);
            return null;
        }
    }

    /**
     * Переименовать чат
     */
    async renameChat(chatId: string, newTitle: string): Promise<boolean> {
        if (!this.userStore.canSync()) {
            console.log('⏭️ Синхронизация отключена');
            return false;
        }

        try {
            const result = await this.apiClient.post('/chats/actions/update', {
                action: 'rename_chat',
                chatId: chatId,
                newTitle: newTitle.trim()
            });

            if (result.success) {
                this.chatStore.renameChat(chatId, newTitle);
                this.saveSyncToken(result.syncToken);
                console.log(`✅ Чат ${chatId} переименован`);
                return true;
            }

            return false;
        } catch (err) {
            console.error(`❌ Ошибка переименования чата ${chatId}:`, err);
            return false;
        }
    }

    /**
     * Обновить контекст чата
     */
    async updateContext(chatId: string, maxContext: number): Promise<boolean> {
        if (!this.userStore.canSync()) {
            console.log('⏭️ Синхронизация отключена');
            return false;
        }

        try {
            const result = await this.apiClient.post('/chats/actions/update', {
                action: 'update_context',
                chatId: chatId,
                maxContext: maxContext
            });

            if (result.success) {
                this.chatStore.updateChat(chatId, { maxContext });
                this.saveSyncToken(result.syncToken);
                console.log(`✅ Контекст чата ${chatId} обновлён`);
                return true;
            }

            return false;
        } catch (err) {
            console.error(`❌ Ошибка обновления контекста ${chatId}:`, err);
            return false;
        }
    }

    /**
     * Удалить чат (в корзину)
     */
    async deleteChat(chatId: string): Promise<boolean> {
        this.chatStore.deleteChat(chatId);

        if (this.userStore.canSync()) {
            try {
                const result = await this.apiClient.post('/chats/actions/update', {
                    action: 'delete_chat',
                    chatId: chatId
                });

                if (result.success) {
                    this.saveSyncToken(result.syncToken);
                    console.log(`✅ Чат ${chatId} отправлен в корзину на сервере`);
                    return true;
                }

                return false;
            } catch (err) {
                console.error(`❌ Ошибка удаления чата ${chatId}:`, err);
                return false;
            }
        }

        return true;
    }

    /**
     * Восстановить чат из корзины
     */
    async restoreChat(chatId: string): Promise<boolean> {
        this.chatStore.restoreChat(chatId);

        if (this.userStore.canSync()) {
            try {
                const result = await this.apiClient.post('/chats/trash', {
                    id: chatId,
                    type: 'chat'
                });

                if (result.success) {
                    this.saveSyncToken(result.syncToken);
                    console.log(`✅ Чат ${chatId} восстановлен на сервере`);
                    return true;
                }

                return false;
            } catch (err) {
                console.error(`❌ Ошибка восстановления чата ${chatId}:`, err);
                return false;
            }
        }

        return true;
    }

    /**
     * Безвозвратное удаление чата
     */
    async permanentDeleteChat(chatId: string): Promise<boolean> {
        this.chatStore.permanentDeleteChat(chatId);

        if (this.userStore.canSync()) {
            try {
                const result = await this.apiClient.delete('/chats/trash', {
                    body: {
                        id: chatId,
                        type: 'chat'
                    }
                });

                if (result.success) {
                    this.saveSyncToken(result.syncToken);
                    console.log(`✅ Чат ${chatId} удален навсегда на сервере (HARD DELETE)`);
                    return true;
                }

                return false;
            } catch (err) {
                console.error(`❌ Ошибка HARD DELETE чата ${chatId}:`, err);
                return false;
            }
        }

        return true;
    }

    // ==========================================
    // СОЗДАНИЕ ЧАТА
    // ==========================================

    /**
     * Создать чат в облаке
     */
    async createChat(
        topicId: string,
        title: string,
        options: CreateChatOptions & { firstMessage?: Message } = {}
    ): Promise<Chat | null> {
        const hasMessages = options.firstMessage && options.firstMessage.text;

        if (!hasMessages) {
            console.warn('⚠️ Попытка создать пустой чат — отклонено');
            return null;
        }

        try {
            const chatId = options.existingChatId || undefined;

            const data = await this.apiClient.post('/chats/actions/create', {
                action: 'create_chat',
                chat: {
                    id: chatId,
                    topic_id: topicId,
                    title: title || `Чат в ${topicId}`,
                    max_context: options.maxContext || 15,
                    user_renamed: options.userRenamed || false
                },
                firstMessage: options.firstMessage || null
            });

            if (data.success) {
                this.saveSyncToken(data.syncToken);

                const existingChat = this.chatStore.findChatById(data.chatId);

                if (existingChat) {
                    const updatedChat = this.chatStore.updateChat(data.chatId, {
                        synced: true,
                        title: title || existingChat.chat.title,
                        updated_at: new Date().toISOString()
                    });

                    if (options.firstMessage && data.messageId) {
                        const existingMsg = existingChat.chat.messages.find(
                            m => m.id === options.firstMessage!.id
                        );
                        if (!existingMsg) {
                            this.chatStore.addMessage(
                                data.chatId,
                                options.firstMessage.text,
                                options.firstMessage.type || 'user-msg',
                                {
                                    id: data.messageId,
                                    synced: true
                                }
                            );
                        }
                    }

                    console.log(`✅ Чат ${data.chatId} обновлён в облаке`);
                    return updatedChat || existingChat.chat;
                } else {
                    const chat = this.chatStore.createChat(topicId, title, {
                        ...options,
                        synced: true,
                        id: data.chatId
                    });

                    if (options.firstMessage && data.messageId) {
                        this.chatStore.addMessage(
                            data.chatId,
                            options.firstMessage.text,
                            options.firstMessage.type || 'user-msg',
                            {
                                id: data.messageId,
                                synced: true
                            }
                        );
                    }

                    console.log(`✅ Создан новый чат ${data.chatId} в облаке`);
                    return chat;
                }
            }

            return null;
        } catch (err) {
            console.error('❌ Ошибка создания чата:', err);
            return null;
        }
    }

    // ==========================================
    // ЗАГРУЗКА ЛОКАЛЬНЫХ ДАННЫХ В ОБЛАКО
    // ==========================================

    /**
     * Загрузить локальные данные в облако
     */
    async uploadLocalDataToCloud(): Promise<boolean> {
        const localChats = this.getAllLocalChats();
        const total = localChats.length;

        if (total === 0) {
            console.log('📭 Нет локальных чатов для загрузки');
            return true;
        }

        console.log(`📤 Загрузка ${total} чатов в облако...`);
        this.showProgressModal(total);

        let uploaded = 0;
        let currentIndex = 0;
        const errors: string[] = [];

        this.chatStore.setUploadProgress(0, total);

        while (currentIndex < localChats.length) {
            const chat = localChats[currentIndex];

            try {
                const exists = await this.checkChatExists(chat.id);

                if (exists) {
                    await this.updateChatInCloud(chat);
                } else {
                    await this.createChatInCloud(chat);
                }

                uploaded++;
                currentIndex++;
                this.chatStore.setUploadProgress(currentIndex, total);
                this.updateProgress(uploaded, total);

            } catch (error: any) {
                console.error(`❌ Ошибка загрузки чата ${chat.id}:`, error);

                const action = await this.showErrorDialog({
                    message: `Ошибка при загрузке чата "${chat.title || 'Без названия'}"`,
                    error: error.message || 'Неизвестная ошибка',
                    options: ['Повторить', 'Пропустить', 'Отменить']
                });

                if (action === 'Повторить') {
                    continue;
                } else if (action === 'Пропустить') {
                    currentIndex++;
                    this.chatStore.setUploadProgress(currentIndex, total);
                    continue;
                } else {
                    await this.rollbackUpload(uploaded, localChats);
                    this.hideProgressModal();
                    this.chatStore.clearUploadFlags();

                    if ((window as any).uiRenderer) {
                        (window as any).uiRenderer.showToast('❌ Загрузка отменена. Данные откатаны.', 'error', 3000);
                    }
                    return false;
                }
            }
        }

        this.hideProgressModal();
        this.chatStore.clearUploadFlags();

        if (errors.length > 0) {
            if ((window as any).uiRenderer) {
                (window as any).uiRenderer.showToast(
                    `⚠️ Загружено ${uploaded} из ${total} чатов. ${errors.length} пропущено.`,
                    'warning',
                    3000
                );
            }
        } else {
            if ((window as any).uiRenderer) {
                (window as any).uiRenderer.showToast(
                    `✅ Все ${total} чатов успешно загружены в облако!`,
                    'success',
                    3000
                );
            }
        }

        return true;
    }

    /**
     * Получить все локальные чаты
     */
    private getAllLocalChats(): Chat[] {
        const allChats: Chat[] = [];

        for (const [topic, chats] of Object.entries(this.chatStore.histories)) {
            if (!chats || !Array.isArray(chats)) continue;

            for (const chat of chats) {
                if (chat.deleted_at) continue;
                if (!this.chatStore.hasRealMessages(chat)) continue;

                allChats.push({
                    ...chat,
                    topic: topic
                } as Chat);
            }
        }

        return allChats;
    }

    /**
     * Проверить существование чата
     */
    private async checkChatExists(chatId: string): Promise<boolean> {
        try {
            const data = await this.apiClient.get(`/chats/get?id=${chatId}`);
            return data.success && data.chat;
        } catch (err: any) {
            if (err.status === 404) return false;
            throw err;
        }
    }

    /**
     * Обновить чат в облаке
     */
    private async updateChatInCloud(localChat: Chat): Promise<void> {
        console.log(`📝 Обновляем чат ${localChat.id} в облаке (мерж)...`);

        const cloudChat = await this.getChat(localChat.id);
        if (!cloudChat) {
            throw new Error('Не удалось загрузить чат из облака');
        }

        const cloudMsgIds = new Set(cloudChat.messages.map(m => m.id));
        const newMessages = localChat.messages.filter(m => !cloudMsgIds.has(m.id));

        if (newMessages.length > 0) {
            for (const msg of newMessages) {
                const result = await this.apiClient.post('/chats/actions/message', {
                    action: 'new_message',
                    chatId: localChat.id,
                    message: {
                        id: msg.id,
                        text: msg.text,
                        type: msg.type,
                        isFavorite: msg.isFavorite || false
                    }
                });
                this.saveSyncToken(result.syncToken);
            }
            console.log(`📝 Добавлено ${newMessages.length} новых сообщений в чат ${localChat.id}`);
        }

        // Обновляем метаданные
        if (localChat.title !== cloudChat.title || localChat.maxContext !== cloudChat.maxContext) {
            const result = await this.apiClient.post('/chats/actions/update', {
                action: 'rename_chat',
                chatId: localChat.id,
                newTitle: localChat.title
            });
            this.saveSyncToken(result.syncToken);
            console.log(`📝 Обновлены метаданные чата ${localChat.id}`);
        }
    }

    /**
     * Создать чат в облаке
     */
    private async createChatInCloud(localChat: Chat): Promise<void> {
        console.log(`📝 Создаем чат ${localChat.id} в облаке...`);

        const result = await this.apiClient.post('/chats/actions/create', {
            action: 'create_chat',
            chat: {
                id: localChat.id,
                topic_id: localChat.topic,
                title: localChat.title,
                max_context: localChat.maxContext || 15,
                user_renamed: localChat.userRenamed || false
            },
            firstMessage: null
        });
        this.saveSyncToken(result.syncToken);

        const messages = localChat.messages.filter(m => !m.deleted_at);

        if (messages.length > 0) {
            for (const msg of messages) {
                const msgResult = await this.apiClient.post('/chats/actions/message', {
                    action: 'new_message',
                    chatId: localChat.id,
                    message: {
                        id: msg.id,
                        text: msg.text,
                        type: msg.type,
                        isFavorite: msg.isFavorite || false
                    }
                });
                this.saveSyncToken(msgResult.syncToken);
            }
            console.log(`📝 Загружено ${messages.length} сообщений в чат ${localChat.id}`);
        }

        console.log(`✅ Чат ${localChat.id} создан в облаке`);
    }

    /**
     * Откат загрузки
     */
    private async rollbackUpload(uploadedCount: number, localChats: Chat[]): Promise<void> {
        console.log(`🔄 Откатываем загрузку (${uploadedCount} чатов)...`);

        for (let i = 0; i < uploadedCount && i < localChats.length; i++) {
            const chat = localChats[i];
            if (chat) {
                try {
                    await this.apiClient.delete('/chats/trash', {
                        body: {
                            id: chat.id,
                            type: 'chat',
                            deviceFingerprint: 'rollback'
                        }
                    });
                    console.log(`🗑️ Удален чат ${chat.id} из облака (откат)`);
                } catch (err) {
                    console.error(`❌ Не удалось удалить чат ${chat.id}:`, err);
                }
            }
        }

        const tempStore = new (window as any).BaseStore('temp');
        tempStore.clearSyncToken();

        console.log('✅ Откат завершен');
    }

    // ==========================================
    // UI ДЛЯ ЗАГРУЗКИ
    // ==========================================

    /**
     * Показать модалку прогресса
     */
    private showProgressModal(total: number): void {
        const modal = document.createElement('div');
        modal.id = 'upload-progress-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            backdrop-filter: blur(8px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            animation: fadeIn 0.3s ease;
        `;

        modal.innerHTML = `
            <div style="background: var(--app-bg-secondary); padding: 32px; border-radius: 16px; max-width: 400px; width: 90%; text-align: center; box-shadow: 0 20px 60px rgba(0,0,0,0.3);">
                <div style="font-size: 48px; margin-bottom: 12px;">☁️</div>
                <h3 style="margin: 0 0 8px 0; color: var(--app-text-primary);">Загрузка в облако</h3>
                <p style="color: var(--app-text-tertiary); font-size: 14px; margin: 0 0 8px 0;">
                    Пожалуйста, не закрывайте приложение...
                </p>
                <p id="upload-time-estimate" style="color: var(--app-text-tertiary); font-size: 12px; margin: 0 0 20px 0;">
                    Осталось ~ вычисляется...
                </p>
                <div style="width: 100%; height: 8px; background: var(--app-bg-tertiary); border-radius: 4px; overflow: hidden;">
                    <div id="upload-progress-bar" style="width: 0%; height: 100%; background: var(--app-gradient-primary); transition: width 0.3s ease; border-radius: 4px;"></div>
                </div>
                <div style="display: flex; justify-content: space-between; margin-top: 8px; font-size: 12px; color: var(--app-text-tertiary);">
                    <span id="upload-progress-text">0%</span>
                    <span id="upload-progress-count">0/${total}</span>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        this._uploadStartTime = Date.now();
        this._uploadTotal = total;
    }

    /**
     * Обновить прогресс
     */
    private updateProgress(current: number, total: number): void {
        const bar = document.getElementById('upload-progress-bar');
        const text = document.getElementById('upload-progress-text');
        const count = document.getElementById('upload-progress-count');
        const estimate = document.getElementById('upload-time-estimate');

        if (bar) {
            const percent = Math.round((current / total) * 100);
            bar.style.width = `${Math.min(percent, 100)}%`;
        }

        if (text) {
            const percent = Math.round((current / total) * 100);
            text.textContent = `${Math.min(percent, 100)}%`;
        }

        if (count) {
            count.textContent = `${current}/${total}`;
        }

        if (estimate && current > 0) {
            const elapsed = (Date.now() - this._uploadStartTime) / 1000;
            const avgTimePerChat = elapsed / current;
            const remaining = (total - current) * avgTimePerChat;

            if (remaining > 60) {
                estimate.textContent = `⏱️ Осталось ~ ${Math.round(remaining / 60)} минут`;
            } else if (remaining > 0) {
                estimate.textContent = `⏱️ Осталось ~ ${Math.round(remaining)} секунд`;
            } else {
                estimate.textContent = '⏱️ Завершается...';
            }
        }
    }

    /**
     * Скрыть модалку прогресса
     */
    private hideProgressModal(): void {
        const modal = document.getElementById('upload-progress-modal');
        if (modal) {
            modal.style.opacity = '0';
            modal.style.transition = 'opacity 0.3s ease';
            setTimeout(() => modal.remove(), 300);
        }
        this._uploadStartTime = 0;
        this._uploadTotal = 0;
    }

    /**
     * Показать диалог ошибки
     */
    private showErrorDialog(options: {
        message: string;
        error: string;
        options: string[];
    }): Promise<string> {
        return new Promise((resolve) => {
            const modal = document.createElement('div');
            modal.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.5);
                backdrop-filter: blur(4px);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 10000;
                animation: fadeIn 0.2s ease;
            `;

            modal.innerHTML = `
                <div style="background: var(--app-bg-secondary); padding: 24px; border-radius: 16px; max-width: 360px; width: 90%; text-align: center; box-shadow: 0 20px 60px rgba(0,0,0,0.3);">
                    <div style="font-size: 32px; margin-bottom: 8px;">⚠️</div>
                    <h4 style="margin: 0 0 4px 0; color: var(--app-text-primary); font-size: 16px;">${options.message}</h4>
                    <p style="color: var(--app-text-tertiary); font-size: 13px; margin: 0 0 16px 0; word-break: break-word;">${options.error}</p>
                    <div style="display: flex; gap: 8px; flex-wrap: wrap; justify-content: center;">
                        ${options.options.map(opt => `
                            <button class="btn" style="padding: 8px 16px; font-size: 13px; min-width: 80px; ${opt === 'Отменить' ? 'background: var(--app-accent-danger);' : ''}" 
                                    onclick="this.closest('div[style]').parentElement.remove(); window._errorResolve('${opt}')">
                                ${opt}
                            </button>
                        `).join('')}
                    </div>
                </div>
            `;

            document.body.appendChild(modal);
            (window as any)._errorResolve = resolve;
        });
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let chatServiceInstance: ChatService | null = null;

/**
 * Получить экземпляр ChatService
 */
export function getChatService(): ChatService {
    if (!chatServiceInstance) {
        chatServiceInstance = ChatService.getInstance();
    }
    return chatServiceInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).ChatService = ChatService;
    (window as any).chatService = getChatService();
}

console.log('✅ ChatService v3.0.0 (TypeScript) загружен');
