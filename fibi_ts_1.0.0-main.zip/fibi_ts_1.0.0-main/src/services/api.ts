// ============================================
// src/services/api.ts
// Описание: Базовый API-клиент с JWT и sync_token
// Версия: 5.0.0 - TypeScript
// ============================================

import { getEventBus, EventBus } from '@core/event-bus';
import { getUserStore } from '@store/UserStore';

/**
 * Опции запроса
 */
export interface RequestOptions extends RequestInit {
    timeout?: number;
    retries?: number;
    retryDelay?: number;
    skipAuth?: boolean;
}

/**
 * Ответ с пагинацией
 */
export interface PaginatedResponse<T> {
    data: T[];
    total: number;
    page: number;
    limit: number;
    totalPages: number;
}

/**
 * Стандартный ответ API
 */
export interface ApiResponse<T = any> {
    success: boolean;
    data?: T;
    error?: string;
    message?: string;
    status?: number;
}

/**
 * Ошибка API
 */
export class ApiError extends Error {
    public status: number;
    public details: any;

    constructor(message: string, status: number = 500, details: any = null) {
        super(message);
        this.name = 'ApiError';
        this.status = status;
        this.details = details;

        // Восстанавливаем прототип для instanceof
        Object.setPrototypeOf(this, ApiError.prototype);
    }

    /**
     * Проверка, является ли ошибка клиентской (4xx)
     */
    isClientError(): boolean {
        return this.status >= 400 && this.status < 500;
    }

    /**
     * Проверка, является ли ошибка серверной (5xx)
     */
    isServerError(): boolean {
        return this.status >= 500 && this.status < 600;
    }

    /**
     * Проверка, является ли ошибка связанной с авторизацией
     */
    isAuthError(): boolean {
        return this.status === 401 || this.status === 403;
    }

    /**
     * Проверка, является ли ошибка связанной с таймаутом
     */
    isTimeoutError(): boolean {
        return this.status === 408 || this.message.includes('timeout');
    }

    /**
     * Проверка, является ли ошибка сетевой
     */
    isNetworkError(): boolean {
        return this.status === 0 || this.message.includes('network');
    }
}

/**
 * API Клиент
 */
export class ApiClient {
    private static instance: ApiClient | null = null;

    private baseUrl: string = '';
    private initData: string | null = null;
    private timeout: number = 30000;
    private retries: number = 3;
    private retryDelay: number = 1000;
    private jwtToken: string | null = null;
    private syncToken: string | null = null;
    private eventBus: EventBus;
    private _isRefreshing: boolean = false;
    private _refreshPromise: Promise<void> | null = null;

    private constructor() {
        this.eventBus = getEventBus();
        this.initFromTelegram();
        this.loadTokens();
    }

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): ApiClient {
        if (!ApiClient.instance) {
            ApiClient.instance = new ApiClient();
        }
        return ApiClient.instance;
    }

    // ==========================================
    // ИНИЦИАЛИЗАЦИЯ
    // ==========================================

    /**
     * Инициализировать из Telegram
     */
    private initFromTelegram(): void {
        const tg = (window as any).Telegram?.WebApp;
        this.initData = tg?.initData || null;

        if (!this.initData) {
            console.warn('⚠️ Telegram initData не найден');
        }
    }

    /**
     * Загрузить токены из хранилища
     */
    private loadTokens(): void {
        const userStore = getUserStore();

        // JWT через UserStore
        this.jwtToken = userStore.getJWT();

        // sync_token через BaseStore (без ID)
        const tempStore = new (window as any).BaseStore('temp');
        this.syncToken = tempStore.getSyncToken();

        if (this.syncToken) {
            console.log(`🔑 Найден sync_token: ${this.syncToken.substring(0, 8)}...`);
        } else {
            console.log('ℹ️ sync_token не найден');
        }
    }

    /**
     * Получить Telegram ID
     */
    private getTelegramId(): number | null {
        try {
            const tg = (window as any).Telegram?.WebApp;
            if (!tg) return null;

            const initData = tg.initData;
            if (initData) {
                const params = new URLSearchParams(initData);
                const userStr = params.get('user');
                if (userStr) {
                    try {
                        const user = JSON.parse(decodeURIComponent(userStr));
                        if (user?.id) return user.id;
                    } catch {
                        // ignore
                    }
                }
            }

            const user = tg.initDataUnsafe?.user;
            return user?.id || null;
        } catch {
            return null;
        }
    }

    /**
     * Обновить sync_token
     */
    private updateSyncToken(token: string | null): void {
        if (token) {
            const tempStore = new (window as any).BaseStore('temp');
            tempStore.saveSyncToken(token);
            this.syncToken = token;
            console.log(`🔄 sync_token обновлен: ${token.substring(0, 8)}...`);
        } else {
            const tempStore = new (window as any).BaseStore('temp');
            tempStore.clearSyncToken();
            this.syncToken = null;
        }
    }

    // ==========================================
    // БАЗОВЫЙ ЗАПРОС
    // ==========================================

    /**
     * Выполнить HTTP запрос
     */
    async request<T = any>(
        endpoint: string,
        options: RequestOptions = {}
    ): Promise<T> {
        // Загружаем свежие токены
        this.loadTokens();

        const url = endpoint.startsWith('http') ? endpoint : `/api${endpoint}`;

        // Подготавливаем заголовки
        const headers: Record<string, string> = {
            'Content-Type': 'application/json',
            'X-Telegram-Init-Data': this.initData || ''
        };

        if (this.jwtToken && !options.skipAuth) {
            headers['Authorization'] = `Bearer ${this.jwtToken}`;
        }

        if (this.syncToken) {
            headers['x-sync-token'] = this.syncToken;
            if (process.env.NODE_ENV === 'development') {
                console.log(`📤 Отправляем sync_token: ${this.syncToken.substring(0, 8)}...`);
            }
        }

        // Настройки запроса
        const timeout = options.timeout || this.timeout;
        const retries = options.retries ?? this.retries;
        const retryDelay = options.retryDelay || this.retryDelay;

        const fetchOptions: RequestInit = {
            method: options.method || 'GET',
            headers: {
                ...headers,
                ...(options.headers || {})
            },
            signal: AbortSignal.timeout(timeout)
        };

        // Добавляем тело если есть
        if (options.body && typeof options.body === 'object') {
            fetchOptions.body = JSON.stringify(options.body);
        }

        // Копируем остальные опции
        Object.assign(fetchOptions, options);

        let lastError: Error | null = null;

        // Пытаемся выполнить запрос с повторными попытками
        for (let attempt = 1; attempt <= retries; attempt++) {
            try {
                const response = await fetch(url, fetchOptions);

                // 304 Not Modified
                if (response.status === 304) {
                    return { success: true, cached: true, status: 304 } as T;
                }

                // Обработка ошибок авторизации
                if (response.status === 401 || response.status === 403) {
                    if (!options.skipAuth) {
                        console.warn(`⚠️ Ошибка аутентификации ${response.status}, пробуем обновить JWT...`);
                        await this.refreshAuth();
                        // Повторяем запрос с новым токеном
                        return this.request(endpoint, {
                            ...options,
                            skipAuth: true
                        });
                    }
                    throw new ApiError('Authentication failed', response.status);
                }

                // Парсим ответ
                const contentType = response.headers.get('content-type') || '';

                if (!response.ok) {
                    let errorMessage = `HTTP ${response.status}`;
                    let errorDetails = null;

                    if (contentType.includes('application/json')) {
                        try {
                            const errorData = await response.json();
                            errorMessage = errorData.error || errorData.message || errorMessage;
                            errorDetails = errorData;
                        } catch {
                            // ignore
                        }
                    } else {
                        try {
                            const text = await response.text();
                            if (text && text.length < 200) {
                                errorMessage = text;
                            }
                        } catch {
                            // ignore
                        }
                    }

                    throw new ApiError(errorMessage, response.status, errorDetails);
                }

                // Пустой ответ
                if (response.status === 204 || response.headers.get('content-length') === '0') {
                    return { success: true, status: 204 } as T;
                }

                // JSON ответ
                if (contentType.includes('application/json')) {
                    const data = await response.json();
                    return data as T;
                }

                // Другие типы ответов
                return response as any;

            } catch (err: any) {
                lastError = err;

                // Не повторяем для ошибок авторизации
                if (err instanceof ApiError && err.isClientError() && !err.isAuthError()) {
                    throw err;
                }

                // Повторяем для сетевых ошибок и таймаутов
                if (
                    attempt < retries &&
                    (err.name === 'AbortError' ||
                        err.name === 'TypeError' ||
                        err.message?.includes('network') ||
                        err.message?.includes('timeout'))
                ) {
                    const delay = retryDelay * Math.pow(2, attempt - 1);
                    console.log(`🔄 Повторная попытка ${attempt}/${retries} через ${delay}ms`);
                    await new Promise(resolve => setTimeout(resolve, delay));
                    continue;
                }

                break;
            }
        }

        console.error(`❌ API Error [${endpoint}]: Все попытки неудачны`, lastError);
        throw lastError || new ApiError('Request failed', 500);
    }

    // ==========================================
    // АУТЕНТИФИКАЦИЯ
    // ==========================================

    /**
     * Обновить авторизацию
     */
    private async refreshAuth(): Promise<void> {
        if (this._isRefreshing && this._refreshPromise) {
            return this._refreshPromise;
        }

        this._isRefreshing = true;
        this._refreshPromise = (async () => {
            try {
                // Пытаемся обновить через AuthService
                const authService = (window as any).authService;
                if (authService) {
                    const result = await authService.checkSubscription();
                    if (result?.jwtToken) {
                        const userStore = getUserStore();
                        userStore.saveJWT(result.jwtToken);
                        this.jwtToken = result.jwtToken;

                        if (result.syncToken) {
                            this.updateSyncToken(result.syncToken);
                        }

                        console.log('✅ JWT обновлен через AuthService');
                        return;
                    }
                }

                // Fallback: пытаемся получить из localStorage
                const userStore = getUserStore();
                const token = userStore.getJWT();
                if (token) {
                    this.jwtToken = token;
                    console.log('✅ JWT восстановлен из localStorage');
                    return;
                }

                throw new ApiError('Не удалось обновить JWT', 401);
            } finally {
                this._isRefreshing = false;
                this._refreshPromise = null;
            }
        })();

        return this._refreshPromise;
    }

    // ==========================================
    // ОБЕРТКИ ДЛЯ HTTP МЕТОДОВ
    // ==========================================

    /**
     * GET запрос
     */
    async get<T = any>(endpoint: string, options: RequestOptions = {}): Promise<T> {
        return this.request<T>(endpoint, {
            ...options,
            method: 'GET'
        });
    }

    /**
     * POST запрос
     */
    async post<T = any>(endpoint: string, body?: any, options: RequestOptions = {}): Promise<T> {
        return this.request<T>(endpoint, {
            ...options,
            method: 'POST',
            body
        });
    }

    /**
     * PUT запрос
     */
    async put<T = any>(endpoint: string, body?: any, options: RequestOptions = {}): Promise<T> {
        return this.request<T>(endpoint, {
            ...options,
            method: 'PUT',
            body
        });
    }

    /**
     * PATCH запрос
     */
    async patch<T = any>(endpoint: string, body?: any, options: RequestOptions = {}): Promise<T> {
        return this.request<T>(endpoint, {
            ...options,
            method: 'PATCH',
            body
        });
    }

    /**
     * DELETE запрос
     */
    async delete<T = any>(endpoint: string, options: RequestOptions = {}): Promise<T> {
        return this.request<T>(endpoint, {
            ...options,
            method: 'DELETE'
        });
    }

    // ==========================================
    // СТРИМИНГ
    // ==========================================

    /**
     * Стриминг ответа с SSE
     */
    async stream(
        endpoint: string,
        body: any,
        onChunk: (chunk: string, accumulated: string) => void
    ): Promise<string> {
        this.loadTokens();

        const url = endpoint.startsWith('http') ? endpoint : `/api${endpoint}`;

        const headers: Record<string, string> = {
            'Content-Type': 'application/json',
            'X-Telegram-Init-Data': this.initData || ''
        };

        if (this.jwtToken) {
            headers['Authorization'] = `Bearer ${this.jwtToken}`;
        }

        if (this.syncToken) {
            headers['x-sync-token'] = this.syncToken;
        }

        const response = await fetch(url, {
            method: 'POST',
            headers,
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            const text = await response.text();
            throw new ApiError(
                `Stream error ${response.status}: ${text.substring(0, 200)}`,
                response.status
            );
        }

        const reader = response.body?.getReader();
        if (!reader) {
            throw new ApiError('Stream reader not available', 500);
        }

        const decoder = new TextDecoder('utf-8');
        let buffer = '';
        let accumulatedText = '';

        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';

                for (const line of lines) {
                    const trimmedLine = line.trim();
                    if (trimmedLine.startsWith('data: ')) {
                        const jsonStr = trimmedLine.slice(6).trim();
                        if (jsonStr === '[DONE]') continue;

                        try {
                            const data = JSON.parse(jsonStr);
                            const content = data.choices?.[0]?.delta?.content;
                            if (content) {
                                accumulatedText += content;
                                onChunk(content, accumulatedText);
                            }
                        } catch {
                            // Игнорируем невалидный JSON
                        }
                    }
                }
            }
        } catch (err: any) {
            console.error('Stream reading error:', err);
            throw err;
        }

        return accumulatedText;
    }

    // ==========================================
    // ЗАГРУЗКА ФАЙЛОВ
    // ==========================================

    /**
     * Загрузка файла (multipart/form-data)
     */
    async uploadFile(
        endpoint: string,
        file: File,
        fieldName: string = 'file',
        options: RequestOptions = {}
    ): Promise<any> {
        this.loadTokens();

        const url = endpoint.startsWith('http') ? endpoint : `/api${endpoint}`;

        const formData = new FormData();
        formData.append(fieldName, file);

        const headers: Record<string, string> = {
            'X-Telegram-Init-Data': this.initData || ''
        };

        if (this.jwtToken) {
            headers['Authorization'] = `Bearer ${this.jwtToken}`;
        }

        if (this.syncToken) {
            headers['x-sync-token'] = this.syncToken;
        }

        const fetchOptions: RequestInit = {
            method: 'POST',
            headers,
            body: formData
        };

        if (options.timeout) {
            fetchOptions.signal = AbortSignal.timeout(options.timeout);
        }

        const response = await fetch(url, fetchOptions);

        if (!response.ok) {
            const text = await response.text();
            throw new ApiError(`Upload error ${response.status}: ${text}`, response.status);
        }

        return response.json();
    }

    // ==========================================
    // ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    // ==========================================

    /**
     * Установить JWT токен
     */
    setJWT(token: string | null): void {
        this.jwtToken = token;
        if (token) {
            const userStore = getUserStore();
            userStore.saveJWT(token);
        }
    }

    /**
     * Установить sync_token
     */
    setSyncToken(token: string | null): void {
        if (token) {
            this.updateSyncToken(token);
        } else {
            this.updateSyncToken(null);
        }
    }

    /**
     * Получить текущий JWT
     */
    getJWT(): string | null {
        return this.jwtToken;
    }

    /**
     * Получить текущий sync_token
     */
    getSyncToken(): string | null {
        return this.syncToken;
    }

    /**
     * Проверить, авторизован ли клиент
     */
    isAuthenticated(): boolean {
        return !!this.jwtToken;
    }

    /**
     * Установить базовый URL
     */
    setBaseUrl(url: string): void {
        this.baseUrl = url;
    }

    /**
     * Установить таймаут
     */
    setTimeout(ms: number): void {
        this.timeout = ms;
    }

    /**
     * Установить количество повторных попыток
     */
    setRetries(count: number): void {
        this.retries = Math.max(0, count);
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let apiClientInstance: ApiClient | null = null;

/**
 * Получить экземпляр ApiClient
 */
export function getApiClient(): ApiClient {
    if (!apiClientInstance) {
        apiClientInstance = ApiClient.getInstance();
    }
    return apiClientInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).ApiClient = ApiClient;
    (window as any).ApiError = ApiError;
    (window as any).apiClient = getApiClient();
}

console.log('✅ ApiClient v5.0.0 (TypeScript) загружен');
