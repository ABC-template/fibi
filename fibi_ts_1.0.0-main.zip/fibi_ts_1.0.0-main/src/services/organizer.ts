// ============================================
// src/services/organizer.ts
// Описание: API для органайзера (напоминания, трекеры)
// Версия: 3.0.0 - TypeScript
// ============================================

import { getApiClient } from './api';
import { getOrganizerStore, Reminder, Tracker, TrackerLog } from '@store/OrganizerStore';
import { getUserStore } from '@store/UserStore';

/**
 * Результат получения трекеров
 */
export interface TrackersResult {
    trackers: Tracker[];
    logs: TrackerLog[];
}

/**
 * Сервис органайзера
 */
export class OrganizerService {
    private static instance: OrganizerService | null = null;

    private apiClient = getApiClient();
    private organizerStore = getOrganizerStore();
    private userStore = getUserStore();

    private constructor() {}

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): OrganizerService {
        if (!OrganizerService.instance) {
            OrganizerService.instance = new OrganizerService();
        }
        return OrganizerService.instance;
    }

    // ==========================================
    // НАПОМИНАНИЯ
    // ==========================================

    /**
     * Получить напоминания
     */
    async getReminders(topicId: string | null = null): Promise<Reminder[]> {
        try {
            let url = '/organizer/reminders/get';
            if (topicId) {
                url += `?topicId=${encodeURIComponent(topicId)}`;
            }

            const data = await this.apiClient.get<{ success: boolean; data: Reminder[] }>(url);

            if (data.success && data.data) {
                this.organizerStore.setReminders(data.data);
                return data.data;
            }

            return [];
        } catch (err) {
            console.error('Get reminders error:', err);
            return this.organizerStore.getRemindersByTopic(topicId || '');
        }
    }

    /**
     * Создать напоминание
     */
    async createReminder(topicId: string, taskText: string, triggerAt: string): Promise<Reminder | null> {
        try {
            const data = await this.apiClient.post<{ success: boolean; data: Reminder }>(
                '/organizer/reminders/create',
                {
                    topicId: topicId,
                    taskText: taskText,
                    triggerAt: triggerAt
                }
            );

            if (data.success && data.data) {
                this.organizerStore.addReminder(data.data);
                return data.data;
            }

            return null;
        } catch (err) {
            console.error('Create reminder error:', err);
            return null;
        }
    }

    /**
     * Удалить напоминание
     */
    async deleteReminder(id: string): Promise<boolean> {
        try {
            const data = await this.apiClient.post<{ success: boolean }>(
                '/organizer/reminders/delete',
                { id }
            );

            if (data.success) {
                this.organizerStore.deleteReminder(id);
                return true;
            }

            return false;
        } catch (err) {
            console.error('Delete reminder error:', err);
            return false;
        }
    }

    // ==========================================
    // ТРЕКЕРЫ
    // ==========================================

    /**
     * Получить трекеры и логи
     */
    async getTrackers(topicId: string | null = null): Promise<TrackersResult> {
        try {
            let url = '/organizer/trackers/get';
            if (topicId) {
                url += `?topicId=${encodeURIComponent(topicId)}`;
            }

            const data = await this.apiClient.get<{
                success: boolean;
                data: { trackers: Tracker[]; logs: TrackerLog[] };
            }>(url);

            if (data.success && data.data) {
                this.organizerStore.setTrackers(
                    data.data.trackers || [],
                    data.data.logs || []
                );
                return data.data;
            }

            return {
                trackers: this.organizerStore.getAllTrackers(),
                logs: this.organizerStore.getAllTrackerLogs()
            };
        } catch (err) {
            console.error('Get trackers error:', err);
            return {
                trackers: this.organizerStore.getAllTrackers(),
                logs: this.organizerStore.getAllTrackerLogs()
            };
        }
    }

    /**
     * Создать трекер
     */
    async createTracker(topicId: string, title: string, settings: Record<string, any> = {}): Promise<Tracker | null> {
        try {
            const data = await this.apiClient.post<{ success: boolean; data: Tracker }>(
                '/organizer/trackers/create',
                {
                    topicId: topicId,
                    title: title,
                    settings: settings
                }
            );

            if (data.success && data.data) {
                this.organizerStore.addTracker(data.data);
                return data.data;
            }

            return null;
        } catch (err) {
            console.error('Create tracker error:', err);
            return null;
        }
    }

    /**
     * Добавить лог трекера
     */
    async addTrackerLog(
        trackerId: string,
        value: string,
        noteText: string | null = null,
        loggedDate: string | null = null
    ): Promise<TrackerLog | null> {
        try {
            const data = await this.apiClient.post<{ success: boolean; data: TrackerLog }>(
                '/organizer/trackers/add-log',
                {
                    trackerId: trackerId,
                    value: value,
                    noteText: noteText,
                    loggedDate: loggedDate || new Date().toISOString()
                }
            );

            if (data.success && data.data) {
                this.organizerStore.addTrackerLog(data.data);
                return data.data;
            }

            return null;
        } catch (err) {
            console.error('Add tracker log error:', err);
            return null;
        }
    }

    /**
     * Удалить лог трекера
     */
    async deleteTrackerLog(id: string): Promise<boolean> {
        try {
            const data = await this.apiClient.post<{ success: boolean }>(
                '/organizer/trackers/delete-log',
                { id }
            );

            if (data.success) {
                this.organizerStore.deleteTrackerLog(id);
                return true;
            }

            return false;
        } catch (err) {
            console.error('Delete tracker log error:', err);
            return false;
        }
    }

    /**
     * Удалить трекер
     */
    async deleteTracker(id: string): Promise<boolean> {
        try {
            const data = await this.apiClient.post<{ success: boolean }>(
                '/organizer/trackers/delete',
                { id }
            );

            if (data.success) {
                this.organizerStore.deleteTracker(id);
                return true;
            }

            return false;
        } catch (err) {
            console.error('Delete tracker error:', err);
            return false;
        }
    }

    /**
     * Получить логи для трекера
     */
    getLogsForTracker(trackerId: string): TrackerLog[] {
        return this.organizerStore.getLogsForTracker(trackerId);
    }

    /**
     * Получить трекеры по теме
     */
    getTrackersByTopic(topicId: string): Tracker[] {
        return this.organizerStore.getTrackersByTopic(topicId);
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let organizerServiceInstance: OrganizerService | null = null;

/**
 * Получить экземпляр OrganizerService
 */
export function getOrganizerService(): OrganizerService {
    if (!organizerServiceInstance) {
        organizerServiceInstance = OrganizerService.getInstance();
    }
    return organizerServiceInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).OrganizerService = OrganizerService;
    (window as any).organizerService = getOrganizerService();
}

console.log('✅ OrganizerService v3.0.0 (TypeScript) загружен');
