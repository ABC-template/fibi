// ============================================
// src/services/messages.ts
// Описание: Работа с сообщениями (HARD DELETE)
// Версия: 4.0.0 - TypeScript
// ============================================

import { getApiClient } from './api';
import { getChatStore, Message } from '@store/ChatStore';
import { getUserStore } from '@store/UserStore';
import { getChatService } from './chats';

/**
 * Сервис для работы с сообщениями
 */
export class MessageService {
    private static instance: MessageService | null = null;

    private apiClient = getApiClient();
    private chatStore = getChatStore();
    private userStore = getUserStore();
    private chatService = getChatService();

    private constructor() {}

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): MessageService {
        if (!MessageService.instance) {
            MessageService.instance = new MessageService();
        }
        return MessageService.instance;
    }

    // ==========================================
    // ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    // ==========================================

    /**
     * Сохранить sync_token после действия
     */
    private saveSyncToken(syncToken: string | null): void {
        if (syncToken) {
            const tempStore = new (window as any).BaseStore('temp');
            tempStore.saveSyncToken(syncToken);
            console.log(`✅ sync_token обновлен после действия: ${syncToken.substring(0, 8)}...`);
        }
    }

    // ==========================================
    // ОТПРАВКА СООБЩЕНИЯ
    // ==========================================

    /**
     * Отправить сообщение
     */
    async sendMessage(
        chatId: string,
        text: string,
        type: Message['type'],
        options: {
            id?: string;
            isFavorite?: boolean;
            created_at?: string;
        } = {}
    ): Promise<Message | null> {
        if (!navigator.onLine) {
            console.warn('⚠️ Нет интернета, сообщение сохраняется локально');
        }

        const found = this.chatStore.findChatById(chatId);
        if (!found) {
            console.error(`❌ Чат ${chatId} не найден`);
            return null;
        }

        const chat = found.chat;

        // Если сообщение уже существует (синхронизация)
        if (options.id) {
            console.log(`📤 [sendMessage] Сообщение уже существует (ID: ${options.id})`);

            const existingMsg = chat.messages.find(m => m.id === options.id);
            if (!existingMsg) {
                console.error(`❌ [sendMessage] Сообщение с ID ${options.id} не найдено в чате`);
                return null;
            }

            // Синхронизируем с облаком
            if (this.userStore.canSync()) {
                if (!chat.synced) {
                    console.log(`📤 [sendMessage] Создаем чат на сервере...`);
                    const created = await this.chatService.createChat(
                        chat.topic,
                        chat.title,
                        {
                            maxContext: chat.maxContext,
                            userRenamed: chat.userRenamed,
                            firstMessage: existingMsg,
                            existingChatId: chat.id
                        }
                    );
                    if (created) {
                        chat.synced = true;
                    }
                }

                try {
                    const result = await this.apiClient.post('/chats/actions/message', {
                        action: 'new_message',
                        chatId: chatId,
                        message: {
                            id: existingMsg.id,
                            text: existingMsg.text,
                            type: existingMsg.type,
                            isFavorite: existingMsg.isFavorite || false
                        }
                    });

                    this.saveSyncToken(result.syncToken);

                    if (result.synced || result.success) {
                        console.log(`✅ [sendMessage] Сообщение ${existingMsg.id} синхронизировано`);
                    }
                } catch (err) {
                    console.error(`❌ [sendMessage] Ошибка синхронизации:`, err);
                }
            }

            return existingMsg;
        }

        // Новое сообщение
        console.log(`📤 [sendMessage] Новое сообщение, создаем локально`);

        const messageId = options.id || this.chatStore.generateId();
        const isFirstMessage = !this.chatStore.hasRealMessages(chat);

        const message = this.chatStore.addMessage(chatId, text, type, {
            id: messageId,
            isFavorite: options.isFavorite || false,
            created_at: options.created_at || new Date().toISOString()
        });

        if (!message) return null;

        // Синхронизируем с облаком
        if (this.userStore.canSync()) {
            if (!chat.synced || isFirstMessage) {
                console.log(`📤 [sendMessage] Создаем чат ${chat.id} на сервере...`);

                const created = await this.chatService.createChat(
                    chat.topic,
                    chat.title,
                    {
                        maxContext: chat.maxContext,
                        userRenamed: chat.userRenamed,
                        firstMessage: message,
                        existingChatId: chat.id
                    }
                );

                if (created) {
                    chat.synced = true;
                }
            }

            try {
                const result = await this.apiClient.post('/chats/actions/message', {
                    action: 'new_message',
                    chatId: chatId,
                    message: {
                        id: message.id,
                        text: message.text,
                        type: message.type,
                        isFavorite: message.isFavorite || false
                    }
                });

                this.saveSyncToken(result.syncToken);

                if (result.synced || result.success) {
                    console.log(`✅ [sendMessage] Сообщение ${message.id} синхронизировано`);
                }
            } catch (err) {
                console.error(`❌ [sendMessage] Ошибка синхронизации:`, err);
            }
        }

        return message;
    }

    // ==========================================
    // УДАЛЕНИЕ СООБЩЕНИЯ
    // ==========================================

    /**
     * Удалить сообщение
     */
    async deleteMessage(chatId: string, messageId: string): Promise<boolean> {
        const deleted = this.chatStore.deleteMessage(chatId, messageId);
        if (!deleted) return false;

        if (this.userStore.canSync()) {
            try {
                const result = await this.apiClient.post('/chats/mutations/delete-with-confirm', {
                    action: 'delete_message_with_confirm',
                    messageId: messageId
                });

                this.saveSyncToken(result.syncToken);

                if (result.success) {
                    console.log(`✅ [deleteMessage] Сообщение ${messageId} удалено на сервере (HARD DELETE)`);
                } else {
                    console.warn(`⚠️ [deleteMessage] Сообщение ${messageId} удалено локально, но не на сервере`);
                }
            } catch (err) {
                console.error(`❌ [deleteMessage] Ошибка синхронизации:`, err);
            }
        }

        return true;
    }

    // ==========================================
    // ИЗБРАННОЕ
    // ==========================================

    /**
     * Переключить избранное
     */
    async toggleFavorite(chatId: string, messageId: string): Promise<Message | null> {
        const msg = this.chatStore.toggleFavorite(chatId, messageId);
        if (!msg) return null;

        if (this.userStore.canSync()) {
            try {
                const result = await this.apiClient.post('/chats/actions/favorite', {
                    action: 'favorite_message',
                    chatId: chatId,
                    messageId: messageId,
                    isFavorite: msg.isFavorite
                });

                this.saveSyncToken(result.syncToken);

                if (result.success) {
                    console.log(`✅ [toggleFavorite] Избранное ${messageId} синхронизировано`);
                }
            } catch (err) {
                console.error(`❌ [toggleFavorite] Ошибка синхронизации:`, err);
            }
        }

        return msg;
    }

    /**
     * Получить избранные сообщения
     */
    getFavorites(): (Message & { chat_id: string; chat_title: string; topic: string })[] {
        return this.chatStore.getFavorites();
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let messageServiceInstance: MessageService | null = null;

/**
 * Получить экземпляр MessageService
 */
export function getMessageService(): MessageService {
    if (!messageServiceInstance) {
        messageServiceInstance = MessageService.getInstance();
    }
    return messageServiceInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).MessageService = MessageService;
    (window as any).messageService = getMessageService();
}

console.log('✅ MessageService v4.0.0 (TypeScript) загружен');
