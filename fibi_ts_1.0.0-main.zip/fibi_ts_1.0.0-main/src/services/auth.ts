// ============================================
// src/services/auth.ts
// Описание: Сервис авторизации (с JWT и авто-рефрешем)
// Версия: 5.0.0 - TypeScript
// ============================================

import { getApiClient } from './api';
import { getUserStore } from '@store/UserStore';
import { getEventBus } from '@core/event-bus';

/**
 * Результат проверки подписки
 */
export interface AuthResult {
    isMember: boolean;
    role: 'trial' | 'premium' | 'admin' | 'creator' | 'guest';
    dailyLimit: number;
    syncEnabled: boolean;
    syncToken: string | null;
    dataDeadline: string | null;
    jwtToken: string | null;
    authUserId: string | null;
    isNewUser: boolean;
    serverModels: Record<string, boolean>;
}

/**
 * Сервис авторизации
 */
export class AuthService {
    private static instance: AuthService | null = null;

    private apiClient: ReturnType<typeof getApiClient>;
    private userStore: ReturnType<typeof getUserStore>;
    private eventBus: ReturnType<typeof getEventBus>;
    private jwtToken: string | null = null;
    private authUserId: string | null = null;
    private syncToken: string | null = null;
    private refreshTimeout: ReturnType<typeof setTimeout> | null = null;
    private readonly SESSION_TIMEOUT = 25 * 60 * 1000;
    private readonly REFRESH_INTERVAL = 55 * 60 * 1000;

    private constructor() {
        this.apiClient = getApiClient();
        this.userStore = getUserStore();
        this.eventBus = getEventBus();

        this.loadTokens();
        this.startRefreshTimer();
    }

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): AuthService {
        if (!AuthService.instance) {
            AuthService.instance = new AuthService();
        }
        return AuthService.instance;
    }

    // ==========================================
    // ИНИЦИАЛИЗАЦИЯ
    // ==========================================

    /**
     * Загрузить токены
     */
    private loadTokens(): void {
        this.jwtToken = this.userStore.getJWT();
        this.authUserId = localStorage.getItem('auth_user_id');

        const tempStore = new (window as any).BaseStore('temp');
        this.syncToken = tempStore.getSyncToken();
    }

    /**
     * Получить ID пользователя из Telegram
     */
    private getUserId(): number | null {
        try {
            const tg = (window as any).Telegram?.WebApp;
            const user = tg?.initDataUnsafe?.user;
            return user?.id || null;
        } catch {
            return null;
        }
    }

    // ==========================================
    // ТАЙМЕР АВТО-ОБНОВЛЕНИЯ
    // ==========================================

    /**
     * Запустить таймер авто-обновления
     */
    private startRefreshTimer(): void {
        if (this.refreshTimeout) {
            clearTimeout(this.refreshTimeout);
        }

        this.refreshTimeout = setTimeout(() => {
            this.refreshJWT();
        }, this.REFRESH_INTERVAL);
    }

    /**
     * Обновить JWT
     */
    private async refreshJWT(): Promise<void> {
        try {
            console.log('🔄 Автоматический рефреш JWT...');
            const result = await this.checkSubscription();

            if (result?.jwtToken) {
                this.jwtToken = result.jwtToken;
                this.authUserId = result.authUserId;
                this.userStore.saveJWT(result.jwtToken);
                console.log('✅ JWT обновлен');

                // Уведомляем о обновлении
                this.eventBus.emit('auth:token_refreshed', { jwt: result.jwtToken });
            }
        } catch (err) {
            console.error('❌ Ошибка рефреша JWT:', err);
        } finally {
            this.startRefreshTimer();
        }
    }

    // ==========================================
    // АУТЕНТИФИКАЦИЯ
    // ==========================================

    /**
     * Проверить подписку пользователя
     */
    async checkSubscription(): Promise<AuthResult> {
        try {
            const data = await this.apiClient.get<AuthResult & { error?: string }>('/auth/check');

            if (data.error) {
                console.error('Ошибка проверки подписки:', data.error);
                return this.fallbackToOffline();
            }

            // Сохраняем токены
            if (data.jwtToken) {
                this.jwtToken = data.jwtToken;
                this.userStore.saveJWT(data.jwtToken);
                console.log('✅ JWT токен сохранен');
            }

            if (data.authUserId) {
                this.authUserId = data.authUserId;
                localStorage.setItem('auth_user_id', data.authUserId);
            }

            if (data.syncToken) {
                console.log(`🔑 sync_token получен с сервера: ${data.syncToken.substring(0, 8)}...`);
                this.syncToken = data.syncToken;

                const tempStore = new (window as any).BaseStore('temp');
                tempStore.saveSyncToken(data.syncToken);
            }

            // Обновляем UserStore
            this.userStore.setRole(
                data.role || 'trial',
                data.dailyLimit || 5,
                data.syncEnabled === true
            );

            if (data.userId) {
                this.userStore.userId = data.userId as any;
            }

            // Сохраняем дополнительные данные
            if (data.dataDeadline) {
                localStorage.setItem('data_deadline', data.dataDeadline);
            } else {
                localStorage.removeItem('data_deadline');
            }

            localStorage.setItem('user_role', data.role || 'trial');
            localStorage.setItem('session_active', 'true');
            localStorage.setItem('session_start', String(Date.now()));

            this.userStore.save();

            // Отправляем событие
            this.eventBus.emit('auth:checked', data);

            return {
                isMember: data.isMember !== false,
                role: data.role || 'trial',
                dailyLimit: data.dailyLimit || 5,
                syncEnabled: data.syncEnabled === true,
                syncToken: data.syncToken || null,
                dataDeadline: data.dataDeadline || null,
                jwtToken: data.jwtToken || null,
                authUserId: data.authUserId || null,
                isNewUser: data.isNewUser || false,
                serverModels: data.serverModels || {}
            };

        } catch (err) {
            console.error('Auth check error:', err);
            return this.fallbackToOffline();
        }
    }

    /**
     * Проверить, нужно ли полное обновление данных
     */
    needFullReload(serverToken: string | null): boolean {
        let localToken: string | null = null;
        const tempStore = new (window as any).BaseStore('temp');
        localToken = tempStore.getSyncToken();

        console.log(
            `🔍 needFullReload: localToken=${localToken ? localToken.substring(0, 8) + '...' : 'null'}, ` +
            `serverToken=${serverToken ? serverToken.substring(0, 8) + '...' : 'null'}`
        );

        if (!localToken) {
            console.log('🔄 Нет локального sync_token → полная загрузка');
            return true;
        }

        if (!serverToken) {
            console.log('⚠️ Нет серверного sync_token → полная загрузка');
            return true;
        }

        if (serverToken !== localToken) {
            console.log(`🔄 sync_token не совпадает: ${localToken.substring(0, 8)} → ${serverToken.substring(0, 8)}`);
            return true;
        }

        console.log('✅ sync_token совпадает → используем кеш');
        return false;
    }

    /**
     * Проверить активность сессии
     */
    checkSession(): 'new_session' | 'current_session' {
        const sessionStart = parseInt(localStorage.getItem('session_start') || '0');
        const isActive = localStorage.getItem('session_active') === 'true';
        const isExpired = (Date.now() - sessionStart) > this.SESSION_TIMEOUT;

        if (!isActive || isExpired) {
            localStorage.setItem('session_active', 'true');
            localStorage.setItem('session_start', String(Date.now()));
            return 'new_session';
        }
        return 'current_session';
    }

    // ==========================================
    // ВЫХОД ИЗ СИСТЕМЫ
    // ==========================================

    /**
     * Выйти из системы
     */
    logout(): void {
        this.jwtToken = null;
        this.authUserId = null;
        this.syncToken = null;

        this.userStore.clearJWT();

        const tempStore = new (window as any).BaseStore('temp');
        tempStore.clearSyncToken();

        localStorage.removeItem('auth_user_id');
        localStorage.removeItem('session_active');

        if (this.refreshTimeout) {
            clearTimeout(this.refreshTimeout);
            this.refreshTimeout = null;
        }

        // Отключаем синхронизацию
        const syncService = (window as any).syncService;
        if (syncService) {
            syncService.unsubscribe();
        }

        this.eventBus.emit('auth:logout', {});
        console.log('👋 Выход выполнен');
    }

    // ==========================================
    // ОФЛАЙН-РЕЖИМ
    // ==========================================

    /**
     * Получить данные в офлайн-режиме
     */
    private fallbackToOffline(): AuthResult {
        const isCreator = this.userStore.isCreator;

        if (isCreator) {
            this.userStore.setRole('creator', 9999, true);
            this.userStore.save();

            return {
                isMember: true,
                role: 'creator',
                dailyLimit: 9999,
                syncEnabled: true,
                syncToken: this.syncToken || null,
                dataDeadline: localStorage.getItem('data_deadline') || null,
                jwtToken: this.jwtToken || null,
                authUserId: localStorage.getItem('auth_user_id') || null,
                isNewUser: false,
                serverModels: {}
            };
        }

        const savedRole = localStorage.getItem('user_role') as any;
        if (savedRole === 'admin' || savedRole === 'creator') {
            this.userStore.setRole(savedRole, 9999, true);
            this.userStore.save();

            return {
                isMember: true,
                role: savedRole,
                dailyLimit: 9999,
                syncEnabled: true,
                syncToken: this.syncToken || null,
                dataDeadline: localStorage.getItem('data_deadline') || null,
                jwtToken: this.jwtToken || null,
                authUserId: localStorage.getItem('auth_user_id') || null,
                isNewUser: false,
                serverModels: {}
            };
        }

        this.userStore.setRole('guest', 0, false);
        this.userStore.save();

        return {
            isMember: false,
            role: 'guest',
            dailyLimit: 0,
            syncEnabled: false,
            syncToken: null,
            dataDeadline: null,
            jwtToken: null,
            authUserId: null,
            isNewUser: false,
            serverModels: {}
        };
    }

    // ==========================================
    // ГЕТТЕРЫ
    // ==========================================

    /**
     * Получить JWT токен
     */
    getJWT(): string | null {
        return this.jwtToken || this.userStore.getJWT();
    }

    /**
     * Получить ID пользователя в Auth
     */
    getAuthUserId(): string | null {
        return this.authUserId || localStorage.getItem('auth_user_id') || null;
    }

    /**
     * Получить sync_token
     */
    getSyncToken(): string | null {
        const tempStore = new (window as any).BaseStore('temp');
        return tempStore.getSyncToken();
    }

    /**
     * Получить статистику пользователя
     */
    async getUserStats(): Promise<any> {
        try {
            const data = await this.apiClient.get('/users/stats');
            if (data.success && data.stats) {
                return data.stats;
            }
            return null;
        } catch (err) {
            console.error('Get user stats error:', err);
            return null;
        }
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let authServiceInstance: AuthService | null = null;

/**
 * Получить экземпляр AuthService
 */
export function getAuthService(): AuthService {
    if (!authServiceInstance) {
        authServiceInstance = AuthService.getInstance();
    }
    return authServiceInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).AuthService = AuthService;
    (window as any).authService = getAuthService();
}

console.log('✅ AuthService v5.0.0 (TypeScript) загружен');
