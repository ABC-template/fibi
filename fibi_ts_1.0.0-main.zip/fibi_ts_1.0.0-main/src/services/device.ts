// ============================================
// src/services/device.ts
// Описание: Управление устройствами и fingerprint
// Версия: 2.0.0 - TypeScript
// ============================================

import { getApiClient } from './api';
import { getUserStore } from '@store/UserStore';

/**
 * Данные устройства
 */
export interface DeviceInfo {
    fingerprint: string;
    signedFingerprint?: string;
    deviceType: string;
    platform: string;
    isTelegramWebApp: boolean;
}

/**
 * Сервис устройств
 */
export class DeviceService {
    private static instance: DeviceService | null = null;

    private apiClient = getApiClient();
    private userStore = getUserStore();

    private constructor() {}

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): DeviceService {
        if (!DeviceService.instance) {
            DeviceService.instance = new DeviceService();
        }
        return DeviceService.instance;
    }

    // ==========================================
    // ГЕНЕРАЦИЯ FINGERPRINT
    // ==========================================

    /**
     * Генерировать уникальный fingerprint
     */
    generateFingerprint(): DeviceInfo {
        const tg = (window as any).Telegram?.WebApp;
        const user = tg?.initDataUnsafe?.user;

        const components = [
            user?.id || 'unknown',
            navigator.userAgent || 'unknown',
            tg?.platform || 'unknown',
            navigator.language || 'unknown',
            navigator.hardwareConcurrency || 'unknown',
            screen.width + 'x' + screen.height,
            screen.colorDepth || 'unknown',
            (navigator as any).deviceMemory || 'unknown',
            tg?.version || 'unknown',
            tg?.isExpanded || false,
            new Date().getTimezoneOffset()
        ];

        const str = components.join('|');
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            hash = ((hash << 5) - hash) + str.charCodeAt(i);
            hash = hash & hash;
        }

        const isTelegramWebApp = !!tg?.initData;
        const platform = tg?.platform || 'web';
        const deviceType = isTelegramWebApp ? `tg_${platform}` : 'web';

        const fingerprint = `device_${user?.id}_${Math.abs(hash)}_${deviceType}`;

        return {
            fingerprint,
            deviceType,
            platform,
            isTelegramWebApp
        };
    }

    /**
     * Получить сохраненный fingerprint
     */
    getStoredFingerprint(): string | null {
        // Проверяем UserStore
        const stored = this.userStore.getDeviceFingerprint();
        if (stored) return stored;

        // Проверяем localStorage
        const saved = localStorage.getItem('device_fingerprint');
        if (saved) return saved;

        // Генерируем новый
        const { fingerprint } = this.generateFingerprint();
        localStorage.setItem('device_fingerprint', fingerprint);
        return fingerprint;
    }

    /**
     * Получить подписанный fingerprint
     */
    getSignedFingerprint(): string | null {
        const stored = this.userStore.getDeviceFingerprint();
        if (stored) return stored;

        const signed = localStorage.getItem('device_fingerprint_signed');
        if (signed) return signed;

        return this.getStoredFingerprint();
    }

    // ==========================================
    // РЕГИСТРАЦИЯ
    // ==========================================

    /**
     * Зарегистрировать устройство на сервере
     */
    async register(): Promise<boolean> {
        if (!this.userStore.canSync()) {
            console.log('⏭️ Синхронизация отключена, устройство не регистрируется');
            return false;
        }

        const { fingerprint, deviceType, platform } = this.generateFingerprint();
        const initData = (window as any).Telegram?.WebApp?.initData;

        if (!initData) {
            console.error('❌ Нет initData для регистрации устройства');
            return false;
        }

        try {
            console.log('📤 Отправляем запрос на регистрацию устройства...');

            const data = await this.apiClient.post<{
                success: boolean;
                signedFingerprint?: string;
                isNew: boolean;
            }>('/users/register-device', {
                deviceFingerprint: fingerprint,
                deviceType: deviceType,
                platform: platform
            });

            if (data.success) {
                if (data.signedFingerprint) {
                    localStorage.setItem('device_fingerprint_signed', data.signedFingerprint);
                    this.userStore.setDeviceFingerprint(
                        fingerprint,
                        data.signedFingerprint,
                        deviceType,
                        platform
                    );
                }

                console.log(data.isNew ? '🆕 Новое устройство зарегистрировано' : '🔄 Устройство уже зарегистрировано');
                return true;
            }

            console.error('❌ Ошибка регистрации устройства');
            return false;
        } catch (err) {
            console.error('❌ Ошибка регистрации устройства:', err);
            return false;
        }
    }

    /**
     * Обновить устройство
     */
    async updateDevice(): Promise<boolean> {
        // Просто перерегистрируем
        return this.register();
    }

    /**
     * Проверить, зарегистрировано ли устройство
     */
    isRegistered(): boolean {
        return !!this.userStore.getDeviceFingerprint();
    }

    /**
     * Получить информацию об устройстве
     */
    getDeviceInfo(): DeviceInfo {
        return this.generateFingerprint();
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let deviceServiceInstance: DeviceService | null = null;

/**
 * Получить экземпляр DeviceService
 */
export function getDeviceService(): DeviceService {
    if (!deviceServiceInstance) {
        deviceServiceInstance = DeviceService.getInstance();
    }
    return deviceServiceInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).DeviceService = DeviceService;
    (window as any).deviceService = getDeviceService();
}

console.log('✅ DeviceService v2.0.0 (TypeScript) загружен');
