// ============================================
// src/utils/validators.ts
// Описание: Клиентские валидации
// Версия: 2.0.0 - TypeScript
// ============================================

/**
 * Проверка UUID
 */
export function isValidUUID(uuid: string | null | undefined): boolean {
    if (!uuid || typeof uuid !== 'string') return false;
    const regex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    return regex.test(uuid);
}

/**
 * Проверка топика
 */
export function isValidTopic(topic: string | null | undefined): boolean {
    const allowed = ['code', 'creative', 'fast', 'kitchen', 'analytics'] as const;
    return allowed.includes(topic as any);
}

/**
 * Проверка длины сообщения
 */
export function isValidMessageLength(text: string | null | undefined, maxLength: number = 10000): boolean {
    if (!text || typeof text !== 'string') return false;
    const length = text.trim().length;
    return length > 0 && length <= maxLength;
}

/**
 * Проверка email
 */
export function isValidEmail(email: string | null | undefined): boolean {
    if (!email) return false;
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

/**
 * Проверка URL
 */
export function isValidURL(url: string | null | undefined): boolean {
    if (!url) return false;
    try {
        new URL(url);
        return true;
    } catch {
        return false;
    }
}

/**
 * Проверка размера файла
 */
export function isValidFileSize(bytes: number, maxMB: number = 5): boolean {
    const maxBytes = maxMB * 1024 * 1024;
    return bytes <= maxBytes;
}

/**
 * Проверка Base64 изображения
 */
export function isValidImageBase64(str: string | null | undefined): boolean {
    if (!str) return false;
    return str.startsWith('data:image/') && str.includes(';base64,');
}

/**
 * Санитайзинг HTML (клиентский)
 */
export function sanitizeHTML(html: string): string {
    // Используем DOMPurify если доступен
    if (typeof window !== 'undefined' && window.DOMPurify) {
        return window.DOMPurify.sanitize(html, {
            ALLOWED_TAGS: [
                'p', 'br', 'strong', 'em', 'u', 'i', 'b',
                'code', 'pre', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
                'ul', 'ol', 'li', 'blockquote',
                'a', 'table', 'thead', 'tbody', 'tr', 'th', 'td',
                'span', 'div', 'img', 'hr', 'sub', 'sup'
            ],
            ALLOWED_ATTR: ['href', 'target', 'class', 'id', 'style', 'src', 'alt', 'title', 'rel'],
            FORBID_TAGS: ['script', 'style', 'iframe', 'object', 'embed', 'form', 'input', 'button']
        });
    }
    
    // Fallback
    const temp = document.createElement('div');
    temp.textContent = html;
    return temp.innerHTML;
}

/**
 * Проверка, является ли строка валидным числом
 */
export function isValidNumber(value: any): boolean {
    return !isNaN(parseFloat(value)) && isFinite(value);
}

/**
 * Проверка, является ли значение валидным ID пользователя
 */
export function isValidUserId(userId: any): userId is number {
    const id = parseInt(userId, 10);
    return Number.isInteger(id) && id > 0;
}

/**
 * Проверка, является ли значение валидной датой
 */
export function isValidDate(date: any): date is Date {
    return date instanceof Date && !isNaN(date.getTime());
}

/**
 * Проверка, является ли строка валидной датой ISO
 */
export function isValidISODate(dateStr: string | null | undefined): boolean {
    if (!dateStr) return false;
    const date = new Date(dateStr);
    return isValidDate(date);
}

/**
 * Проверка, является ли значение валидным токеном
 */
export function isValidToken(token: string | null | undefined): boolean {
    if (!token || typeof token !== 'string') return false;
    return token.length >= 20;
}

/**
 * Проверка, является ли значение валидным phone number
 */
export function isValidPhone(phone: string | null | undefined): boolean {
    if (!phone) return false;
    const cleaned = phone.replace(/[\s\-()]/g, '');
    return /^\+?\d{10,15}$/.test(cleaned);
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКСПОРТ (для совместимости)
// ============================================

declare global {
    interface Window {
        isValidUUID: typeof isValidUUID;
        isValidTopic: typeof isValidTopic;
        isValidMessageLength: typeof isValidMessageLength;
        isValidEmail: typeof isValidEmail;
        isValidURL: typeof isValidURL;
        isValidFileSize: typeof isValidFileSize;
        isValidImageBase64: typeof isValidImageBase64;
        sanitizeHTML: typeof sanitizeHTML;
    }
}

// Экспортируем в глобальный объект
if (typeof window !== 'undefined') {
    window.isValidUUID = isValidUUID;
    window.isValidTopic = isValidTopic;
    window.isValidMessageLength = isValidMessageLength;
    window.isValidEmail = isValidEmail;
    window.isValidURL = isValidURL;
    window.isValidFileSize = isValidFileSize;
    window.isValidImageBase64 = isValidImageBase64;
    window.sanitizeHTML = sanitizeHTML;
}

console.log('✅ Validators v2.0.0 (TypeScript) загружен');
