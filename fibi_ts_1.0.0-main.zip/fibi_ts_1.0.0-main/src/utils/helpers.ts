// ============================================
// src/utils/helpers.ts
// Описание: Общие утилиты
// Версия: 2.0.0 - TypeScript
// ============================================

/**
 * Форматирование даты
 */
export function formatDate(dateStr: string | null | undefined): string {
    if (!dateStr) return 'неизвестно';
    
    const date = new Date(dateStr);
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diff === 0) {
        return 'сегодня ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diff === 1) {
        return 'вчера ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diff < 7) {
        return diff + ' дня назад';
    } else {
        return date.toLocaleDateString([], { day: '2-digit', month: 'short' });
    }
}

/**
 * Склонение слов (1, 2, 5)
 */
export function pluralize(count: number, one: string, two: string, five: string): string {
    const n = Math.abs(count) % 100;
    const n1 = n % 10;
    
    if (n > 10 && n < 20) return five;
    if (n1 > 1 && n1 < 5) return two;
    if (n1 === 1) return one;
    return five;
}

/**
 * Генерация UUID
 */
export function generateUUID(): string {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
        return crypto.randomUUID();
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

/**
 * Задержка (Promise)
 */
export function sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Безопасный парсинг JSON
 */
export function safeJSONParse<T = any>(str: string, fallback: T | null = null): T | null {
    try {
        return JSON.parse(str);
    } catch {
        return fallback;
    }
}

/**
 * Транкейт строки
 */
export function truncate(str: string, maxLength: number, suffix: string = '...'): string {
    if (!str) return '';
    if (str.length <= maxLength) return str;
    return str.substring(0, maxLength) + suffix;
}

/**
 * Проверка на пустой объект
 */
export function isEmptyObject(obj: Record<string, any> | null | undefined): boolean {
    if (!obj) return true;
    return Object.keys(obj).length === 0;
}

/**
 * Клонирование объекта (глубокое)
 */
export function cloneObject<T>(obj: T): T {
    return JSON.parse(JSON.stringify(obj));
}

/**
 * Дебаунс
 */
export function debounce<T extends (...args: any[]) => any>(
    func: T,
    wait: number
): (...args: Parameters<T>) => void {
    let timeout: ReturnType<typeof setTimeout> | null = null;
    
    return function executedFunction(...args: Parameters<T>): void {
        const later = () => {
            timeout = null;
            func(...args);
        };
        
        if (timeout !== null) {
            clearTimeout(timeout);
        }
        timeout = setTimeout(later, wait);
    };
}

/**
 * Троттлинг
 */
export function throttle<T extends (...args: any[]) => any>(
    func: T,
    limit: number
): (...args: Parameters<T>) => void {
    let inThrottle = false;
    
    return function(...args: Parameters<T>): void {
        if (!inThrottle) {
            func(...args);
            inThrottle = true;
            setTimeout(() => {
                inThrottle = false;
            }, limit);
        }
    };
}

/**
 * Безопасное получение вложенного свойства
 */
export function getSafe<T = any>(obj: any, path: string, defaultValue: T | null = null): T | null {
    try {
        const keys = path.split('.');
        let result = obj;
        for (const key of keys) {
            if (result === null || result === undefined) {
                return defaultValue;
            }
            result = result[key];
        }
        return result !== undefined && result !== null ? result : defaultValue;
    } catch {
        return defaultValue;
    }
}

/**
 * Проверка, является ли значение объектом
 */
export function isObject(value: any): value is Record<string, any> {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}

/**
 * Проверка, является ли значение строкой
 */
export function isString(value: any): value is string {
    return typeof value === 'string';
}

/**
 * Проверка, является ли значение числом
 */
export function isNumber(value: any): value is number {
    return typeof value === 'number' && !isNaN(value);
}

/**
 * Проверка, является ли значение boolean
 */
export function isBoolean(value: any): value is boolean {
    return typeof value === 'boolean';
}

/**
 * Проверка, является ли значение функцией
 */
export function isFunction(value: any): value is Function {
    return typeof value === 'function';
}

/**
 * Проверка, является ли значение массивом
 */
export function isArray<T = any>(value: any): value is T[] {
    return Array.isArray(value);
}

/**
 * Безопасный вызов функции
 */
export function safeCall<T = any>(
    fn: ((...args: any[]) => T) | null | undefined,
    ...args: any[]
): T | null {
    if (isFunction(fn)) {
        try {
            return fn(...args);
        } catch {
            return null;
        }
    }
    return null;
}

/**
 * Получение случайного элемента из массива
 */
export function randomItem<T>(arr: T[]): T | null {
    if (!arr || arr.length === 0) return null;
    return arr[Math.floor(Math.random() * arr.length)];
}

/**
 * Уникальные значения из массива
 */
export function uniqueArray<T>(arr: T[]): T[] {
    return [...new Set(arr)];
}

/**
 * Группировка массива по ключу
 */
export function groupBy<T>(arr: T[], key: keyof T): Record<string, T[]> {
    return arr.reduce((acc, item) => {
        const groupKey = String(item[key]);
        if (!acc[groupKey]) {
            acc[groupKey] = [];
        }
        acc[groupKey].push(item);
        return acc;
    }, {} as Record<string, T[]>);
}

/**
 * Проверка, является ли строка валидным JSON
 */
export function isValidJSON(str: string): boolean {
    try {
        JSON.parse(str);
        return true;
    } catch {
        return false;
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКСПОРТ (для совместимости)
// ============================================

// Добавляем все функции в window для обратной совместимости
declare global {
    interface Window {
        formatDate: typeof formatDate;
        pluralize: typeof pluralize;
        generateUUID: typeof generateUUID;
        sleep: typeof sleep;
        safeJSONParse: typeof safeJSONParse;
        truncate: typeof truncate;
        isEmptyObject: typeof isEmptyObject;
        cloneObject: typeof cloneObject;
        debounce: typeof debounce;
        throttle: typeof throttle;
    }
}

// Экспортируем в глобальный объект
if (typeof window !== 'undefined') {
    window.formatDate = formatDate;
    window.pluralize = pluralize;
    window.generateUUID = generateUUID;
    window.sleep = sleep;
    window.safeJSONParse = safeJSONParse;
    window.truncate = truncate;
    window.isEmptyObject = isEmptyObject;
    window.cloneObject = cloneObject;
    window.debounce = debounce;
    window.throttle = throttle;
}

console.log('✅ Helpers v2.0.0 (TypeScript) загружен');
