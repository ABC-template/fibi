// ============================================
// src/core/modal-manager.ts
// Описание: Универсальный менеджер модалок
// Версия: 4.0.0 - TypeScript
// ============================================

import { getEventBus } from './event-bus';
import { getNavigationState } from './navigation-state';

/**
 * Опции открытия модалки
 */
export interface ModalOptions {
    title: string;
    content: string;
    footer?: string;
    showFooter?: boolean;
    modalId?: string;
    onOpen?: () => void;
    onClose?: () => void;
    onSave?: () => void;
    onCancel?: () => void;
}

/**
 * Менеджер модальных окон
 */
export class ModalManager {
    private static instance: ModalManager | null = null;

    private modal: HTMLElement | null = null;
    private overlay: HTMLElement | null = null;
    private content: HTMLElement | null = null;
    private title: HTMLElement | null = null;
    private body: HTMLElement | null = null;
    private footer: HTMLElement | null = null;
    private closeBtn: HTMLElement | null = null;

    private eventBus = getEventBus();
    private navigationState = getNavigationState();

    private _isOpen: boolean = false;
    private _callbacks: {
        onOpen?: () => void;
        onClose?: () => void;
        onSave?: () => void;
        onCancel?: () => void;
    } = {};
    private _modalId: string | null = null;
    private _wasDrawerOpen: boolean = false;
    private _isClosing: boolean = false;

    private constructor() {
        this.initElements();
        this.initEvents();
    }

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): ModalManager {
        if (!ModalManager.instance) {
            ModalManager.instance = new ModalManager();
        }
        return ModalManager.instance;
    }

    // ==========================================
    // ИНИЦИАЛИЗАЦИЯ
    // ==========================================

    private initElements(): void {
        this.modal = document.getElementById('universal-modal');
        this.overlay = document.getElementById('modal-overlay');
        this.content = document.getElementById('modal-content');
        this.title = document.getElementById('modal-title');
        this.body = document.getElementById('modal-body');
        this.footer = document.getElementById('modal-footer');
        this.closeBtn = document.getElementById('modal-close');
    }

    private initEvents(): void {
        if (!this.modal || !this.overlay || !this.content) return;

        // Закрытие по крестику
        this.closeBtn?.addEventListener('click', (e) => {
            e.stopPropagation();
            this.close();
        });

        // Закрытие по клику на оверлей
        this.overlay.addEventListener('click', (e) => {
            if (e.target === this.overlay) {
                e.stopPropagation();
                this.close();
            }
        });

        // Защита от всплытия
        this.content.addEventListener('click', (e) => e.stopPropagation());
        this.title?.addEventListener('click', (e) => e.stopPropagation());
        this.body?.addEventListener('click', (e) => e.stopPropagation());
        this.footer?.addEventListener('click', (e) => e.stopPropagation());

        // Подписка на закрытие через кнопку "Назад"
        this.eventBus.on('modal:state_changed', (data) => {
            if (data && data.action === 'back' && data.isOpen === false) {
                this.handleBackClose();
            }
        });

        console.log('✅ ModalManager v4.0.0 инициализирован');
    }

    private handleBackClose(): void {
        if (this._isOpen && !this._isClosing) {
            console.log('📱 Модалка закрыта через кнопку "Назад"');
            this.close();
        }
    }

    // ==========================================
    // ОТКРЫТИЕ / ЗАКРЫТИЕ
    // ==========================================

    /**
     * Открыть модалку
     */
    open(options: ModalOptions): void {
        const {
            title = 'Заголовок',
            content = '',
            footer = '',
            onOpen = null,
            onClose = null,
            onSave = null,
            onCancel = null,
            showFooter = false,
            modalId = 'default'
        } = options;

        if (!this.modal || !this.overlay || !this.content) return;

        this._isClosing = false;
        this._callbacks = { onOpen, onClose, onSave, onCancel };
        this._modalId = modalId;

        // Сохраняем состояние сайдбара
        const drawer = document.getElementById('drawer');
        this._wasDrawerOpen = drawer?.classList.contains('active') || false;

        if (this._wasDrawerOpen && drawer) {
            drawer.style.pointerEvents = 'none';
            drawer.style.opacity = '0.5';
            document.body.style.overflow = '';
        }

        // Устанавливаем контент
        if (this.title) this.title.textContent = title;
        if (this.body) this.body.innerHTML = content;

        // Настраиваем футер
        if (this.footer) {
            if (showFooter && footer) {
                this.footer.innerHTML = footer;
                this.footer.classList.remove('hidden');

                const saveBtn = this.footer.querySelector('#modal-save-btn');
                const cancelBtn = this.footer.querySelector('#modal-cancel-btn');

                if (saveBtn) {
                    saveBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        if (this._callbacks.onSave) {
                            this._callbacks.onSave();
                        }
                    });
                }

                if (cancelBtn) {
                    cancelBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        if (this._callbacks.onCancel) {
                            this._callbacks.onCancel();
                        }
                        this.close();
                    });
                }
            } else {
                this.footer.innerHTML = '';
                this.footer.classList.add('hidden');
            }
        }

        // Показываем модалку
        this.modal.style.display = 'flex';
        this.modal.style.visibility = 'visible';
        this.modal.style.opacity = '1';
        this.modal.classList.remove('hidden');

        // Анимация появления
        this.content.style.transition = 'none';
        this.content.style.transform = 'scale(0.95) translateY(20px)';
        this.content.style.opacity = '0';

        requestAnimationFrame(() => {
            if (this.content) {
                this.content.style.transition = 'all 0.3s cubic-bezier(0.1, 0.8, 0.25, 1)';
                this.content.style.transform = 'scale(1) translateY(0)';
                this.content.style.opacity = '1';
            }
        });

        this._isOpen = true;

        // Отправляем события
        this.eventBus.emit('modal:open', { modalId: this._modalId });
        this.navigationState.toggleModal(true, this._modalId);

        // Создаем иконки
        setTimeout(() => {
            if (typeof (window as any).lucide !== 'undefined') {
                (window as any).lucide.createIcons();
            }
        }, 100);

        if (this._callbacks.onOpen) {
            this._callbacks.onOpen();
        }

        console.log(`📱 Модалка открыта: ${title} (id: ${this._modalId})`);
    }

    /**
     * Закрыть модалку
     */
    close(): void {
        if (this._isClosing || !this._isOpen) return;
        if (!this.modal || !this.content) return;

        this._isClosing = true;

        this.content.style.transition = 'all 0.25s cubic-bezier(0.1, 0.8, 0.25, 1)';
        this.content.style.transform = 'scale(0.95) translateY(20px)';
        this.content.style.opacity = '0';

        setTimeout(() => {
            if (this.modal) {
                this.modal.style.display = 'none';
                this.modal.style.visibility = 'hidden';
                this.modal.style.opacity = '0';
                this.modal.classList.add('hidden');
            }

            // Восстанавливаем сайдбар
            const drawer = document.getElementById('drawer');
            if (drawer) {
                drawer.style.pointerEvents = 'auto';
                drawer.style.opacity = '1';
            }

            document.body.style.overflow = '';

            this._isOpen = false;
            this._isClosing = false;

            // Отправляем события
            this.eventBus.emit('modal:close', {
                modalId: this._modalId,
                action: 'close'
            });

            this.navigationState.toggleModal(false, this._modalId);

            if (this.body) this.body.innerHTML = '';
            if (this.footer) {
                this.footer.innerHTML = '';
                this.footer.classList.add('hidden');
            }

            if (this._callbacks.onClose) {
                this._callbacks.onClose();
            }

            this._callbacks = {};
            this._modalId = null;

            console.log('📱 Модалка закрыта');
        }, 300);
    }

    /**
     * Принудительно закрыть
     */
    forceClose(): void {
        if (!this._isOpen) return;
        if (!this.modal) return;

        this.modal.style.display = 'none';
        this.modal.style.visibility = 'hidden';
        this.modal.style.opacity = '0';
        this.modal.classList.add('hidden');

        const drawer = document.getElementById('drawer');
        if (drawer) {
            drawer.style.pointerEvents = 'auto';
            drawer.style.opacity = '1';
        }

        document.body.style.overflow = '';
        this._isOpen = false;
        this._isClosing = false;

        if (this.body) this.body.innerHTML = '';
        if (this.footer) {
            this.footer.innerHTML = '';
            this.footer.classList.add('hidden');
        }

        this._callbacks = {};

        this.eventBus.emit('modal:close', {
            modalId: this._modalId,
            action: 'force'
        });

        this.navigationState.toggleModal(false, this._modalId);
        this._modalId = null;

        console.log('📱 Модалка принудительно закрыта');
    }

    // ==========================================
    // ОБНОВЛЕНИЕ
    // ==========================================

    /**
     * Обновить содержимое
     */
    updateContent(content: string): void {
        if (this._isOpen && this.body) {
            this.body.innerHTML = content;
            setTimeout(() => {
                if (typeof (window as any).lucide !== 'undefined') {
                    (window as any).lucide.createIcons();
                }
            }, 100);
        }
    }

    /**
     * Обновить заголовок
     */
    updateTitle(title: string): void {
        if (this._isOpen && this.title) {
            this.title.textContent = title;
        }
    }

    /**
     * Обновить футер
     */
    updateFooter(footer: string): void {
        if (!this._isOpen || !this.footer) return;

        if (footer) {
            this.footer.innerHTML = footer;
            this.footer.classList.remove('hidden');

            const saveBtn = this.footer.querySelector('#modal-save-btn');
            const cancelBtn = this.footer.querySelector('#modal-cancel-btn');

            if (saveBtn) {
                saveBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (this._callbacks.onSave) {
                        this._callbacks.onSave();
                    }
                });
            }

            if (cancelBtn) {
                cancelBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (this._callbacks.onCancel) {
                        this._callbacks.onCancel();
                    }
                    this.close();
                });
            }
        } else {
            this.footer.innerHTML = '';
            this.footer.classList.add('hidden');
        }
    }

    // ==========================================
    // ГЕТТЕРЫ
    // ==========================================

    /**
     * Проверить, открыта ли модалка
     */
    isOpen(): boolean {
        return this._isOpen;
    }

    /**
     * Получить ID модалки
     */
    getModalId(): string | null {
        return this._modalId;
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let modalManagerInstance: ModalManager | null = null;

/**
 * Получить экземпляр ModalManager
 */
export function getModalManager(): ModalManager {
    if (!modalManagerInstance) {
        modalManagerInstance = ModalManager.getInstance();
    }
    return modalManagerInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).ModalManager = ModalManager;
    (window as any).modalManager = getModalManager();
}

// Глобальные функции
if (typeof window !== 'undefined') {
    (window as any).showModal = (options: ModalOptions) => getModalManager().open(options);
    (window as any).closeModal = () => getModalManager().close();
}

console.log('✅ ModalManager v4.0.0 (TypeScript) загружен');
