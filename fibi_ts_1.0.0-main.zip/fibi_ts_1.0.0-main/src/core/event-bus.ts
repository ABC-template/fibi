// ============================================
// src/core/event-bus.ts
// Описание: Центральная шина событий для реактивности
// Версия: 2.0.0 - TypeScript
// ============================================

/**
 * Тип данных события
 */
export type EventData = any;

/**
 * Тип функции-обработчика события
 */
export type EventHandler<T = EventData> = (data: T, sender?: any, event?: string) => void;

/**
 * Интерфейс слушателя события
 */
interface Listener<T = EventData> {
    callback: EventHandler<T>;
    context: any | null;
    id: string;
}

/**
 * Центральная шина событий
 */
export class EventBus {
    private listeners: Map<string, Listener[]> = new Map();
    private onceListeners: Map<string, Listener[]> = new Map();
    private _isDebug: boolean = false;

    constructor(debug: boolean = false) {
        this._isDebug = debug;
    }

    /**
     * Подписаться на событие
     * @param event - Название события
     * @param callback - Функция-обработчик
     * @param context - Контекст (this) для обработчика
     * @returns Функция для отписки
     */
    on<T = EventData>(
        event: string,
        callback: EventHandler<T>,
        context: any = null
    ): () => void {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, []);
        }

        const listener: Listener<T> = {
            callback: callback as EventHandler,
            context: context,
            id: Date.now() + '_' + Math.random().toString(36).substring(2, 6)
        };

        this.listeners.get(event)!.push(listener as Listener);

        if (this._isDebug) {
            console.log(`📡 [EventBus] Подписка на "${event}" (id: ${listener.id})`);
        }

        // Возвращаем функцию для отписки
        return () => this.off(event, listener.id);
    }

    /**
     * Подписаться на событие один раз
     */
    once<T = EventData>(
        event: string,
        callback: EventHandler<T>,
        context: any = null
    ): () => void {
        if (!this.onceListeners.has(event)) {
            this.onceListeners.set(event, []);
        }

        const listener: Listener<T> = {
            callback: callback as EventHandler,
            context: context,
            id: Date.now() + '_' + Math.random().toString(36).substring(2, 6)
        };

        this.onceListeners.get(event)!.push(listener as Listener);

        if (this._isDebug) {
            console.log(`📡 [EventBus] Подписка "один раз" на "${event}" (id: ${listener.id})`);
        }

        return () => this.off(event, listener.id);
    }

    /**
     * Отписаться от события
     */
    off(event: string, listenerId: string): boolean {
        let removed = false;

        // Проверяем обычные подписки
        if (this.listeners.has(event)) {
            const initialLength = this.listeners.get(event)!.length;
            this.listeners.set(
                event,
                this.listeners.get(event)!.filter(l => l.id !== listenerId)
            );
            if (this.listeners.get(event)!.length < initialLength) {
                removed = true;
            }
        }

        // Проверяем "один раз" подписки
        if (this.onceListeners.has(event)) {
            const initialLength = this.onceListeners.get(event)!.length;
            this.onceListeners.set(
                event,
                this.onceListeners.get(event)!.filter(l => l.id !== listenerId)
            );
            if (this.onceListeners.get(event)!.length < initialLength) {
                removed = true;
            }
        }

        if (this._isDebug && removed) {
            console.log(`📡 [EventBus] Отписка от "${event}" (id: ${listenerId})`);
        }

        return removed;
    }

    /**
     * Отписаться от всех событий для конкретного контекста
     */
    offAll(context: any): number {
        let count = 0;

        for (const [event, listeners] of this.listeners) {
            const filtered = listeners.filter(l => l.context !== context);
            if (filtered.length < listeners.length) {
                count += listeners.length - filtered.length;
                this.listeners.set(event, filtered);
            }
        }

        for (const [event, listeners] of this.onceListeners) {
            const filtered = listeners.filter(l => l.context !== context);
            if (filtered.length < listeners.length) {
                count += listeners.length - filtered.length;
                this.onceListeners.set(event, filtered);
            }
        }

        if (this._isDebug && count > 0) {
            console.log(`📡 [EventBus] Отписка от всех событий для контекста (${count} подписок)`);
        }

        return count;
    }

    /**
     * Полная очистка всех подписок
     */
    clear(): void {
        const total = this.listeners.size + this.onceListeners.size;
        this.listeners.clear();
        this.onceListeners.clear();

        if (this._isDebug) {
            console.log(`📡 [EventBus] Полная очистка (${total} событий)`);
        }
    }

    /**
     * Вызвать событие
     * @param event - Название события
     * @param data - Данные события
     * @param sender - Отправитель (обычно this)
     */
    emit<T = EventData>(event: string, data?: T, sender?: any): void {
        if (this._isDebug) {
            console.log(`📡 [EventBus] Событие "${event}"`, data);
        }

        // Вызываем обычные подписки
        if (this.listeners.has(event)) {
            const listeners = [...this.listeners.get(event)!];
            for (const listener of listeners) {
                try {
                    listener.callback.call(listener.context, data, sender, event);
                } catch (err) {
                    console.error(`❌ [EventBus] Ошибка в обработчике "${event}":`, err);
                }
            }
        }

        // Вызываем подписки "один раз"
        if (this.onceListeners.has(event)) {
            const listeners = [...this.onceListeners.get(event)!];
            // Удаляем их сразу после вызова
            this.onceListeners.delete(event);

            for (const listener of listeners) {
                try {
                    listener.callback.call(listener.context, data, sender, event);
                } catch (err) {
                    console.error(`❌ [EventBus] Ошибка в once-обработчике "${event}":`, err);
                }
            }
        }
    }

    /**
     * Включить/выключить отладку
     */
    setDebug(enabled: boolean): void {
        this._isDebug = enabled;
        console.log(`📡 [EventBus] Отладка ${enabled ? 'включена' : 'выключена'}`);
    }

    /**
     * Получить количество подписок на событие
     */
    listenerCount(event: string): number {
        let count = 0;
        if (this.listeners.has(event)) {
            count += this.listeners.get(event)!.length;
        }
        if (this.onceListeners.has(event)) {
            count += this.onceListeners.get(event)!.length;
        }
        return count;
    }

    /**
     * Получить все события
     */
    getEvents(): string[] {
        const events = new Set<string>();
        for (const key of this.listeners.keys()) {
            events.add(key);
        }
        for (const key of this.onceListeners.keys()) {
            events.add(key);
        }
        return Array.from(events);
    }

    /**
     * Проверить, есть ли подписки на событие
     */
    hasListeners(event: string): boolean {
        return this.listenerCount(event) > 0;
    }

    /**
     * Получить количество всех подписок
     */
    totalListeners(): number {
        let total = 0;
        for (const listeners of this.listeners.values()) {
            total += listeners.length;
        }
        for (const listeners of this.onceListeners.values()) {
            total += listeners.length;
        }
        return total;
    }

    /**
     * Удалить все подписки на событие
     */
    removeAllListeners(event: string): void {
        this.listeners.delete(event);
        this.onceListeners.delete(event);
        
        if (this._isDebug) {
            console.log(`📡 [EventBus] Удалены все подписки на "${event}"`);
        }
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

// Создаем глобальный экземпляр
let globalEventBus: EventBus | null = null;

/**
 * Получить глобальный экземпляр EventBus
 */
export function getEventBus(): EventBus {
    if (!globalEventBus) {
        globalEventBus = new EventBus();
        
        // Включаем отладку в development
        if (typeof window !== 'undefined' && 
            (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')) {
            globalEventBus.setDebug(true);
        }
        
        console.log('✅ EventBus v2.0.0 (TypeScript) создан');
    }
    return globalEventBus;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    window.eventBus = getEventBus();
}

console.log('✅ EventBus v2.0.0 (TypeScript) загружен');
