// ============================================
// src/modules/ui/profile-ui.ts
// Описание: Работа с модалками (Избранное, Корзина)
// Версия: 7.0.0 - TypeScript
// ============================================

import { getChatStore, Message } from '@store/ChatStore';
import { getUserStore } from '@store/UserStore';
import { getEventBus } from '@core/event-bus';
import { getUIRenderer } from './renderer';
import { getModalManager } from '@core/modal-manager';

/**
 * UI для профиля
 */
export class ProfileUI {
    private static instance: ProfileUI | null = null;

    private chatStore = getChatStore();
    private userStore = getUserStore();
    private eventBus = getEventBus();
    private uiRenderer = getUIRenderer();
    private subscriptions: (() => void)[] = [];
    public currentFilter: string = 'all';

    private constructor() {
        this.subscribeToEvents();
    }

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): ProfileUI {
        if (!ProfileUI.instance) {
            ProfileUI.instance = new ProfileUI();
        }
        return ProfileUI.instance;
    }

    // ==========================================
    // ПОДПИСКА НА СОБЫТИЯ
    // ==========================================

    private subscribeToEvents(): void {
        const unsubFav = this.eventBus.on('chat:favorite_toggled', () => {
            const modalManager = getModalManager();
            if (modalManager.isOpen()) {
                this.renderFavoritesModal();
            }
        });
        this.subscriptions.push(unsubFav);

        const unsubTrash = this.eventBus.on('chat:deleted', () => {
            const modalManager = getModalManager();
            if (modalManager.isOpen()) {
                this.renderTrashModal();
            }
        });
        this.subscriptions.push(unsubTrash);

        const unsubRestore = this.eventBus.on('chat:restored', () => {
            const modalManager = getModalManager();
            if (modalManager.isOpen()) {
                this.renderTrashModal();
            }
        });
        this.subscriptions.push(unsubRestore);

        console.log('📡 ProfileUI подписан на события');
    }

    // ==========================================
    // ИЗБРАННОЕ
    // ==========================================

    /**
     * Показать модалку избранного
     */
    showFavoritesModal(): void {
        const content = this.renderFavoritesContent();
        const modalManager = getModalManager();

        modalManager.open({
            title: '⭐ Избранное',
            content: content,
            modalId: 'favorites',
            onClose: () => {
                this.eventBus.emit('modal:close', { modalId: 'favorites' });
            }
        });
    }

    /**
     * Рендерить содержимое избранного
     */
    private renderFavoritesContent(): string {
        const favorites = this.chatStore.getFavorites();

        if (favorites.length === 0) {
            return `
                <div style="padding: 40px 20px; text-align: center; color: var(--app-text-tertiary);">
                    <i data-lucide="heart" style="width:48px;height:48px;display:block;margin:0 auto 12px;opacity:0.3;"></i>
                    <p style="font-size:14px;">У вас пока нет избранных ответов</p>
                    <p style="font-size:12px;margin-top:4px;">Нажмите ❤️ на любом сообщении ИИ, чтобы добавить его в избранное</p>
                </div>
            `;
        }

        let html = `<div style="display:flex;flex-direction:column;gap:8px;padding:4px 0;">`;

        for (const msg of favorites) {
            const cleanText = msg.text.replace(/[#*`]/g, '');
            const shortText = cleanText.length > 80 ? cleanText.substring(0, 80) + '...' : cleanText;

            html += `
                <div class="fav-item" style="
                    display:flex;
                    align-items:center;
                    justify-content:space-between;
                    padding:12px 14px;
                    background:var(--app-bg-tertiary);
                    border-radius:12px;
                    cursor:pointer;
                    transition:all 0.2s;
                    gap:12px;
                " onclick="window.profileUI.openChatFromFavorite('${msg.chat_id}', '${msg.topic}', '${msg.id}')">
                    <div style="flex:1;min-width:0;">
                        <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--app-text-tertiary);margin-bottom:4px;font-weight:600;">
                            <span>🤖 ${(window as any).topicNames?.[msg.topic] || msg.topic}</span>
                            <span>📂 ${msg.chat_title}</span>
                        </div>
                        <div style="color:var(--app-text-primary);line-height:1.3;font-size:13px;word-break:break-word;">${shortText}</div>
                    </div>
                    <button class="fav-unfav-btn" style="
                        background:transparent;
                        border:none;
                        font-size:18px;
                        cursor:pointer;
                        padding:4px;
                        opacity:0.5;
                        transition:all 0.2s;
                        flex-shrink:0;
                    " onclick="event.stopPropagation(); window.profileUI.unfavorite('${msg.chat_id}', '${msg.id}')">
                        ❤️
                    </button>
                </div>
            `;
        }

        html += `</div>`;
        return html;
    }

    /**
     * Открыть чат из избранного
     */
    openChatFromFavorite(chatId: string, topic: string, msgId: string): void {
        console.log(`⭐ [favorite] Открываем чат из избранного: ${chatId}`);

        // Закрываем модалку
        const modalManager = getModalManager();
        modalManager.forceClose();

        // Закрываем сайдбар
        if ((window as any).closeDrawer) {
            (window as any).closeDrawer();
        } else {
            const drawer = document.getElementById('drawer');
            const overlay = document.getElementById('drawer-overlay');
            if (drawer?.classList.contains('active')) {
                drawer.classList.remove('active');
                overlay?.classList.remove('active');
                document.body.style.overflow = '';
            }
        }

        // Открываем чат
        if ((window as any).navigationState) {
            (window as any).navigationState.openChat(chatId, topic);
        } else if (this.eventBus) {
            this.eventBus.emit('navigation:open_chat', { chatId, topic });
        } else {
            (window as any).openChat(chatId, topic);
        }

        // Скролл к сообщению
        setTimeout(() => {
            const target = document.getElementById(`msg-block-${msgId}`);
            const container = document.getElementById('chat-container');
            if (container && target) {
                container.scrollTo({ top: Math.max(0, target.offsetTop - 80), behavior: 'smooth' });
                target.style.transition = 'background 0.5s';
                target.style.background = 'rgba(212,175,55,0.15)';
                setTimeout(() => target.style.background = '', 1500);
            }
        }, 500);
    }

    /**
     * Убрать из избранного
     */
    async unfavorite(chatId: string, msgId: string): Promise<void> {
        if ((window as any).messageService) {
            await (window as any).messageService.toggleFavorite(chatId, msgId);
        }
        this.renderFavoritesModal();
    }

    /**
     * Перерендерить избранное
     */
    renderFavoritesModal(): void {
        const modalManager = getModalManager();
        if (modalManager.isOpen()) {
            const content = this.renderFavoritesContent();
            modalManager.updateContent(content);
        }
    }

    // ==========================================
    // КОРЗИНА
    // ==========================================

    /**
     * Показать модалку корзины
     */
    showTrashModal(): void {
        const content = this.renderTrashContent();
        const modalManager = getModalManager();

        modalManager.open({
            title: '🗑️ Корзина',
            content: content,
            modalId: 'trash',
            footer: `
                <button id="modal-save-btn" class="btn btn-danger" style="width:100%;">
                    🗑️ Очистить корзину полностью
                </button>
            `,
            showFooter: true,
            onSave: () => {
                this.clearAllTrash();
            },
            onClose: () => {
                this.eventBus.emit('modal:close', { modalId: 'trash' });
            }
        });
    }

    /**
     * Рендерить содержимое корзины
     */
    private renderTrashContent(): string {
        const trash = this.chatStore.getTrash();
        const chats = trash.chats || [];

        if (chats.length === 0) {
            return `
                <div style="padding: 40px 20px; text-align: center; color: var(--app-text-tertiary);">
                    <i data-lucide="trash-2" style="width:48px;height:48px;display:block;margin:0 auto 12px;opacity:0.3;"></i>
                    <p style="font-size:14px;">Корзина пуста</p>
                    <p style="font-size:12px;margin-top:4px;">Удалённые чаты будут появляться здесь</p>
                </div>
            `;
        }

        let html = `<div style="display:flex;flex-direction:column;gap:8px;padding:4px 0;">`;

        for (const chat of chats) {
            const deletedDate = chat.deleted_at ? new Date(chat.deleted_at) : new Date();
            const dateStr = (window as any).formatDate ? (window as any).formatDate(deletedDate) : deletedDate.toLocaleString();
            const msgCount = chat.messages ? chat.messages.length : 0;

            html += `
                <div class="trash-item" style="
                    display:flex;
                    align-items:center;
                    justify-content:space-between;
                    padding:12px 14px;
                    background:var(--app-bg-tertiary);
                    border-radius:12px;
                    gap:10px;
                    border:1px solid var(--app-border-color-light);
                ">
                    <div style="flex:1;min-width:0;">
                        <div style="font-weight:500;font-size:13px;color:var(--app-text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                            ${chat.title || 'Без названия'}
                        </div>
                        <div style="font-size:11px;color:var(--app-text-tertiary);">
                            ${chat.topic || 'unknown'} • ${dateStr} • ${msgCount} сообщений
                        </div>
                    </div>
                    <div style="display:flex;gap:6px;flex-shrink:0;">
                        <button class="btn" style="padding:4px 10px;font-size:11px;border-radius:6px;background:#27ae60;color:white;border:none;cursor:pointer;"
                                onclick="window.profileUI.restoreFromTrash('${chat.id}')">
                            ↩️
                        </button>
                        <button class="btn" style="padding:4px 10px;font-size:11px;border-radius:6px;background:#e74c3c;color:white;border:none;cursor:pointer;"
                                onclick="window.profileUI.permanentDelete('${chat.id}')">
                            🗑️
                        </button>
                    </div>
                </div>
            `;
        }

        html += `</div>`;
        return html;
    }

    /**
     * Восстановить из корзины
     */
    async restoreFromTrash(chatId: string): Promise<void> {
        const confirmMsg = 'Восстановить этот чат и все его сообщения?';

        const action = async () => {
            this.chatStore.restoreChat(chatId);

            if (this.userStore.canSync() && (window as any).chatService) {
                await (window as any).chatService.restoreChat(chatId);
            }

            this.renderTrashModal();

            if (this.uiRenderer) {
                this.uiRenderer.showToast('♻️ Чат восстановлен', 'success', 1500);
            }
        };

        if ((window as any).tg?.showConfirm) {
            (window as any).tg.showConfirm(confirmMsg, (ok: boolean) => { if (ok) action(); });
        } else if (confirm(confirmMsg)) {
            action();
        }
    }

    /**
     * Безвозвратное удаление
     */
    async permanentDelete(chatId: string): Promise<void> {
        const confirmMsg = 'Удалить чат навсегда? Это действие нельзя отменить!';

        const action = async () => {
            this.chatStore.permanentDeleteChat(chatId);

            if (this.userStore.canSync() && (window as any).chatService) {
                await (window as any).chatService.permanentDeleteChat(chatId);
            }

            this.renderTrashModal();

            if (this.uiRenderer) {
                this.uiRenderer.showToast('🗑️ Чат удалён навсегда', 'info', 1500);
            }
        };

        if ((window as any).tg?.showConfirm) {
            (window as any).tg.showConfirm(confirmMsg, (ok: boolean) => { if (ok) action(); });
        } else if (confirm(confirmMsg)) {
            action();
        }
    }

    /**
     * Очистить всю корзину
     */
    async clearAllTrash(): Promise<void> {
        const confirmMsg = 'Очистить корзину полностью? Все чаты будут удалены навсегда!';

        const action = async () => {
            const trash = this.chatStore.getTrash();
            const chatIds = trash.chats.map(c => c.id);

            for (const chatId of chatIds) {
                this.chatStore.permanentDeleteChat(chatId);
                if (this.userStore.canSync() && (window as any).chatService) {
                    await (window as any).chatService.permanentDeleteChat(chatId);
                }
            }

            this.renderTrashModal();

            if (this.uiRenderer) {
                this.uiRenderer.showToast(`🗑️ Очищено ${chatIds.length} чатов`, 'info', 1500);
            }
        };

        if ((window as any).tg?.showConfirm) {
            (window as any).tg.showConfirm(confirmMsg, (ok: boolean) => { if (ok) action(); });
        } else if (confirm(confirmMsg)) {
            action();
        }
    }

    /**
     * Перерендерить корзину
     */
    renderTrashModal(): void {
        const modalManager = getModalManager();
        if (modalManager.isOpen()) {
            const content = this.renderTrashContent();
            modalManager.updateContent(content);

            const footer = `
                <button id="modal-save-btn" class="btn btn-danger" style="width:100%;">
                    🗑️ Очистить корзину полностью
                </button>
            `;
            modalManager.updateFooter(footer);
        }
    }

    // ==========================================
    // КОНТЕКСТ ЧАТА
    // ==========================================

    /**
     * Показать модалку контекста
     */
    showContextModal(chatId: string): void {
        const found = this.chatStore.findChatById(chatId);
        if (!found) {
            if ((window as any).tg?.showAlert) {
                (window as any).tg.showAlert('Чат не найден');
            }
            return;
        }

        const chat = found.chat;
        const currentValue = chat.maxContext || 15;
        const modalManager = getModalManager();

        const content = `
            <div style="padding:4px 0;">
                <p style="font-size:13px;color:var(--app-text-secondary);margin:0 0 12px 0;line-height:1.5;">
                    🧠 <strong>Память чата</strong> определяет, сколько последних сообщений ИИ учитывает при ответе.
                </p>
                <div style="background:var(--app-bg-tertiary);padding:12px;border-radius:10px;margin-bottom:16px;">
                    <div style="font-size:12px;color:var(--app-text-tertiary);line-height:1.6;">
                        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
                            <span style="font-size:16px;">⚡</span>
                            <span><strong>Меньше</strong> — быстрей ответ и экономия токенов</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <span style="font-size:16px;">🧠</span>
                            <span><strong>Больше</strong> — ИИ идеально помнит нить беседы</span>
                        </div>
                    </div>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                    <span style="font-size:13px;font-weight:600;color:var(--app-text-primary);">Текущее значение: <span id="context-display-value">${currentValue}</span></span>
                    <span style="font-size:11px;color:var(--app-text-tertiary);">1-40</span>
                </div>
                <input type="range" id="context-slider-modal" min="1" max="40" value="${currentValue}" 
                       style="width:100%;cursor:pointer;display:block;height:4px;border-radius:2px;background:var(--app-bg-tertiary);outline:none;"
                       oninput="document.getElementById('context-display-value').textContent = this.value">
                <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--app-text-tertiary);margin-top:2px;">
                    <span>1 (Выкл)</span>
                    <span>40 сообщений</span>
                </div>
            </div>
        `;

        const footer = `
            <button id="modal-save-btn" class="btn" style="width:100%;">💾 Сохранить</button>
        `;

        modalManager.open({
            title: '🧠 Память чата',
            content: content,
            modalId: 'context',
            footer: footer,
            showFooter: true,
            onSave: () => {
                const slider = document.getElementById('context-slider-modal') as HTMLInputElement;
                if (slider) {
                    const newValue = parseInt(slider.value, 10);
                    this.saveChatContext(chatId, newValue);
                }
            },
            onClose: () => {
                this.eventBus.emit('modal:close', { modalId: 'context' });
            }
        });
    }

    /**
     * Сохранить контекст чата
     */
    private async saveChatContext(chatId: string, value: number): Promise<void> {
        const found = this.chatStore.findChatById(chatId);
        if (!found) return;

        found.chat.maxContext = value;
        this.chatStore.save();

        if (this.userStore.canSync() && (window as any).chatService) {
            await (window as any).chatService.updateContext(chatId, value);
        }

        const modalManager = getModalManager();
        modalManager.close();

        if (this.uiRenderer) {
            this.uiRenderer.showToast(`🧠 Память обновлена: ${value} сообщений`, 'success', 1500);
        }
    }

    // ==========================================
    // ИСТОРИЯ ЧАТОВ
    // ==========================================

    /**
     * Рендерить список истории чатов
     */
    renderHistoryChatsList(filter: string = 'all'): void {
        this.currentFilter = filter;
        // Заглушка — реальная реализация в ProfileModule
    }

    /**
     * Обновить название чата
     */
    updateChatTitle(chatId: string, newTitle: string): void {
        // Заглушка
    }

    // ==========================================
    // ОЧИСТКА
    // ==========================================

    /**
     * Уничтожить подписки
     */
    destroy(): void {
        for (const unsub of this.subscriptions) {
            try {
                unsub();
            } catch (e) {
                console.warn('Ошибка отписки ProfileUI:', e);
            }
        }
        this.subscriptions = [];
        console.log('📡 ProfileUI отписан от событий');
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let profileUIInstance: ProfileUI | null = null;

/**
 * Получить экземпляр ProfileUI
 */
export function getProfileUI(): ProfileUI {
    if (!profileUIInstance) {
        profileUIInstance = ProfileUI.getInstance();
    }
    return profileUIInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).ProfileUI = ProfileUI;
    (window as any).profileUI = getProfileUI();
}

// Глобальные функции
if (typeof window !== 'undefined') {
    (window as any).showFavoritesModal = () => getProfileUI().showFavoritesModal();
    (window as any).showTrashModal = () => getProfileUI().showTrashModal();
    (window as any).showContextModal = (chatId: string) => getProfileUI().showContextModal(chatId);
}

console.log('✅ ProfileUI v7.0.0 (TypeScript) загружен');
