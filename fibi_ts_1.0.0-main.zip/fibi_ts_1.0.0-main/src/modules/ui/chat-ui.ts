// ============================================
// src/modules/ui/chat-ui.ts
// Описание: Управление чатами (компактная версия)
// Версия: 4.0.0 - TypeScript
// ============================================

import { getChatStore, Chat } from '@store/ChatStore';
import { getEventBus } from '@core/event-bus';
import { getUIRenderer } from './renderer';

/**
 * UI для управления чатами
 */
export class ChatUI {
    private static instance: ChatUI | null = null;

    private chatStore = getChatStore();
    private eventBus = getEventBus();
    private uiRenderer = getUIRenderer();
    private currentTopic: string = 'code';
    private subscriptions: (() => void)[] = [];

    private constructor() {
        this.subscribeToEvents();
    }

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): ChatUI {
        if (!ChatUI.instance) {
            ChatUI.instance = new ChatUI();
        }
        return ChatUI.instance;
    }

    // ==========================================
    // ПОДПИСКА НА СОБЫТИЯ
    // ==========================================

    private subscribeToEvents(): void {
        const update = () => this.updateLists();

        const unsubMsg = this.eventBus.on('chat:message_added', update);
        this.subscriptions.push(unsubMsg);

        const unsubAll = this.eventBus.on('chat:all_updated', update);
        this.subscriptions.push(unsubAll);

        const unsubRename = this.eventBus.on('chat:renamed', update);
        this.subscriptions.push(unsubRename);

        const unsubDelete = this.eventBus.on('chat:deleted', () => {
            if ((window as any).updateTrashCount) {
                setTimeout((window as any).updateTrashCount, 300);
            }
            this.updateLists();
        });
        this.subscriptions.push(unsubDelete);

        const unsubRestore = this.eventBus.on('chat:restored', () => {
            if ((window as any).updateTrashCount) {
                setTimeout((window as any).updateTrashCount, 300);
            }
            this.updateLists();
        });
        this.subscriptions.push(unsubRestore);
    }

    // ==========================================
    // ОБНОВЛЕНИЕ UI
    // ==========================================

    /**
     * Обновить списки чатов
     */
    private updateLists(): void {
        if ((window as any).renderChatsInDrawer) {
            (window as any).renderChatsInDrawer();
        }

        if ((window as any).chatListModule) {
            (window as any).chatListModule._renderRecentChats();
        }

        if ((window as any).profileUI?.renderHistoryChatsList) {
            (window as any).profileUI.renderHistoryChatsList(
                (window as any).profileUI.currentFilter || 'all'
            );
        }
    }

    // ==========================================
    // УПРАВЛЕНИЕ ЧАТАМИ
    // ==========================================

    /**
     * Создать новый чат
     */
    createNewChat(): Chat | null {
        this.deleteEmptyCurrentChat();

        const chat = this.chatStore.createTempChat();
        if (chat) {
            chat.synced = false;
            this.chatStore.save();
            this.updateLists();
        }

        return chat || null;
    }

    /**
     * Удалить пустой текущий чат
     */
    private deleteEmptyCurrentChat(): boolean {
        const active = this.chatStore.getActiveChat();
        if (!active || this.chatStore.hasRealMessages(active)) return false;

        const topic = active.topic || this.currentTopic;
        this.chatStore.deleteChat(active.id);
        this.chatStore.save();

        return true;
    }

    /**
     * Очистить все пустые чаты
     */
    cleanupAllEmptyChats(): number {
        let cleaned = 0;

        for (const [topic, chats] of Object.entries(this.chatStore.histories)) {
            if (!chats) continue;

            for (const chat of chats) {
                if (!this.chatStore.hasRealMessages(chat)) {
                    const topicChats = this.chatStore.getChats(topic);
                    if (topicChats.length > 1) {
                        this.chatStore.deleteChat(chat.id);
                        cleaned++;
                    }
                }
            }
        }

        if (cleaned > 0) {
            this.chatStore.save();
        }

        return cleaned;
    }

    /**
     * Обновить UI
     */
    refreshUI(): void {
        this.updateLists();
    }

    /**
     * Показать интерфейс чата
     */
    showChatInterface(): void {
        // Заглушка для совместимости
    }

    /**
     * Загрузить активные сообщения чата
     */
    loadActiveChatMessages(): void {
        // Заглушка для совместимости
    }

    // ==========================================
    // ОЧИСТКА
    // ==========================================

    /**
     * Уничтожить подписки
     */
    destroy(): void {
        for (const unsub of this.subscriptions) {
            try {
                unsub();
            } catch (e) {
                console.warn('Ошибка отписки ChatUI:', e);
            }
        }
        this.subscriptions = [];
        console.log('📡 ChatUI отписан от событий');
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let chatUIInstance: ChatUI | null = null;

/**
 * Получить экземпляр ChatUI
 */
export function getChatUI(): ChatUI {
    if (!chatUIInstance) {
        chatUIInstance = ChatUI.getInstance();
    }
    return chatUIInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).ChatUI = ChatUI;
    (window as any).chatUI = getChatUI();
}

// Глобальные функции для совместимости
if (typeof window !== 'undefined') {
    (window as any).getCurrentActiveChat = () => getChatStore().getActiveChat();

    (window as any).renameChat = function(event: Event, chatId: string) {
        if (event) event.stopPropagation();

        if (!navigator.onLine) {
            if ((window as any).tg?.showAlert) {
                (window as any).tg.showAlert('Нет интернета. Переименование недоступно.');
            }
            return;
        }

        const found = getChatStore().findChatById(chatId);
        if (!found) {
            if ((window as any).tg?.showAlert) {
                (window as any).tg.showAlert('Чат не найден');
            }
            return;
        }

        const newTitle = prompt('Введите новое название:', found.chat.title || 'Без названия');
        if (newTitle?.trim()) {
            const trimmed = newTitle.trim();
            getChatStore().renameChat(chatId, trimmed);

            getChatUI().updateLists();

            if (getUserStore().canSync() && (window as any).chatService) {
                (window as any).chatService.renameChat(chatId, trimmed);
            }

            if (getUIRenderer()) {
                getUIRenderer().showToast('✏️ Чат переименован', 'success', 1500);
            }
        }
    };

    (window as any).deleteChat = async function(event: Event, chatId: string) {
        if (event) event.stopPropagation();

        if (!navigator.onLine) {
            if ((window as any).tg?.showAlert) {
                (window as any).tg.showAlert('Нет интернета. Удаление недоступно.');
            }
            return;
        }

        const found = getChatStore().findChatById(chatId);
        if (!found || found.chat.deleted_at) return;

        const confirmMsg = (window as any).getLangString ? (window as any).getLangString('confirm_del_chat') : 'Удалить чат в корзину?';

        const action = async () => {
            if (!getChatStore().deleteChat(chatId)) {
                if ((window as any).tg?.showAlert) {
                    (window as any).tg.showAlert('Не удалось удалить чат');
                }
                return;
            }

            if (getUserStore().canSync() && (window as any).chatService) {
                await (window as any).chatService.deleteChat(chatId);
            }

            getChatUI().updateLists();

            if ((window as any).updateTrashCount) {
                setTimeout((window as any).updateTrashCount, 300);
            }

            if (getUIRenderer()) {
                getUIRenderer().showToast('🗑️ Чат отправлен в корзину', 'info', 1500);
            }

            const active = getChatStore().getActiveChat();
            if (!active || !getChatStore().hasRealMessages(active)) {
                if ((window as any).moduleLoader) {
                    (window as any).moduleLoader.load('chat-list');
                }
            }
        };

        if ((window as any).tg?.showConfirm) {
            (window as any).tg.showConfirm(confirmMsg, (ok: boolean) => { if (ok) action(); });
        } else if (confirm(confirmMsg)) {
            action();
        }
    };
}

// Импорты для глобальных функций
import { getUserStore } from '@store/UserStore';

console.log('✅ ChatUI v4.0.0 (TypeScript) загружен');
