// ============================================
// src/modules/ui/renderer.ts
// Описание: Базовый рендеринг UI-элементов (С ЛЮСИД)
// Версия: 3.0.0 - TypeScript
// ============================================

import { getChatStore, Message } from '@store/ChatStore';
import { getUserStore } from '@store/UserStore';
import { getEventBus } from '@core/event-bus';
import { generateUUID } from '@utils/helpers';
import { sanitizeHTML } from '@utils/validators';

/**
 * Тип сообщения для рендеринга
 */
export type RenderMessageType = 'user-msg' | 'ai-msg' | 'system';

/**
 * Опции рендеринга
 */
export interface RenderMessageOptions {
    msgId?: string;
    isFavorite?: boolean;
    actions?: boolean;
}

/**
 * UI Рендерер
 */
export class UIRenderer {
    private static instance: UIRenderer | null = null;

    private chatStore = getChatStore();
    private userStore = getUserStore();
    private eventBus = getEventBus();

    private constructor() {
        this.subscribeToEvents();
    }

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): UIRenderer {
        if (!UIRenderer.instance) {
            UIRenderer.instance = new UIRenderer();
        }
        return UIRenderer.instance;
    }

    // ==========================================
    // ПОДПИСКА НА СОБЫТИЯ
    // ==========================================

    private subscribeToEvents(): void {
        // Обновление баланса
        this.eventBus.on('tasks:balance_changed', (data) => {
            this.updateCoinDisplay(data.newBalance);
        });

        // Обновление токенов
        this.eventBus.on('tasks:tokens_changed', (data) => {
            this.updateTokensDisplay(data.newTokens);
        });

        // Обновление лимитов
        this.eventBus.on('user:usage_incremented', (data) => {
            this.updateLimitDisplay(data);
        });

        this.eventBus.on('user:role_changed', (data) => {
            this.updateLimitDisplay({ used: this.userStore.usedToday, limit: data.dailyLimit });
        });

        // Обновление счетчика корзины
        this.eventBus.on('chat:deleted', () => {
            if ((window as any).updateTrashCount) {
                setTimeout((window as any).updateTrashCount, 300);
            }
        });

        this.eventBus.on('chat:restored', () => {
            if ((window as any).updateTrashCount) {
                setTimeout((window as any).updateTrashCount, 300);
            }
        });

        // Обновление статуса синхронизации
        this.eventBus.on('sync:token_updated', () => {
            this.showSyncStatus('success');
        });

        console.log('📡 UIRenderer подписан на события');
    }

    // ==========================================
    // ОБНОВЛЕНИЕ ОТОБРАЖЕНИЙ
    // ==========================================

    /**
     * Обновить отображение монет
     */
    private updateCoinDisplay(balance: number): void {
        document.querySelectorAll('.coin-amount').forEach(el => {
            el.textContent = String(balance || 0);
        });

        const drawerCoins = document.getElementById('drawer-coins-amount');
        if (drawerCoins) drawerCoins.textContent = String(balance || 0);

        const headerCoins = document.getElementById('header-coins-amount');
        if (headerCoins) headerCoins.textContent = String(balance || 0);
    }

    /**
     * Обновить отображение токенов
     */
    private updateTokensDisplay(tokens: number): void {
        const tokensEl = document.getElementById('tasks-tokens');
        if (tokensEl) tokensEl.textContent = String(tokens || 0);
    }

    /**
     * Обновить отображение лимитов
     */
    private updateLimitDisplay(data: { used: number; limit: number }): void {
        const total = data.limit || this.userStore.dailyLimit || 0;
        const used = data.used || this.userStore.usedToday || 0;
        const percent = total > 0 ? Math.min((used / total) * 100, 100) : 0;

        // Обновляем в ProfileModule
        const totalEl = document.getElementById('profile-limit-total');
        const usedEl = document.getElementById('profile-limit-used');
        const remainingEl = document.getElementById('profile-limit-remaining');
        const barEl = document.getElementById('profile-limit-bar');

        if (totalEl) totalEl.textContent = total >= 9999 ? '∞' : String(total);
        if (usedEl) usedEl.textContent = String(used);
        if (remainingEl) remainingEl.textContent = String(Math.max(0, total - used));
        if (barEl) barEl.style.width = total >= 9999 ? '100%' : `${percent}%`;

        // Обновляем в Header
        const limitInfo = document.getElementById('limit-info');
        if (limitInfo) {
            const limitLabel = (window as any).getLangString ? (window as any).getLangString('limit') : 'Лимит';
            if (total >= 9999) {
                limitInfo.innerText = `${limitLabel}: ∞`;
            } else {
                limitInfo.innerText = `${limitLabel}: ${used}/${total}`;
            }
        }
    }

    // ==========================================
    // РЕНДЕРИНГ СООБЩЕНИЙ
    // ==========================================

    /**
     * Рендерить сообщение в чате
     */
    renderMessage(
        text: string,
        type: RenderMessageType,
        msgId: string | null = null,
        isFavorite: boolean = false
    ): HTMLElement | null {
        const container = document.getElementById('chat-container');
        if (!container) return null;

        const finalMsgId = msgId || generateUUID();
        const msgDiv = document.createElement('div');
        msgDiv.className = `msg ${type} msg-animated`;
        msgDiv.id = `msg-block-${finalMsgId}`;

        if (type === 'ai-msg') {
            this.renderAIMessage(msgDiv, text, finalMsgId, isFavorite);
        } else {
            this.renderUserMessage(msgDiv, text, finalMsgId);
        }

        container.appendChild(msgDiv);
        container.scrollTop = container.scrollHeight;
        return msgDiv;
    }

    /**
     * Рендерить AI сообщение
     */
    private renderAIMessage(container: HTMLElement, text: string, msgId: string, isFavorite: boolean): void {
        const contentDiv = document.createElement('div');
        contentDiv.style.width = '100%';

        try {
            if (typeof (window as any).marked !== 'undefined') {
                let html = (window as any).marked.parse(text);
                html = html.replace(
                    /<table[^>]*>([\s\S]*?)<\/table>/gi,
                    '<div class="table-wrapper"><table>$1</table></div>'
                );
                contentDiv.innerHTML = sanitizeHTML(html);

                // Добавляем кнопки копирования для кода
                contentDiv.querySelectorAll('pre').forEach((pre) => {
                    const codeText = pre.querySelector('code')?.innerText || pre.innerText;
                    const wrapper = document.createElement('div');
                    wrapper.style.cssText = 'position:relative; width:100%;';
                    pre.parentNode?.insertBefore(wrapper, pre);
                    wrapper.appendChild(pre);

                    const copyBtn = document.createElement('button');
                    copyBtn.className = 'code-copy-btn';
                    copyBtn.innerText = '📋 Копировать';
                    copyBtn.onclick = () => {
                        navigator.clipboard.writeText(codeText).then(() => {
                            copyBtn.innerText = '✅ Готово!';
                            setTimeout(() => copyBtn.innerText = '📋 Копировать', 1500);
                        });
                    };
                    wrapper.appendChild(copyBtn);
                });
            } else {
                contentDiv.textContent = text;
            }
        } catch (e) {
            contentDiv.textContent = text;
        }

        container.appendChild(contentDiv);

        const isWelcome = text.includes('Привет') || text.includes('Welcome');
        if (!isWelcome) {
            const actions = this.createMessageActions(msgId, isFavorite);
            container.appendChild(actions);
        }
    }

    /**
     * Рендерить пользовательское сообщение
     */
    private renderUserMessage(container: HTMLElement, text: string, msgId: string): void {
        const textSpan = document.createElement('span');
        textSpan.textContent = text;
        container.appendChild(textSpan);

        const delBtn = document.createElement('button');
        delBtn.className = 'action-btn';
        delBtn.style.cssText = 'background:transparent; border:none; outline:none; cursor:pointer; margin-left:8px; opacity:0.4; padding:0; vertical-align:middle;';
        delBtn.innerHTML = '<i data-lucide="trash-2" style="width:16px;height:16px;"></i>';
        delBtn.onclick = () => {
            const activeChat = this.chatStore.getActiveChat();
            if (activeChat && (window as any).messageService) {
                (window as any).messageService.deleteMessage(activeChat.id, msgId);
            }
            const domBlock = document.getElementById(`msg-block-${msgId}`);
            if (domBlock) {
                domBlock.style.transition = 'all 0.25s ease';
                domBlock.style.opacity = '0';
                domBlock.style.transform = 'scale(0.95)';
                setTimeout(() => domBlock.remove(), 250);
            }
        };
        container.appendChild(delBtn);

        setTimeout(() => {
            if (typeof (window as any).lucide !== 'undefined') {
                (window as any).lucide.createIcons();
            }
        }, 50);
    }

    /**
     * Создать действия для сообщения
     */
    private createMessageActions(msgId: string, isFavorite: boolean): HTMLElement {
        const actions = document.createElement('div');
        actions.className = 'msg-actions';
        actions.innerHTML = `
            <button class="action-btn" data-tooltip="📋" onclick="window.chatSend.copyMsgText(this, '${msgId}')">
                <i data-lucide="copy"></i>
            </button>
            <button class="action-btn" data-tooltip="🔗" onclick="window.chatSend.shareMsgText(this, '${msgId}')">
                <i data-lucide="share-2"></i>
            </button>
            <button class="action-btn ${isFavorite ? 'is-favorite' : ''}" onclick="window.chatSend.toggleFavoriteMsg(this, '${msgId}')">
                <i data-lucide="${isFavorite ? 'heart' : 'heart'}"></i>
            </button>
            <button class="action-btn" style="margin-left:auto; background:rgba(231,76,60,0.05); color:#e74c3c;" onclick="window.chatSend.deleteMessage('${msgId}')">
                <i data-lucide="trash-2"></i>
            </button>
        `;

        setTimeout(() => {
            if (typeof (window as any).lucide !== 'undefined') {
                (window as any).lucide.createIcons();
            }
        }, 50);

        return actions;
    }

    // ==========================================
    // ИНДИКАТОР "ПЕЧАТАЕТ"
    // ==========================================

    /**
     * Показать индикатор печати
     */
    showSkeleton(): void {
        const container = document.getElementById('chat-container');
        if (!container) return;

        const existing = document.getElementById('ai-typing-indicator');
        if (existing) return;

        const indicator = document.createElement('div');
        indicator.id = 'ai-typing-indicator';
        indicator.className = 'typing-indicator';
        indicator.innerHTML = `
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
        `;
        container.appendChild(indicator);
        container.scrollTop = container.scrollHeight;
    }

    /**
     * Скрыть индикатор печати
     */
    hideSkeleton(): void {
        const indicator = document.getElementById('ai-typing-indicator');
        if (indicator) {
            indicator.remove();
        }
    }

    /**
     * Рендерить приветственное сообщение
     */
    renderWelcome(text: string): void {
        const container = document.getElementById('chat-container');
        if (!container) return;

        const msgDiv = document.createElement('div');
        msgDiv.className = 'msg ai-msg welcome-msg';
        msgDiv.id = 'welcome-message';

        const contentContainer = document.createElement('div');
        contentContainer.style.width = '100%';

        if (typeof (window as any).marked !== 'undefined') {
            contentContainer.innerHTML = (window as any).marked.parse(text);
        } else {
            contentContainer.textContent = text;
        }

        msgDiv.appendChild(contentContainer);
        container.appendChild(msgDiv);
        container.scrollTop = container.scrollHeight;
    }

    // ==========================================
    // СТАТУСЫ
    // ==========================================

    /**
     * Показать статус синхронизации
     */
    showSyncStatus(status: 'syncing' | 'success' | 'error' | 'offline', isError: boolean = false): void {
        const indicator = document.getElementById('chat-model-indicator');
        if (!indicator) return;

        const originalText = indicator.innerText;

        switch (status) {
            case 'syncing':
                indicator.innerHTML = '<span style="opacity:0.7;">🔄 синхр...</span>';
                setTimeout(() => {
                    if (indicator.innerHTML === '<span style="opacity:0.7;">🔄 синхр...</span>') {
                        indicator.innerText = originalText;
                    }
                }, 2000);
                break;
            case 'success':
                indicator.innerHTML = '<span style="color: #27ae60;">✓ синхр.</span>';
                setTimeout(() => {
                    if (indicator.innerHTML === '<span style="color: #27ae60;">✓ синхр.</span>') {
                        indicator.innerText = originalText;
                    }
                }, 1500);
                break;
            case 'error':
            case 'offline':
                indicator.innerHTML = '<span style="color: #e74c3c;">⚠️ офлайн</span>';
                break;
            default:
                indicator.innerText = originalText;
        }
    }

    // ==========================================
    // TOAST
    // ==========================================

    /**
     * Показать toast уведомление
     */
    showToast(message: string, type: 'info' | 'success' | 'warning' | 'error' = 'info', duration: number = 2000): void {
        let toast = document.getElementById('custom-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'custom-toast';
            document.body.appendChild(toast);
        }

        toast.textContent = message;
        toast.className = `show ${type}`;
        toast.style.display = 'block';

        clearTimeout((toast as any)._timeout);
        (toast as any)._timeout = setTimeout(() => {
            toast!.className = 'hide';
            setTimeout(() => {
                if (toast) toast!.style.display = 'none';
            }, 300);
        }, duration);
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let uiRendererInstance: UIRenderer | null = null;

/**
 * Получить экземпляр UIRenderer
 */
export function getUIRenderer(): UIRenderer {
    if (!uiRendererInstance) {
        uiRendererInstance = UIRenderer.getInstance();
    }
    return uiRendererInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).UIRenderer = UIRenderer;
    (window as any).uiRenderer = getUIRenderer();
}

console.log('✅ UIRenderer v3.0.0 (TypeScript) загружен');
