// ============================================
// src/types/global.d.ts
// Глобальные типы для приложения
// ============================================

import { EventBus } from '@core/event-bus';
import { NavigationState } from '@core/navigation-state';
import { HeaderManager } from '@core/header-manager';
import { ModuleLoader } from '@core/module-loader';
import { ModalManager } from '@core/modal-manager';
import { BackButtonManager } from '@core/back-button-manager';
import { ThemeManager } from '@core/theme-manager';

import { ChatStore } from '@store/ChatStore';
import { UserStore } from '@store/UserStore';
import { OrganizerStore } from '@store/OrganizerStore';
import { TasksStore } from '@store/TasksStore';

import { ApiClient } from '@services/api';
import { AuthService } from '@services/auth';
import { ChatService } from '@services/chats';
import { MessageService } from '@services/messages';
import { OrganizerService } from '@services/organizer';
import { SyncService } from '@services/sync';
import { DeviceService } from '@services/device';

import { UIRenderer } from '@modules/ui/renderer';
import { ChatUI } from '@modules/ui/chat-ui';
import { ProfileUI } from '@modules/ui/profile-ui';
import { OrganizerUI } from '@modules/ui/organizer-ui';

import { ChatModule } from '@modules/chat/ChatModule';
import { ChatListModule } from '@modules/chat-list/ChatListModule';
import { DashboardModule } from '@modules/dashboard/DashboardModule';
import { GamesModule } from '@modules/games/GamesModule';
import { OrganizerModule } from '@modules/organizer/OrganizerModule';
import { ProfileModule } from '@modules/profile/ProfileModule';
import { TasksModule } from '@modules/tasks/TasksModule';

import { TetrisGame } from '@modules/games/tetris/TetrisGame';
import { SudokuGame } from '@modules/games/sudoku/SudokuGame';

declare global {
  // ==========================================
  // TELEGRAM
  // ==========================================
  interface TelegramWebApp {
    initData: string;
    initDataUnsafe: {
      user?: {
        id: number;
        first_name: string;
        last_name?: string;
        username?: string;
        language_code?: string;
        photo_url?: string;
      };
      chat?: {
        id: number;
        type: string;
      };
    };
    colorScheme: 'light' | 'dark';
    themeParams: {
      bg_color: string;
      text_color: string;
      hint_color: string;
      link_color: string;
      button_color: string;
      button_text_color: string;
    };
    isExpanded: boolean;
    platform: string;
    version: string;
    expand(): void;
    ready(): void;
    close(): void;
    setHeaderColor(color: string): void;
    setBackgroundColor(color: string): void;
    onEvent(event: string, callback: (data?: any) => void): void;
    offEvent(event: string, callback: (data?: any) => void): void;
    showAlert(message: string, callback?: () => void): void;
    showConfirm(message: string, callback?: (ok: boolean) => void): void;
    openTelegramLink(url: string): void;
    requestFullscreen(): void;
    BackButton: {
      show(): void;
      hide(): void;
      onClick(callback: () => void): void;
      offClick(): void;
    };
    MainButton: {
      show(): void;
      hide(): void;
      setText(text: string): void;
      setColor(color: string): void;
      setTextColor(color: string): void;
      onClick(callback: () => void): void;
    };
  }

  interface Window {
    // ==========================================
    // TELEGRAM
    // ==========================================
    Telegram: {
      WebApp: TelegramWebApp;
    };
    tg: TelegramWebApp;

    // ==========================================
    // THIRD PARTY
    // ==========================================
    marked: any;
    DOMPurify: any;
    lucide: {
      createIcons(options?: any): void;
    };
    eruda: any;
    supabase: any;

    // ==========================================
    // CORE
    // ==========================================
    eventBus: EventBus;
    navigationState: NavigationState;
    headerManager: HeaderManager;
    moduleLoader: ModuleLoader;
    modalManager: ModalManager;
    backButtonManager: BackButtonManager;
    themeManager: ThemeManager;
    navigation: any;

    // ==========================================
    // STORE
    // ==========================================
    BaseStore: any;
    chatStore: ChatStore;
    userStore: UserStore;
    organizerStore: OrganizerStore;
    tasksStore: TasksStore;

    // ==========================================
    // SERVICES
    // ==========================================
    apiClient: ApiClient;
    authService: AuthService;
    chatService: ChatService;
    messageService: MessageService;
    organizerService: OrganizerService;
    syncService: SyncService;
    deviceService: DeviceService;

    // ==========================================
    // UI
    // ==========================================
    uiRenderer: UIRenderer;
    chatUI: ChatUI;
    profileUI: ProfileUI;
    organizerUI: OrganizerUI;

    // ==========================================
    // MODULES
    // ==========================================
    chatModule: ChatModule;
    chatListModule: ChatListModule;
    dashboardModule: DashboardModule;
    gamesModule: GamesModule;
    organizerModule: OrganizerModule;
    profileModule: ProfileModule;
    tasksModule: TasksModule;

    // ==========================================
    // GAME CLASSES
    // ==========================================
    TetrisGame: typeof TetrisGame;
    SudokuGame: typeof SudokuGame;

    // ==========================================
    // GLOBAL FUNCTIONS (Legacy compatibility)
    // ==========================================
    getLangString(key: string): string;
    applyUiLocalization(): void;
    updateLimitDisplay(): void;
    formatDate(dateStr: string): string;
    pluralize(count: number, one: string, two: string, five: string): string;
    generateUUID(): string;
    sleep(ms: number): Promise<void>;
    safeJSONParse(str: string, fallback: any): any;
    truncate(str: string, maxLength: number, suffix?: string): string;
    isEmptyObject(obj: any): boolean;
    cloneObject(obj: any): any;
    debounce(func: Function, wait: number): Function;
    throttle(func: Function, limit: number): Function;
    isValidUUID(uuid: string): boolean;
    isValidTopic(topic: string): boolean;
    isValidMessageLength(text: string, maxLength?: number): boolean;
    isValidEmail(email: string): boolean;
    isValidURL(url: string): boolean;
    isValidFileSize(bytes: number, maxMB?: number): boolean;
    isValidImageBase64(str: string): boolean;
    sanitizeHTML(html: string): string;

    // ==========================================
    // GLOBAL FUNCTIONS (App)
    // ==========================================
    openDrawer(): void;
    closeDrawer(options?: { instant?: boolean }): void;
    openChat(chatId: string, topic: string): void;
    goToChatList(): void;
    goToProfile(): void;
    goToTasks(): void;
    fullDataReload(): Promise<boolean>;
    showFavoritesModal(): void;
    showTrashModal(): void;
    showContextModal(chatId: string): void;
    updateTrashCount(): void;
    updateRealtimeIndicator(status: string): void;
    updateHeader(config: any): void;
    updateChatTitle(title: string): void;
    refreshBackButton(): void;
    handleNewChatClick(): void;
    exportLocalArchive(): Promise<void>;
    exportCloudArchive(): Promise<void>;
    downloadJSON(data: any, filename: string): void;
    initExportButtons(): void;
    clearCacheFromProfile(): void;
    goBackFromProfile(): void;
    showOfflineBanner(message?: string): void;
    hideOfflineBanner(): void;

    // ==========================================
    // GLOBAL CONFIG
    // ==========================================
    config: {
      dailyLimit: number;
      role: string;
      serverModels: Record<string, boolean>;
      syncEnabled: boolean;
    };
    currentTopic: string;
    currentModel: string;
    currentFilter: string;
    usedToday: number;
    allUserKeys: Record<string, any>;
    isSendingMessage: boolean;
    isVoiceRecording: boolean;
    mediaRecorder: MediaRecorder | null;
    audioChunks: Blob[];
    topicNames: Record<string, string>;
    topicShortNames: Record<string, string>;
    welcomeTexts: Record<string, string>;
    modelNames: Record<string, string>;

    // ==========================================
    // CHAT MEDIA
    // ==========================================
    currentAttachedImageBase64: string | null;
    initMediaAttachment(): void;
    triggerMediaSelector(): void;
    processAndResizeImage(file: File): void;
    renderImagePreview(): void;
    clearImagePreviewDOM(): void;
    clearImageAttachment(): void;

    // ==========================================
    // CHAT SEND
    // ==========================================
    chatSend: any;
    sendMessage(): Promise<void>;
    streamAiResponse(
      historyMessages: any[],
      topic: string,
      userLang: string,
      attachedImage: string | null,
      chatId: string
    ): Promise<boolean>;
    toggleVoiceRecording(btn: HTMLElement): Promise<void>;
    expandInputArea(): void;
    collapseInputArea(): void;
    clearUserText(e?: Event): void;

    // ==========================================
    // DRAWER
    // ==========================================
    renderChatsInDrawer(): void;
    updateDrawerCoins(): void;
    updateCoinsDisplay(): void;
    updateDrawerUserInfo(): void;
    updateDrawerRole(role: string): void;
    updateThemeLabel(theme: string): void;

    // ==========================================
    // TRASH
    // ==========================================
    openTrashModal(): void;
    closeTrashModal(): void;
    loadTrashContent(): void;
    restoreFromTrash(chatId: string): Promise<void>;
    permanentDelete(chatId: string): Promise<void>;
    clearAllTrash(): void;

    // ==========================================
    // ORGANIZER
    // ==========================================
    organizerStore: OrganizerStore;
    organizerService: OrganizerService;

    // ==========================================
    // SYNC UPLOAD
    // ==========================================
    uploadLocalDataToCloud(): Promise<boolean>;
  }

  // ==========================================
  // MODULE CLASSES (для регистрации)
  // ==========================================
  interface ModuleClass {
    new(container: HTMLElement): any;
    _instance?: any;
  }

  interface ModuleLoaderInterface {
    register(moduleName: string, ModuleClass: ModuleClass): void;
    load(moduleName: string, params?: any, options?: any): Promise<any>;
    show(moduleName: string, params?: any): void;
    back(): void;
    currentModule: string | null;
    currentParams: any;
    isLoaded(moduleName: string): boolean;
    getModule(moduleName: string): any;
  }
}

export {};
