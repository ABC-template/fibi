// ============================================
// src/store/BaseStore.d.ts
// Типы для BaseStore (для обратной совместимости с JS)
// ============================================

export interface BaseStoreInterface<T = any> {
    load(): T;
    save(): void;
    getJWT(): string | null;
    saveJWT(token: string | null): void;
    clearJWT(): void;
    getSyncToken(): string | null;
    saveSyncToken(token: string | null): void;
    clearSyncToken(): void;
    get<K extends keyof T>(key: K, defaultValue?: T[K] | null): T[K] | null;
    set<K extends keyof T>(key: K, value: T[K]): T[K];
    remove<K extends keyof T>(key: K): void;
    has<K extends keyof T>(key: K): boolean;
    getAll(): T;
    setAll(data: Partial<T>): void;
    reset(): void;
    reload(): T;
    clear(): void;
    on(event: string, callback: (data: any, sender?: any) => void, context?: any): () => void;
    once(event: string, callback: (data: any, sender?: any) => void, context?: any): () => void;
    off(event: string, listenerId: string): boolean;
    offAll(context: any): number;
}

export declare class BaseStore<T = any> implements BaseStoreInterface<T> {
    constructor(storeName: string);
    load(): T;
    save(): void;
    getJWT(): string | null;
    saveJWT(token: string | null): void;
    clearJWT(): void;
    getSyncToken(): string | null;
    saveSyncToken(token: string | null): void;
    clearSyncToken(): void;
    get<K extends keyof T>(key: K, defaultValue?: T[K] | null): T[K] | null;
    set<K extends keyof T>(key: K, value: T[K]): T[K];
    remove<K extends keyof T>(key: K): void;
    has<K extends keyof T>(key: K): boolean;
    getAll(): T;
    setAll(data: Partial<T>): void;
    reset(): void;
    reload(): T;
    clear(): void;
    on(event: string, callback: (data: any, sender?: any) => void, context?: any): () => void;
    once(event: string, callback: (data: any, sender?: any) => void, context?: any): () => void;
    off(event: string, listenerId: string): boolean;
    offAll(context: any): number;
}
