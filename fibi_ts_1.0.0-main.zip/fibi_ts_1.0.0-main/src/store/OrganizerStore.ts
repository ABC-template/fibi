// ============================================
// src/store/OrganizerStore.ts
// Описание: To-Do, напоминания, трекеры
// Версия: 4.0.0 - TypeScript
// ============================================

import { BaseStore } from './BaseStore';
import { getEventBus } from '@core/event-bus';

/**
 * Интерфейс задачи To-Do
 */
export interface TodoItem {
    id: string;
    text: string;
    topic: string;
    isCompleted: boolean;
    createdAt: string;
}

/**
 * Интерфейс напоминания
 */
export interface Reminder {
    id: string;
    user_id: number;
    topic_id: string;
    task_text: string;
    trigger_at: string;
    status: 'pending' | 'sent' | 'failed';
    created_at: string;
}

/**
 * Интерфейс трекера
 */
export interface Tracker {
    id: string;
    user_id: number;
    topic_id: string;
    title: string;
    settings: Record<string, any>;
    status: 'active' | 'paused' | 'archived';
    created_at: string;
    updated_at: string;
}

/**
 * Интерфейс лога трекера
 */
export interface TrackerLog {
    id: string;
    tracker_id: string;
    value: string;
    note_text: string | null;
    logged_date: string;
    created_at: string;
}

/**
 * Интерфейс данных OrganizerStore
 */
interface OrganizerStoreData {
    todoItems: TodoItem[];
    reminders: Reminder[];
    trackers: Tracker[];
    trackerLogs: TrackerLog[];
}

/**
 * Хранилище органайзера
 */
export class OrganizerStore extends BaseStore<OrganizerStoreData> {
    private static instance: OrganizerStore | null = null;

    private constructor() {
        super('organizer');
        this.load();

        // Инициализация дефолтных значений
        if (Object.keys(this._data).length === 0) {
            this._data = {
                todoItems: [],
                reminders: [],
                trackers: [],
                trackerLogs: []
            };
            this.save();
        }

        // Гарантируем наличие всех полей
        if (!this._data.todoItems) this._data.todoItems = [];
        if (!this._data.reminders) this._data.reminders = [];
        if (!this._data.trackers) this._data.trackers = [];
        if (!this._data.trackerLogs) this._data.trackerLogs = [];
    }

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): OrganizerStore {
        if (!OrganizerStore.instance) {
            OrganizerStore.instance = new OrganizerStore();
        }
        return OrganizerStore.instance;
    }

    /**
     * Генерация ID
     */
    protected generateId(): string {
        return 'org_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
    }

    // ==========================================
    // TO-DO
    // ==========================================

    /**
     * Добавить задачу
     */
    addTodo(text: string, topic?: string): TodoItem {
        const item: TodoItem = {
            id: this.generateId(),
            text: text,
            topic: topic || (window as any).currentTopic || 'code',
            isCompleted: false,
            createdAt: new Date().toISOString()
        };

        this._data.todoItems.unshift(item);
        this.save();

        this._emitChange('organizer:todo_added', {
            todo: item,
            topic: item.topic
        });

        return item;
    }

    /**
     * Переключить статус задачи
     */
    toggleTodo(id: string): TodoItem | null {
        const item = this._data.todoItems.find(t => t.id === id);
        if (item) {
            item.isCompleted = !item.isCompleted;
            this.save();

            this._emitChange('organizer:todo_toggled', {
                id,
                isCompleted: item.isCompleted,
                todo: item
            });
        }
        return item || null;
    }

    /**
     * Удалить задачу
     */
    deleteTodo(id: string): void {
        const deleted = this._data.todoItems.find(t => t.id === id);
        this._data.todoItems = this._data.todoItems.filter(t => t.id !== id);
        this.save();

        this._emitChange('organizer:todo_deleted', {
            id,
            todo: deleted
        });
    }

    /**
     * Получить задачи по теме
     */
    getTodoByTopic(topic: string): TodoItem[] {
        if (!topic || topic === 'all') {
            return this._data.todoItems;
        }
        return this._data.todoItems.filter(t => t.topic === topic);
    }

    /**
     * Получить статистику задач
     */
    getTodoStats(topic: string): { total: number; completed: number; pending: number } {
        const items = topic && topic !== 'all' ? this.getTodoByTopic(topic) : this._data.todoItems;
        const total = items.length;
        const completed = items.filter(t => t.isCompleted).length;
        return { total, completed, pending: total - completed };
    }

    // ==========================================
    // НАПОМИНАНИЯ
    // ==========================================

    /**
     * Установить список напоминаний
     */
    setReminders(reminders: Reminder[]): void {
        this._data.reminders = reminders;
        this.save();
        this._emitChange('organizer:reminders_updated', { count: reminders.length });
    }

    /**
     * Добавить напоминание
     */
    addReminder(reminder: Reminder): Reminder {
        this._data.reminders.push(reminder);
        this.save();
        this._emitChange('organizer:reminder_added', { reminder });
        return reminder;
    }

    /**
     * Удалить напоминание
     */
    deleteReminder(id: string): void {
        const deleted = this._data.reminders.find(r => r.id === id);
        this._data.reminders = this._data.reminders.filter(r => r.id !== id);
        this.save();
        this._emitChange('organizer:reminder_deleted', { id, reminder: deleted });
    }

    /**
     * Получить напоминания по теме
     */
    getRemindersByTopic(topic: string): Reminder[] {
        return this._data.reminders.filter(r =>
            r.topic_id === topic && r.status === 'pending'
        );
    }

    // ==========================================
    // ТРЕКЕРЫ
    // ==========================================

    /**
     * Установить список трекеров и логов
     */
    setTrackers(trackers: Tracker[], logs: TrackerLog[]): void {
        this._data.trackers = trackers || [];
        this._data.trackerLogs = logs || [];
        this.save();

        this._emitChange('organizer:trackers_updated', {
            trackers: trackers.length,
            logs: logs.length
        });
    }

    /**
     * Добавить трекер
     */
    addTracker(tracker: Tracker): Tracker {
        this._data.trackers.push(tracker);
        this.save();

        this._emitChange('organizer:tracker_added', { tracker });
        return tracker;
    }

    /**
     * Удалить трекер
     */
    deleteTracker(id: string): void {
        const deleted = this._data.trackers.find(t => t.id === id);
        this._data.trackers = this._data.trackers.filter(t => t.id !== id);
        this._data.trackerLogs = this._data.trackerLogs.filter(l => l.tracker_id !== id);
        this.save();

        this._emitChange('organizer:tracker_deleted', { id, tracker: deleted });
    }

    /**
     * Добавить лог трекера
     */
    addTrackerLog(log: TrackerLog): TrackerLog {
        this._data.trackerLogs.push(log);
        this.save();

        this._emitChange('organizer:tracker_log_added', { log });
        return log;
    }

    /**
     * Удалить лог трекера
     */
    deleteTrackerLog(id: string): void {
        const deleted = this._data.trackerLogs.find(l => l.id === id);
        this._data.trackerLogs = this._data.trackerLogs.filter(l => l.id !== id);
        this.save();

        this._emitChange('organizer:tracker_log_deleted', { id, log: deleted });
    }

    /**
     * Получить трекеры по теме
     */
    getTrackersByTopic(topic: string): Tracker[] {
        return this._data.trackers.filter(t =>
            t.topic_id === topic && t.status === 'active'
        );
    }

    /**
     * Получить логи для трекера
     */
    getLogsForTracker(trackerId: string): TrackerLog[] {
        return this._data.trackerLogs
            .filter(l => l.tracker_id === trackerId)
            .sort((a, b) =>
                new Date(b.logged_date).getTime() - new Date(a.logged_date).getTime()
            );
    }

    /**
     * Получить все трекеры
     */
    getAllTrackers(): Tracker[] {
        return this._data.trackers;
    }

    /**
     * Получить все логи
     */
    getAllTrackerLogs(): TrackerLog[] {
        return this._data.trackerLogs;
    }

    // ==========================================
    // СБРОС
    // ==========================================

    /**
     * Полный сброс данных
     */
    reset(): void {
        this._data = {
            todoItems: [],
            reminders: [],
            trackers: [],
            trackerLogs: []
        };
        this.save();
        this._emitChange('organizer:reset', {});
        console.log('🔄 OrganizerStore сброшен');
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let organizerStoreInstance: OrganizerStore | null = null;

/**
 * Получить экземпляр OrganizerStore
 */
export function getOrganizerStore(): OrganizerStore {
    if (!organizerStoreInstance) {
        organizerStoreInstance = OrganizerStore.getInstance();
    }
    return organizerStoreInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).OrganizerStore = OrganizerStore;
    (window as any).organizerStore = getOrganizerStore();
}

console.log('✅ OrganizerStore v4.0.0 (TypeScript) загружен');
