// ============================================
// src/store/BaseStore.ts
// Описание: Базовый класс для всех хранилищ с изоляцией данных
// Версия: 3.0.0 - TypeScript
// ============================================

import { getEventBus, EventBus } from '@core/event-bus';

/**
 * Тип данных хранилища
 */
export type StoreData = Record<string, any>;

/**
 * Базовый класс хранилища
 */
export abstract class BaseStore<T extends StoreData = StoreData> {
    protected storeName: string;
    protected _data: T;
    protected _loaded: boolean;
    protected _eventBus: EventBus;

    constructor(storeName: string) {
        this.storeName = storeName;
        this._data = {} as T;
        this._loaded = false;
        this._eventBus = getEventBus();
    }

    // ==========================================
    // ПОЛУЧЕНИЕ ID ПОЛЬЗОВАТЕЛЯ
    // ==========================================

    /**
     * Получить Telegram ID пользователя
     */
    protected getTelegramId(): number | null {
        try {
            const tg = (window as any).Telegram?.WebApp;
            if (!tg) return null;
            
            const initData = tg.initData;
            if (initData) {
                const params = new URLSearchParams(initData);
                const userStr = params.get('user');
                if (userStr) {
                    try {
                        const user = JSON.parse(decodeURIComponent(userStr));
                        if (user?.id) return user.id;
                    } catch {
                        // ignore
                    }
                }
            }
            
            const user = tg.initDataUnsafe?.user;
            return user?.id || null;
        } catch {
            return null;
        }
    }

    // ==========================================
    // ФОРМИРОВАНИЕ КЛЮЧА
    // ==========================================

    /**
     * Получить ключ для localStorage с учетом ID пользователя
     */
    protected getStorageKey(subKey: string = ''): string {
        const telegramId = this.getTelegramId();
        const id = telegramId || 'default';
        
        const prefixMap: Record<string, string> = {
            'chat': 'tg_chat_histories_',
            'user': 'user_store_data_',
            'organizer': 'organizer_',
            'tasks': 'tasks_',
            'jwt': 'jwt_token_',
            'temp': 'temp_'
        };
        
        const prefix = prefixMap[this.storeName] || `${this.storeName}_`;
        if (subKey) {
            return `${prefix}${id}_${subKey}`;
        }
        return `${prefix}${id}`;
    }

    // ==========================================
    // ЗАГРУЗКА/СОХРАНЕНИЕ
    // ==========================================

    /**
     * Загрузить данные из localStorage
     */
    load(): T {
        const storageKey = this.getStorageKey();
        try {
            const data = localStorage.getItem(storageKey);
            if (data) {
                try {
                    this._data = JSON.parse(data);
                } catch {
                    console.warn(`⚠️ Ошибка парсинга ${this.storeName}`);
                    this._data = {} as T;
                }
            } else {
                this._data = {} as T;
            }
            this._loaded = true;
        } catch {
            console.warn(`⚠️ Ошибка загрузки ${this.storeName}`);
            this._data = {} as T;
            this._loaded = true;
        }
        return this._data;
    }

    /**
     * Сохранить данные в localStorage
     */
    save(): void {
        const storageKey = this.getStorageKey();
        try {
            localStorage.setItem(storageKey, JSON.stringify(this._data));
            this._emitChange('data:saved', { store: this.storeName });
        } catch (e) {
            console.error(`❌ Ошибка сохранения ${this.storeName}:`, e);
        }
    }

    // ==========================================
    // JWT
    // ==========================================

    /**
     * Сохранить JWT токен
     */
    saveJWT(token: string | null): void {
        const telegramId = this.getTelegramId();
        const id = telegramId || 'default';
        if (!token) {
            localStorage.removeItem(`jwt_token_${id}`);
            return;
        }
        localStorage.setItem(`jwt_token_${id}`, token);
        this._emitChange('auth:jwt_updated', { token: token ? 'present' : 'null' });
    }

    /**
     * Получить JWT токен
     */
    getJWT(): string | null {
        const telegramId = this.getTelegramId();
        const id = telegramId || 'default';
        return localStorage.getItem(`jwt_token_${id}`);
    }

    /**
     * Очистить JWT токен
     */
    clearJWT(): void {
        const telegramId = this.getTelegramId();
        const id = telegramId || 'default';
        localStorage.removeItem(`jwt_token_${id}`);
        this._emitChange('auth:jwt_cleared', {});
    }

    // ==========================================
    // SYNC TOKEN
    // ==========================================

    /**
     * Сохранить sync_token (без ID!)
     */
    saveSyncToken(token: string | null): void {
        if (!token) {
            localStorage.removeItem('sync_token');
            return;
        }
        localStorage.setItem('sync_token', token);
        this._emitChange('sync:token_updated', { token: token.substring(0, 8) + '...' });
    }

    /**
     * Получить sync_token
     */
    getSyncToken(): string | null {
        return localStorage.getItem('sync_token');
    }

    /**
     * Очистить sync_token
     */
    clearSyncToken(): void {
        localStorage.removeItem('sync_token');
        this._emitChange('sync:token_cleared', {});
    }

    // ==========================================
    // ОБЩИЕ МЕТОДЫ
    // ==========================================

    /**
     * Получить значение по ключу
     */
    get<K extends keyof T>(key: K, defaultValue: T[K] | null = null): T[K] | null {
        if (!this._loaded) this.load();
        return this._data[key] !== undefined ? this._data[key] : defaultValue;
    }

    /**
     * Установить значение по ключу
     */
    set<K extends keyof T>(key: K, value: T[K]): T[K] {
        if (!this._loaded) this.load();
        this._data[key] = value;
        this.save();
        return value;
    }

    /**
     * Удалить значение по ключу
     */
    remove<K extends keyof T>(key: K): void {
        if (!this._loaded) this.load();
        delete this._data[key];
        this.save();
    }

    /**
     * Проверить наличие ключа
     */
    has<K extends keyof T>(key: K): boolean {
        if (!this._loaded) this.load();
        return this._data[key] !== undefined;
    }

    /**
     * Получить все данные
     */
    getAll(): T {
        if (!this._loaded) this.load();
        return { ...this._data };
    }

    /**
     * Установить все данные
     */
    setAll(data: Partial<T>): void {
        this._data = { ...this._data, ...data } as T;
        this.save();
    }

    /**
     * Сбросить данные
     */
    reset(): void {
        this._data = {} as T;
        this._loaded = false;
        this._emitChange('store:reset', { store: this.storeName });
    }

    /**
     * Перезагрузить данные
     */
    reload(): T {
        this._loaded = false;
        return this.load();
    }

    /**
     * Очистить все данные и токены
     */
    clear(): void {
        const telegramId = this.getTelegramId();
        const id = telegramId || 'default';
        
        this._data = {} as T;
        this.save();
        
        localStorage.removeItem(`jwt_token_${id}`);
        localStorage.removeItem('sync_token');
        
        this._emitChange('store:cleared', { store: this.storeName });
    }

    // ==========================================
    // СОБЫТИЯ
    // ==========================================

    /**
     * Отправить событие
     */
    protected _emitChange(event: string, data: any = null): void {
        this._eventBus.emit(event, data, this);
    }

    /**
     * Подписаться на событие
     */
    on(event: string, callback: (data: any, sender?: any) => void, context: any = null): () => void {
        return this._eventBus.on(event, callback, context);
    }

    /**
     * Подписаться на событие один раз
     */
    once(event: string, callback: (data: any, sender?: any) => void, context: any = null): () => void {
        return this._eventBus.once(event, callback, context);
    }

    /**
     * Отписаться от события
     */
    off(event: string, listenerId: string): boolean {
        return this._eventBus.off(event, listenerId);
    }

    /**
     * Отписаться от всех событий для контекста
     */
    offAll(context: any): number {
        return this._eventBus.offAll(context);
    }

    // ==========================================
    // ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    // ==========================================

    /**
     * Генерация UUID
     */
    protected generateId(): string {
        if (typeof crypto !== 'undefined' && crypto.randomUUID) {
            return crypto.randomUUID();
        }
        return Date.now() + '_' + Math.random().toString(36).substring(2, 8);
    }

    /**
     * Получить текущую дату в ISO формате
     */
    protected now(): string {
        return new Date().toISOString();
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКСПОРТ
// ============================================

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).BaseStore = BaseStore;
}

console.log('✅ BaseStore v3.0.0 (TypeScript) загружен');
