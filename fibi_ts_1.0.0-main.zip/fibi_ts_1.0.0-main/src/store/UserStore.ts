// ============================================
// src/store/UserStore.ts
// Описание: Пользователь, настройки, лимиты, устройство
// Версия: 4.0.0 - TypeScript
// ============================================

import { BaseStore } from './BaseStore';

/**
 * Интерфейс данных пользователя
 */
export interface UserData {
    userId: number | null;
    username: string | null;
    firstName: string;
    lastName: string;
    languageCode: string;
    photoUrl: string | null;
    role: 'trial' | 'premium' | 'admin' | 'creator' | 'guest';
    dailyLimit: number;
    usedToday: number;
    syncEnabled: boolean;
    deviceFingerprint: string | null;
    signedFingerprint: string | null;
    deviceType: string;
    devicePlatform: string;
}

/**
 * Интерфейс для данных в localStorage
 */
interface UserStoreData {
    userId: number | null;
    username: string | null;
    firstName: string;
    lastName: string;
    languageCode: string;
    photoUrl: string | null;
    role: 'trial' | 'premium' | 'admin' | 'creator' | 'guest';
    dailyLimit: number;
    usedToday: number;
    syncEnabled: boolean;
    deviceFingerprint: string | null;
    signedFingerprint: string | null;
    deviceType: string;
    devicePlatform: string;
}

/**
 * Хранилище пользовательских данных
 */
export class UserStore extends BaseStore<UserStoreData> {
    private static instance: UserStore | null = null;

    constructor() {
        super('user');
        this.load();

        // Инициализация дефолтных значений
        if (Object.keys(this._data).length === 0) {
            this._data = {
                userId: null,
                username: null,
                firstName: '',
                lastName: '',
                languageCode: 'ru',
                photoUrl: null,
                role: 'trial',
                dailyLimit: 5,
                usedToday: 0,
                syncEnabled: false,
                deviceFingerprint: null,
                signedFingerprint: null,
                deviceType: 'web',
                devicePlatform: 'web'
            };
            this.save();
        }

        // Гарантируем наличие всех полей
        if (this._data.userId === undefined) this._data.userId = null;
        if (this._data.username === undefined) this._data.username = null;
        if (this._data.firstName === undefined) this._data.firstName = '';
        if (this._data.lastName === undefined) this._data.lastName = '';
        if (this._data.languageCode === undefined) this._data.languageCode = 'ru';
        if (this._data.photoUrl === undefined) this._data.photoUrl = null;
        if (this._data.role === undefined) this._data.role = 'trial';
        if (this._data.dailyLimit === undefined) this._data.dailyLimit = 5;
        if (this._data.usedToday === undefined) this._data.usedToday = 0;
        if (this._data.syncEnabled === undefined) this._data.syncEnabled = false;
        if (this._data.deviceFingerprint === undefined) this._data.deviceFingerprint = null;
        if (this._data.signedFingerprint === undefined) this._data.signedFingerprint = null;
        if (this._data.deviceType === undefined) this._data.deviceType = 'web';
        if (this._data.devicePlatform === undefined) this._data.devicePlatform = 'web';

        this.save();
        this.initFromTelegram();
    }

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): UserStore {
        if (!UserStore.instance) {
            UserStore.instance = new UserStore();
        }
        return UserStore.instance;
    }

    // ==========================================
    // ИНИЦИАЛИЗАЦИЯ ИЗ TELEGRAM
    // ==========================================

    /**
     * Инициализировать данные из Telegram
     */
    private initFromTelegram(): void {
        const tg = (window as any).Telegram?.WebApp;
        const user = tg?.initDataUnsafe?.user;

        if (user) {
            const currentUserId = user.id;
            const storedUserId = this._data.userId;

            if (storedUserId && storedUserId !== currentUserId) {
                console.log(`🔄 Пользователь сменился: ${storedUserId} → ${currentUserId}`);
                this._data.userId = currentUserId;
                this._data.username = user.username || null;
                this._data.firstName = user.first_name || '';
                this._data.lastName = user.last_name || '';
                this._data.languageCode = user.language_code || 'ru';
                this._data.photoUrl = user.photo_url || null;
                this._data.usedToday = 0;
                this.save();
                this._emitChange('user:changed', {
                    userId: currentUserId,
                    username: user.username
                });
            } else if (!storedUserId) {
                this._data.userId = currentUserId;
                this._data.username = user.username || null;
                this._data.firstName = user.first_name || '';
                this._data.lastName = user.last_name || '';
                this._data.languageCode = user.language_code || 'ru';
                this._data.photoUrl = user.photo_url || null;
                this.save();
                this._emitChange('user:created', {
                    userId: currentUserId,
                    username: user.username
                });
            }
        }
    }

    // ==========================================
    // ГЕТТЕРЫ
    // ==========================================

    get userId(): number | null {
        return this._data.userId;
    }

    set userId(value: number | null) {
        this._data.userId = value;
        this.save();
    }

    get username(): string | null {
        return this._data.username;
    }

    get firstName(): string {
        return this._data.firstName || '';
    }

    get lastName(): string {
        return this._data.lastName || '';
    }

    get languageCode(): string {
        return this._data.languageCode || 'ru';
    }

    get photoUrl(): string | null {
        return this._data.photoUrl || null;
    }

    get role(): 'trial' | 'premium' | 'admin' | 'creator' | 'guest' {
        return this._data.role || 'trial';
    }

    get dailyLimit(): number {
        return this._data.dailyLimit || 5;
    }

    get usedToday(): number {
        return this._data.usedToday || 0;
    }

    get syncEnabled(): boolean {
        return this._data.syncEnabled || false;
    }

    get deviceFingerprint(): string | null {
        return this._data.deviceFingerprint || null;
    }

    get signedFingerprint(): string | null {
        return this._data.signedFingerprint || null;
    }

    get deviceType(): string {
        return this._data.deviceType || 'web';
    }

    get devicePlatform(): string {
        return this._data.devicePlatform || 'web';
    }

    /**
     * Проверка, является ли пользователь создателем
     */
    get isCreator(): boolean {
        return this.userId === 1541531808;
    }

    // ==========================================
    // СЕТТЕРЫ
    // ==========================================

    /**
     * Установить роль пользователя
     */
    setRole(
        role: 'trial' | 'premium' | 'admin' | 'creator' | 'guest',
        dailyLimit: number,
        syncEnabled: boolean
    ): void {
        const oldRole = this._data.role;
        this._data.role = role;
        this._data.dailyLimit = dailyLimit;
        this._data.syncEnabled = syncEnabled;
        this.save();

        this._emitChange('user:role_changed', {
            oldRole,
            newRole: role,
            dailyLimit,
            syncEnabled
        });
    }

    /**
     * Инкрементировать использование
     */
    incrementUsage(): number {
        this._data.usedToday = (this._data.usedToday || 0) + 1;
        this.save();

        this._emitChange('user:usage_incremented', {
            used: this._data.usedToday,
            limit: this.dailyLimit
        });

        return this._data.usedToday;
    }

    /**
     * Сбросить ежедневное использование
     */
    resetDailyUsage(): void {
        this._data.usedToday = 0;
        this.save();
        this._emitChange('user:usage_reset', {});
    }

    /**
     * Установить fingerprint устройства
     */
    setDeviceFingerprint(
        fingerprint: string,
        signed: string,
        deviceType: string = 'web',
        platform: string = 'web'
    ): void {
        this._data.deviceFingerprint = fingerprint;
        this._data.signedFingerprint = signed || fingerprint;
        this._data.deviceType = deviceType;
        this._data.devicePlatform = platform;
        this.save();
        this._emitChange('user:device_registered', { deviceType, platform });
    }

    /**
     * Получить fingerprint устройства
     */
    getDeviceFingerprint(): string | null {
        return this._data.signedFingerprint || this._data.deviceFingerprint || null;
    }

    // ==========================================
    // ПРОВЕРКИ
    // ==========================================

    /**
     * Проверка, является ли пользователь PRO
     */
    isPro(): boolean {
        return ['premium', 'admin', 'creator'].includes(this.role);
    }

    /**
     * Проверка, является ли пользователь админом
     */
    isAdmin(): boolean {
        return ['admin', 'creator'].includes(this.role);
    }

    /**
     * Проверка, есть ли безлимит
     */
    hasUnlimited(): boolean {
        return this.dailyLimit >= 9999;
    }

    /**
     * Проверка, может ли пользователь синхронизироваться
     */
    canSync(): boolean {
        return this.syncEnabled === true && this.isPro();
    }

    /**
     * Проверка, есть ли оставшаяся квота
     */
    hasRemainingQuota(): boolean {
        if (this.hasUnlimited()) return true;
        return this.usedToday < this.dailyLimit;
    }

    /**
     * Получить оставшуюся квоту
     */
    getRemainingQuota(): number {
        if (this.hasUnlimited()) return Infinity;
        return Math.max(0, this.dailyLimit - this.usedToday);
    }

    // ==========================================
    // ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    // ==========================================

    /**
     * Получить URL аватара
     */
    getAvatarUrl(): string {
        return this.photoUrl || 'https://gravatar.com/avatar/00000000000000000000000000000000?d=mp';
    }

    /**
     * Получить отображаемое имя
     */
    getDisplayName(): string {
        let name = this.firstName;
        if (this.lastName) {
            name += ' ' + this.lastName;
        }
        return name || 'Пользователь';
    }

    /**
     * Получить статистику использования в процентах
     */
    getUsagePercent(): number {
        if (this.hasUnlimited()) return 0;
        if (this.dailyLimit <= 0) return 0;
        return Math.min((this.usedToday / this.dailyLimit) * 100, 100);
    }

    /**
     * Обновить данные пользователя из Telegram
     */
    refreshFromTelegram(): void {
        this.initFromTelegram();
    }

    /**
     * Полный сброс данных пользователя
     */
    reset(): void {
        this._data = {
            userId: null,
            username: null,
            firstName: '',
            lastName: '',
            languageCode: 'ru',
            photoUrl: null,
            role: 'trial',
            dailyLimit: 5,
            usedToday: 0,
            syncEnabled: false,
            deviceFingerprint: null,
            signedFingerprint: null,
            deviceType: 'web',
            devicePlatform: 'web'
        };
        this.save();
        this._emitChange('user:reset', {});
        console.log('🔄 UserStore сброшен');
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let userStoreInstance: UserStore | null = null;

/**
 * Получить экземпляр UserStore
 */
export function getUserStore(): UserStore {
    if (!userStoreInstance) {
        userStoreInstance = UserStore.getInstance();
    }
    return userStoreInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).userStore = getUserStore();
}

console.log('✅ UserStore v4.0.0 (TypeScript) загружен');
