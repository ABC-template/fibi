// ============================================
// src/store/ChatStore.ts
// Описание: Управление чатами и сообщениями
// Версия: 5.0.0 - TypeScript
// ============================================

import { BaseStore } from './BaseStore';
import { getEventBus } from '@core/event-bus';
import { generateUUID } from '@utils/helpers';

/**
 * Интерфейс сообщения
 */
export interface Message {
    id: string;
    text: string;
    type: 'user-msg' | 'ai-msg' | 'system';
    isFavorite: boolean;
    deleted_at: string | null;
    created_at: string;
    updated_at?: string;
}

/**
 * Интерфейс чата
 */
export interface Chat {
    id: string;
    title: string;
    maxContext: number;
    language: string;
    topic: string;
    userRenamed: boolean;
    synced: boolean;
    deleted_at: string | null;
    created_at: string;
    updated_at: string;
    messages: Message[];
    pinned?: boolean;
}

/**
 * Интерфейс данных ChatStore
 */
interface ChatStoreData {
    histories: Record<string, Chat[]>;
    activeIds: Record<string, string | null>;
    currentTopic: string;
}

/**
 * Результат поиска чата
 */
export interface ChatFindResult {
    chat: Chat;
    topic: string;
}

/**
 * Результат поиска сообщения
 */
export interface MessageFindResult {
    chat: Chat;
    topic: string;
    message: Message;
}

/**
 * Опции для создания чата
 */
export interface CreateChatOptions {
    id?: string;
    maxContext?: number;
    language?: string;
    userRenamed?: boolean;
    synced?: boolean;
    messages?: Message[];
}

/**
 * Опции для добавления сообщения
 */
export interface AddMessageOptions {
    id?: string;
    isFavorite?: boolean;
    created_at?: string;
    synced?: boolean;
}

/**
 * Хранилище чатов
 */
export class ChatStore extends BaseStore<ChatStoreData> {
    private static instance: ChatStore | null = null;
    private readonly DEFAULT_TOPICS = ['code', 'creative', 'fast', 'kitchen', 'analytics'];

    private constructor() {
        super('chat');
        this.load();

        // Инициализация дефолтных значений
        if (Object.keys(this._data).length === 0) {
            this._data = {
                histories: {},
                activeIds: {},
                currentTopic: 'code'
            };
            this.save();
        }

        // Гарантируем наличие всех полей
        if (!this._data.histories) this._data.histories = {};
        if (!this._data.activeIds) this._data.activeIds = {};
        if (!this._data.currentTopic) this._data.currentTopic = 'code';

        // Инициализируем все темы
        for (const topic of this.DEFAULT_TOPICS) {
            if (!this._data.activeIds[topic]) {
                this._data.activeIds[topic] = null;
            }
            if (!this._data.histories[topic]) {
                this._data.histories[topic] = [];
            }
        }

        this.save();
    }

    /**
     * Получить экземпляр (синглтон)
     */
    static getInstance(): ChatStore {
        if (!ChatStore.instance) {
            ChatStore.instance = new ChatStore();
        }
        return ChatStore.instance;
    }

    // ==========================================
    // ГЕТТЕРЫ
    // ==========================================

    get histories(): Record<string, Chat[]> {
        return this._data.histories;
    }

    get activeIds(): Record<string, string | null> {
        return this._data.activeIds;
    }

    get currentTopic(): string {
        return this._data.currentTopic;
    }

    set currentTopic(value: string) {
        this._data.currentTopic = value;
        this.save();
        this._emitChange('chat:topic_changed', { topic: value });
    }

    // ==========================================
    // ПОИСК
    // ==========================================

    /**
     * Найти чат по ID
     */
    findChatById(chatId: string): ChatFindResult | null {
        if (!chatId) return null;

        for (const [topic, chats] of Object.entries(this._data.histories)) {
            if (!chats || !Array.isArray(chats)) continue;

            for (const chat of chats) {
                if (chat.id === chatId) {
                    return { chat, topic };
                }
            }
        }
        return null;
    }

    /**
     * Найти сообщение по ID
     */
    findMessageById(messageId: string): MessageFindResult | null {
        if (!messageId) return null;

        for (const [topic, chats] of Object.entries(this._data.histories)) {
            if (!chats || !Array.isArray(chats)) continue;

            for (const chat of chats) {
                if (!chat.messages || !Array.isArray(chat.messages)) continue;

                const found = chat.messages.find(m => m.id === messageId);
                if (found) {
                    return { chat, topic, message: found };
                }
            }
        }
        return null;
    }

    /**
     * Найти чат по сообщению (для совместимости)
     */
    findChatByMessageId(messageId: string): ChatFindResult | null {
        const result = this.findMessageById(messageId);
        if (result) {
            return { chat: result.chat, topic: result.topic };
        }
        return null;
    }

    // ==========================================
    // РАБОТА С ЧАТАМИ
    // ==========================================

    /**
     * Получить чаты по теме
     */
    getChats(topicId?: string): Chat[] {
        const topic = topicId || this._data.currentTopic;
        return this._data.histories[topic] || [];
    }

    /**
     * Получить активный чат по теме
     */
    getActiveChat(topicId?: string): Chat | null {
        const topic = topicId || this._data.currentTopic;
        const chats = this.getChats(topic);
        const activeId = this._data.activeIds[topic];
        return chats.find(c => c.id === activeId) || null;
    }

    /**
     * Установить активный чат
     */
    setActiveChat(topicId: string, chatId: string): void {
        if (!topicId) topicId = this._data.currentTopic;
        this._data.activeIds[topicId] = chatId;
        this.save();
        this._emitChange('chat:active_changed', { topic: topicId, chatId });
    }

    /**
     * Создать новый чат
     */
    createChat(topicId: string, title: string | null, options: CreateChatOptions = {}): Chat {
        const topic = topicId || this._data.currentTopic;
        const sectionName = (window as any).topicNames?.[topic] || topic;
        const chatTitle = title || `Новый чат в ${sectionName}`;

        const newChat: Chat = {
            id: options.id || generateUUID(),
            title: chatTitle,
            maxContext: options.maxContext || 15,
            language: options.language || this.getUserLanguage(),
            topic: topic,
            userRenamed: options.userRenamed || false,
            synced: options.synced || false,
            deleted_at: null,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            messages: options.messages || []
        };

        if (!this._data.histories[topic]) {
            this._data.histories[topic] = [];
        }

        this._data.histories[topic].unshift(newChat);
        this._data.activeIds[topic] = newChat.id;
        this.save();

        console.log(`📝 Создан чат ${newChat.id} в теме ${topic}`);
        this._emitChange('chat:created', { chat: newChat, topic });

        return newChat;
    }

    /**
     * Создать временный чат (или вернуть существующий пустой)
     */
    createTempChat(topicId?: string): Chat | null {
        const topic = topicId || this._data.currentTopic;

        // Проверяем, есть ли уже пустой чат
        const existing = this._data.histories[topic]?.find(c =>
            !c.deleted_at && (!c.messages || c.messages.length === 0)
        );

        if (existing) {
            this._data.activeIds[topic] = existing.id;
            this.save();
            return existing;
        }

        // Создаем новый
        return this.createChat(topic, null, {
            messages: []
        });
    }

    /**
     * Переименовать чат
     */
    renameChat(chatId: string, newTitle: string): boolean {
        const found = this.findChatById(chatId);
        if (!found) {
            console.error(`❌ Чат ${chatId} не найден для переименования`);
            return false;
        }

        const { chat, topic } = found;
        const oldTitle = chat.title;
        chat.title = newTitle.trim();
        chat.userRenamed = true;
        chat.updated_at = new Date().toISOString();
        this.save();

        console.log(`✅ Чат ${chatId} переименован в "${newTitle}"`);
        this._emitChange('chat:renamed', {
            chatId,
            oldTitle,
            newTitle: chat.title,
            topic
        });

        return true;
    }

    /**
     * Обновить чат
     */
    updateChat(chatId: string, data: Partial<Chat>): Chat | null {
        const found = this.findChatById(chatId);
        if (!found) return null;

        const { chat } = found;

        // Обновляем поля
        if (data.title !== undefined) chat.title = data.title;
        if (data.maxContext !== undefined) chat.maxContext = data.maxContext;
        if (data.userRenamed !== undefined) chat.userRenamed = data.userRenamed;
        if (data.messages !== undefined) chat.messages = data.messages;
        if (data.synced !== undefined) chat.synced = data.synced;
        if (data.language !== undefined) chat.language = data.language;
        if (data.pinned !== undefined) chat.pinned = data.pinned;

        chat.updated_at = new Date().toISOString();
        this.save();

        this._emitChange('chat:updated', { chatId, data });
        return chat;
    }

    /**
     * Удалить чат (в корзину)
     */
    deleteChat(chatId: string): boolean {
        const found = this.findChatById(chatId);
        if (!found) {
            console.error(`❌ Чат ${chatId} не найден для удаления`);
            return false;
        }

        const { chat, topic } = found;

        if (chat.deleted_at) {
            console.warn(`⚠️ Чат ${chatId} уже в корзине`);
            return false;
        }

        chat.deleted_at = new Date().toISOString();
        chat.updated_at = new Date().toISOString();

        // Помечаем все сообщения как удаленные
        if (chat.messages && Array.isArray(chat.messages)) {
            chat.messages = chat.messages.map(m => ({
                ...m,
                deleted_at: new Date().toISOString(),
                updated_at: new Date().toISOString()
            }));
        }

        // Обновляем активный чат
        if (this._data.activeIds[topic] === chatId) {
            const remaining = this._data.histories[topic].filter(c => c.id !== chatId && !c.deleted_at);
            this._data.activeIds[topic] = remaining[0]?.id || null;
        }

        this.save();
        console.log(`🗑️ Чат ${chatId} отправлен в корзину (${chat.messages?.length || 0} сообщений)`);
        this._emitChange('chat:deleted', { chatId, topic, chatTitle: chat.title });

        return true;
    }

    /**
     * Восстановить чат из корзины
     */
    restoreChat(chatId: string): boolean {
        const found = this.findChatById(chatId);
        if (!found) {
            console.error(`❌ Чат ${chatId} не найден для восстановления`);
            return false;
        }

        const { chat, topic } = found;

        if (!chat.deleted_at) {
            console.warn(`⚠️ Чат ${chatId} не в корзине`);
            return false;
        }

        chat.deleted_at = null;
        chat.updated_at = new Date().toISOString();

        // Восстанавливаем сообщения
        if (chat.messages && Array.isArray(chat.messages)) {
            chat.messages = chat.messages.map(m => ({
                ...m,
                deleted_at: null,
                updated_at: new Date().toISOString()
            }));
        }

        this._data.activeIds[topic] = chatId;
        this.save();

        console.log(`♻️ Чат ${chatId} восстановлен из корзины (${chat.messages?.length || 0} сообщений)`);
        this._emitChange('chat:restored', { chatId, topic });

        return true;
    }

    /**
     * Безвозвратное удаление чата
     */
    permanentDeleteChat(chatId: string): boolean {
        const found = this.findChatById(chatId);
        if (!found) {
            console.warn(`⚠️ Чат ${chatId} не найден для безвозвратного удаления`);
            return false;
        }

        const { chat, topic } = found;

        if (!chat.deleted_at) {
            console.warn(`⚠️ Чат ${chatId} не в корзине, удаление невозможно`);
            return false;
        }

        const chatTitle = chat.title;
        this._data.histories[topic] = this._data.histories[topic].filter(c => c.id !== chatId);

        if (this._data.activeIds[topic] === chatId) {
            const remaining = this._data.histories[topic] || [];
            this._data.activeIds[topic] = remaining[0]?.id || null;
        }

        this.save();

        console.log(`🗑️ Чат ${chatId} удален навсегда (HARD DELETE)`);
        this._emitChange('chat:permanent_deleted', { chatId, topic, chatTitle });

        return true;
    }

    // ==========================================
    // РАБОТА С СООБЩЕНИЯМИ
    // ==========================================

    /**
     * Добавить сообщение в чат
     */
    addMessage(chatId: string, text: string, type: Message['type'], options: AddMessageOptions = {}): Message | null {
        const found = this.findChatById(chatId);
        if (!found) {
            console.error(`❌ Чат ${chatId} не найден`);
            return null;
        }

        const { chat } = found;

        const newMsg: Message = {
            id: options.id || generateUUID(),
            text: text,
            type: type,
            isFavorite: options.isFavorite || false,
            deleted_at: null,
            created_at: options.created_at || new Date().toISOString()
        };

        chat.messages.push(newMsg);
        chat.updated_at = new Date().toISOString();

        // Автоматическое переименование чата
        if (type === 'user-msg' && !chat.userRenamed) {
            const sectionName = (window as any).topicNames?.[chat.topic] || chat.topic;
            const startTitle = `Новый чат в ${sectionName}`;
            if (chat.title === startTitle || chat.title.includes('Новый чат')) {
                const newTitle = text.substring(0, 30) + (text.length > 30 ? '...' : '');
                chat.title = newTitle;
                chat.userRenamed = true;
            }
        }

        this.save();

        this._emitChange('chat:message_added', {
            chatId,
            message: newMsg,
            chatTitle: chat.title,
            topic: chat.topic
        });

        return newMsg;
    }

    /**
     * Удалить сообщение
     */
    deleteMessage(chatId: string, messageId: string): boolean {
        const found = this.findChatById(chatId);
        if (!found) {
            console.error(`❌ Чат ${chatId} не найден`);
            return false;
        }

        const { chat } = found;
        const msgIndex = chat.messages.findIndex(m => m.id === messageId);
        if (msgIndex === -1) {
            console.error(`❌ Сообщение ${messageId} не найдено`);
            return false;
        }

        const deletedMsg = chat.messages[msgIndex];
        chat.messages.splice(msgIndex, 1);
        chat.updated_at = new Date().toISOString();

        this.save();

        console.log(`🗑️ Сообщение ${messageId} удалено навсегда (HARD DELETE)`);
        this._emitChange('chat:message_deleted', {
            chatId,
            messageId,
            messageText: deletedMsg?.text?.substring(0, 50) || ''
        });

        return true;
    }

    /**
     * Переключить избранное
     */
    toggleFavorite(chatId: string, messageId: string): Message | null {
        const found = this.findChatById(chatId);
        if (!found) return null;

        const { chat } = found;
        const msg = chat.messages.find(m => m.id === messageId);
        if (!msg) return null;

        msg.isFavorite = !msg.isFavorite;
        chat.updated_at = new Date().toISOString();

        this.save();

        this._emitChange('chat:favorite_toggled', {
            chatId,
            messageId,
            isFavorite: msg.isFavorite,
            messageText: msg.text?.substring(0, 50) || ''
        });

        return msg;
    }

    /**
     * Получить все избранные сообщения
     */
    getFavorites(): (Message & { chat_id: string; chat_title: string; topic: string })[] {
        const favorites: (Message & { chat_id: string; chat_title: string; topic: string })[] = [];

        for (const [topic, chats] of Object.entries(this._data.histories)) {
            if (!chats) continue;

            for (const chat of chats) {
                if (!chat.messages) continue;
                if (chat.deleted_at) continue;

                for (const msg of chat.messages) {
                    if (msg.isFavorite && !msg.deleted_at) {
                        favorites.push({
                            ...msg,
                            chat_id: chat.id,
                            chat_title: chat.title,
                            topic: topic
                        });
                    }
                }
            }
        }

        return favorites;
    }

    /**
     * Получить сообщения чата
     */
    getMessages(chatId: string): Message[] {
        const found = this.findChatById(chatId);
        if (!found) return [];

        const { chat } = found;
        return (chat.messages || []).filter(m => !m.deleted_at);
    }

    /**
     * Получить контекстные сообщения (для ИИ)
     */
    getContextMessages(chatId: string, maxContext: number = 15): Message[] {
        const messages = this.getMessages(chatId);
        return messages.slice(-maxContext);
    }

    // ==========================================
    // ПРОВЕРКИ
    // ==========================================

    /**
     * Проверить, есть ли в чате реальные сообщения
     */
    hasRealMessages(chat: Chat): boolean {
        if (!chat || !chat.messages) return false;
        return chat.messages.some(m =>
            (m.type === 'user-msg' || m.type === 'ai-msg') &&
            !m.deleted_at &&
            m.text && m.text.trim().length > 0
        );
    }

    // ==========================================
    // КОРЗИНА
    // ==========================================

    /**
     * Получить содержимое корзины
     */
    getTrash(): { chats: Chat[]; messages: Message[] } {
        const trash = { chats: [] as Chat[], messages: [] as Message[] };

        for (const [topic, chats] of Object.entries(this._data.histories)) {
            if (!chats || !Array.isArray(chats)) continue;

            for (const chat of chats) {
                if (chat.deleted_at) {
                    trash.chats.push({
                        ...chat,
                        topic: topic as any
                    });
                }
            }
        }

        return trash;
    }

    /**
     * Очистить корзину
     */
    clearTrash(): number {
        let cleared = 0;

        for (const [topic, chats] of Object.entries(this._data.histories)) {
            if (!chats || !Array.isArray(chats)) continue;

            const filtered = chats.filter(chat => {
                if (chat.deleted_at) {
                    cleared++;
                    return false;
                }
                return true;
            });

            this._data.histories[topic] = filtered;
        }

        this.save();
        console.log(`🗑️ Корзина очищена (${cleared} чатов)`);
        this._emitChange('chat:trash_cleared', { count: cleared });

        return cleared;
    }

    // ==========================================
    // ОБНОВЛЕНИЕ ИЗ ОБЛАКА
    // ==========================================

    /**
     * Обновить все чаты из облака
     */
    updateAllChats(cloudChats: any[]): void {
        console.log(`📋 [updateAllChats] Полная замена данных: ${cloudChats?.length || 0} чатов...`);

        if (!cloudChats || !Array.isArray(cloudChats)) {
            console.warn('⚠️ [updateAllChats] Нет данных для обновления');
            return;
        }

        const grouped: Record<string, Chat[]> = {};
        let totalMessages = 0;

        for (const chat of cloudChats) {
            const chatTopic = chat.topic_id || 'fast';
            if (!grouped[chatTopic]) {
                grouped[chatTopic] = [];
            }

            const localChat: Chat = {
                id: chat.id,
                title: chat.title || 'Без названия',
                maxContext: chat.max_context || 15,
                language: chat.language || 'ru',
                topic: chatTopic,
                userRenamed: chat.user_renamed || false,
                synced: true,
                deleted_at: chat.deleted_at || null,
                created_at: chat.created_at || new Date().toISOString(),
                updated_at: chat.updated_at || new Date().toISOString(),
                messages: (chat.messages || []).map((m: any) => ({
                    id: m.id,
                    text: m.text,
                    type: m.msg_type || m.type || 'user-msg',
                    isFavorite: m.is_favorite || false,
                    deleted_at: m.deleted_at || null,
                    created_at: m.created_at || new Date().toISOString()
                }))
            };

            // Сортируем сообщения
            localChat.messages.sort((a, b) => {
                return new Date(a.created_at || 0).getTime() - new Date(b.created_at || 0).getTime();
            });

            totalMessages += localChat.messages.length;
            grouped[chatTopic].push(localChat);
        }

        // Обновляем данные
        for (const [topicId, chats] of Object.entries(grouped)) {
            this._data.histories[topicId] = chats;
        }

        // Удаляем пустые темы
        for (const [topicId] of Object.entries(this._data.histories)) {
            if (!grouped[topicId]) {
                this._data.histories[topicId] = [];
            }
        }

        // Обновляем активные чаты
        for (const topicId of Object.keys(this._data.histories)) {
            const chats = this._data.histories[topicId] || [];
            const activeChat = chats.find(c => !c.deleted_at && c.messages && c.messages.length > 0);
            if (activeChat) {
                this._data.activeIds[topicId] = activeChat.id;
            } else {
                this._data.activeIds[topicId] = null;
            }
        }

        this.save();

        console.log(`✅ [updateAllChats] Заменено ${cloudChats.length} чатов, ${totalMessages} сообщений`);
        this._emitChange('chat:all_updated', {
            totalChats: cloudChats.length,
            totalMessages
        });
    }

    /**
     * Обновить метаданные чатов
     */
    updateMetadata(cloudChats: any[], topic: string | null = null): void {
        console.log(`📋 [updateMetadata] Обновляем ${cloudChats?.length || 0} чатов из облака...`);

        if (!cloudChats || !Array.isArray(cloudChats)) {
            console.warn('⚠️ [updateMetadata] Нет данных для обновления');
            return;
        }

        if (topic && this._data.histories[topic]) {
            const topicChats = cloudChats.filter(c => c.topic_id === topic);
            this._data.histories[topic] = topicChats.map(chat => this.convertCloudChat(chat));
            this.save();
            console.log(`✅ [updateMetadata] Обновлена тема ${topic}: ${topicChats.length} чатов`);
            this._emitChange('chat:metadata_updated', { topic, count: topicChats.length });
            return;
        }

        const grouped: Record<string, Chat[]> = {};

        for (const chat of cloudChats) {
            const chatTopic = chat.topic_id || 'fast';
            if (!grouped[chatTopic]) {
                grouped[chatTopic] = [];
            }
            grouped[chatTopic].push(this.convertCloudChat(chat));
        }

        for (const [topicId, chats] of Object.entries(grouped)) {
            if (this._data.histories[topicId]) {
                this._data.histories[topicId] = chats;
            } else {
                this._data.histories[topicId] = chats;
            }
        }

        for (const [topicId] of Object.entries(this._data.histories)) {
            if (!grouped[topicId]) {
                this._data.histories[topicId] = [];
            }
        }

        this.save();
        console.log(`✅ [updateMetadata] Обновлены все темы: ${cloudChats.length} чатов`);
        this._emitChange('chat:metadata_updated', { count: cloudChats.length });
    }

    /**
     * Конвертировать облачный чат в локальный
     */
    private convertCloudChat(cloudChat: any): Chat {
        return {
            id: cloudChat.id,
            title: cloudChat.title || 'Без названия',
            maxContext: cloudChat.max_context || 15,
            language: cloudChat.language || 'ru',
            topic: cloudChat.topic_id || 'fast',
            userRenamed: cloudChat.user_renamed || false,
            synced: true,
            deleted_at: cloudChat.deleted_at || null,
            created_at: cloudChat.created_at || new Date().toISOString(),
            updated_at: cloudChat.updated_at || new Date().toISOString(),
            messages: []
        };
    }

    // ==========================================
    // ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
    // ==========================================

    /**
     * Получить язык пользователя
     */
    private getUserLanguage(): string {
        try {
            const tg = (window as any).Telegram?.WebApp;
            return tg?.initDataUnsafe?.user?.language_code || 'ru';
        } catch {
            return 'ru';
        }
    }

    /**
     * Очистить временные чаты (пустые, старше 5 минут)
     */
    cleanupTempChats(): number {
        let cleaned = 0;
        const now = new Date();
        const maxAgeMs = 5 * 60 * 1000;

        for (const [topic, chats] of Object.entries(this._data.histories)) {
            if (!chats || !Array.isArray(chats)) continue;

            const filtered = chats.filter(chat => {
                if (chat.deleted_at) return true;
                if (this.hasRealMessages(chat)) return true;

                const createdAt = new Date(chat.created_at);
                const age = now.getTime() - createdAt.getTime();
                if (age > maxAgeMs) {
                    cleaned++;
                    return false;
                }
                return true;
            });

            if (filtered.length !== chats.length) {
                this._data.histories[topic] = filtered;
            }
        }

        if (cleaned > 0) {
            this.save();
            this._emitChange('chat:temp_cleaned', { count: cleaned });
        }

        return cleaned;
    }

    // ==========================================
    // ПРОГРЕСС ЗАГРУЗКИ
    // ==========================================

    /**
     * Проверить, идет ли загрузка
     */
    isUploadInProgress(): boolean {
        return localStorage.getItem('upload_in_progress') === 'true';
    }

    /**
     * Получить прогресс загрузки
     */
    getUploadProgress(): { total: number; current: number; startedAt: number } {
        return {
            total: parseInt(localStorage.getItem('upload_chats_count') || '0'),
            current: parseInt(localStorage.getItem('upload_current_index') || '0'),
            startedAt: parseInt(localStorage.getItem('upload_started_at') || '0')
        };
    }

    /**
     * Установить прогресс загрузки
     */
    setUploadProgress(current: number, total: number): void {
        localStorage.setItem('upload_in_progress', 'true');
        localStorage.setItem('upload_chats_count', String(total));
        localStorage.setItem('upload_current_index', String(current));
        localStorage.setItem('upload_started_at', String(Date.now()));
    }

    /**
     * Очистить флаги загрузки
     */
    clearUploadFlags(): void {
        localStorage.removeItem('upload_in_progress');
        localStorage.removeItem('upload_started_at');
        localStorage.removeItem('upload_chats_count');
        localStorage.removeItem('upload_current_index');
    }
}

// ============================================
// ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР
// ============================================

let chatStoreInstance: ChatStore | null = null;

/**
 * Получить экземпляр ChatStore
 */
export function getChatStore(): ChatStore {
    if (!chatStoreInstance) {
        chatStoreInstance = ChatStore.getInstance();
    }
    return chatStoreInstance;
}

// Экспортируем в глобальный объект для совместимости
if (typeof window !== 'undefined') {
    (window as any).ChatStore = ChatStore;
    (window as any).chatStore = getChatStore();
}

console.log('✅ ChatStore v5.0.0 (TypeScript) загружен');
