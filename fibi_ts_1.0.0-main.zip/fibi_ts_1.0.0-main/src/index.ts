// ============================================
// src/index.ts
// Точка входа приложения
// ============================================

// Импортируем стили
import '../style.css';
import '../add.css';

// Импортируем Core
import './core/event-bus';
import './core/theme-manager';
import './core/header-manager';
import './core/navigation-state';
import './core/module-loader';
import './core/navigation';
import './core/back-button-manager';
import './core/modal-manager';

// Импортируем Store
import './store/BaseStore';
import './store/ChatStore';
import './store/UserStore';
import './store/OrganizerStore';
import './store/TasksStore';

// Импортируем Services
import './services/api';
import './services/auth';
import './services/chats';
import './services/messages';
import './services/organizer';
import './services/sync';
import './services/device';

// Импортируем UI
import './modules/ui/renderer';
import './modules/ui/chat-ui';
import './modules/ui/profile-ui';
import './modules/ui/organizer-ui';

// Импортируем утилиты
import './utils/helpers';
import './utils/validators';

// Импортируем модули
import './modules/chat-list/ChatListModule';
import './modules/chat/ChatModule';
import './modules/chat/send';
import './modules/chat/stream';
import './modules/chat/voice';
import './modules/chat/media';
import './modules/ui-footer';
import './modules/organizer/OrganizerModule';
import './modules/profile/ProfileModule';
import './modules/dashboard/DashboardModule';
import './modules/games/GamesModule';
import './modules/games/tetris/TetrisGame';
import './modules/games/sudoku/SudokuGame';
import './modules/tasks/TasksModule';
import './modules/export-local';
import './modules/trash';

// Импортируем App
import './core/app';

// Инициализация приложения
console.log('🚀 FIBI v2.0.0 (TypeScript)');
